import 'dart:async';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../core/theme/app_theme.dart';
import '../../viewmodels/motohub_viewmodel.dart';

/// Multi-step Password Recovery Screen with 60-second OTP Resend Cooldown
class ForgotPasswordScreen extends StatefulWidget {
  final String? initialEmail;

  const ForgotPasswordScreen({super.key, this.initialEmail});

  static Future<void> navigate(BuildContext context, {String? initialEmail}) {
    return Navigator.of(context).push(
      MaterialPageRoute(
        builder: (_) => ForgotPasswordScreen(initialEmail: initialEmail),
      ),
    );
  }

  @override
  State<ForgotPasswordScreen> createState() => _ForgotPasswordScreenState();
}

class _ForgotPasswordScreenState extends State<ForgotPasswordScreen> {
  int _currentStep = 0; // 0: Email, 1: OTP, 2: New Password, 3: Success

  final TextEditingController _emailController = TextEditingController();
  final TextEditingController _otpController = TextEditingController();
  final TextEditingController _passwordController = TextEditingController();
  final TextEditingController _confirmPasswordController =
      TextEditingController();

  bool _obscurePassword = true;
  bool _obscureConfirmPassword = true;
  bool _isLoading = false;

  Timer? _cooldownTimer;
  int _remainingCooldown = 0;

  @override
  void initState() {
    super.initState();
    if (widget.initialEmail != null && widget.initialEmail!.isNotEmpty) {
      _emailController.text = widget.initialEmail!;
    }
  }

  @override
  void dispose() {
    _cooldownTimer?.cancel();
    _emailController.dispose();
    _otpController.dispose();
    _passwordController.dispose();
    _confirmPasswordController.dispose();
    super.dispose();
  }

  void _startCooldownTimer(int seconds) {
    _cooldownTimer?.cancel();
    setState(() => _remainingCooldown = seconds);

    _cooldownTimer = Timer.periodic(const Duration(seconds: 1), (timer) {
      if (!mounted) {
        timer.cancel();
        return;
      }
      if (_remainingCooldown <= 1) {
        timer.cancel();
        setState(() => _remainingCooldown = 0);
      } else {
        setState(() => _remainingCooldown--);
      }
    });
  }

  Future<void> _handleSendOtp() async {
    final email = _emailController.text.trim();
    if (email.isEmpty || !email.contains('@')) {
      _showSnack('Please enter a valid email address.', isError: true);
      return;
    }

    setState(() => _isLoading = true);
    final vm = context.read<MotoHubViewModel>();
    final success = await vm.sendPasswordResetOtp(email);
    setState(() => _isLoading = false);

    if (success) {
      _startCooldownTimer(60);
      setState(() => _currentStep = 1);
      _showSnack('6-digit OTP verification code sent to $email');
    } else {
      _showSnack(vm.statusMessage ?? 'Failed to send OTP code.', isError: true);
    }
  }

  Future<void> _handleResendOtp() async {
    if (_remainingCooldown > 0) return;
    final email = _emailController.text.trim();
    setState(() => _isLoading = true);
    final vm = context.read<MotoHubViewModel>();
    final success = await vm.sendPasswordResetOtp(email);
    setState(() => _isLoading = false);

    if (success) {
      _startCooldownTimer(60);
      _showSnack('New verification code sent to $email');
    } else {
      _showSnack(vm.statusMessage ?? 'Failed to resend code.', isError: true);
    }
  }

  void _handleVerifyOtp() {
    final email = _emailController.text.trim();
    final otp = _otpController.text.trim();

    if (otp.length != 6) {
      _showSnack('Please enter the full 6-digit OTP code.', isError: true);
      return;
    }

    final vm = context.read<MotoHubViewModel>();
    final isValid = vm.verifyPasswordResetOtp(email, otp);
    if (isValid) {
      setState(() => _currentStep = 2);
    } else {
      _showSnack('Invalid or expired OTP code. Please try again.', isError: true);
    }
  }

  Future<void> _handleResetPassword() async {
    final email = _emailController.text.trim();
    final otp = _otpController.text.trim();
    final newPass = _passwordController.text;
    final confirmPass = _confirmPasswordController.text;

    if (newPass.length < 6) {
      _showSnack('Password must be at least 6 characters long.', isError: true);
      return;
    }
    if (newPass != confirmPass) {
      _showSnack('Passwords do not match.', isError: true);
      return;
    }

    setState(() => _isLoading = true);
    final vm = context.read<MotoHubViewModel>();
    final success = await vm.resetPasswordWithOtp(
      email: email,
      otp: otp,
      newPassword: newPass,
    );
    setState(() => _isLoading = false);

    if (success) {
      setState(() => _currentStep = 3);
    } else {
      _showSnack(vm.statusMessage ?? 'Failed to reset password.', isError: true);
    }
  }

  void _showSnack(String message, {bool isError = false}) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message),
        backgroundColor: isError ? AppPalette.danger : AppPalette.success,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppPalette.crust,
      appBar: AppBar(
        title: const Text('Account Recovery'),
        backgroundColor: AppPalette.mantle,
        foregroundColor: AppPalette.textHigh,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(24),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            // Stepper Indicator
            _buildStepperIndicator(),
            const SizedBox(height: 28),

            // Step Content
            if (_currentStep == 0) _buildEmailStep(),
            if (_currentStep == 1) _buildOtpStep(),
            if (_currentStep == 2) _buildNewPasswordStep(),
            if (_currentStep == 3) _buildSuccessStep(),
          ],
        ),
      ),
    );
  }

  Widget _buildStepperIndicator() {
    final steps = ['Email', 'Verify OTP', 'New Pass', 'Done'];
    return Row(
      children: List.generate(steps.length * 2 - 1, (index) {
        if (index.isOdd) {
          final stepIdx = index ~/ 2;
          final isPassed = _currentStep > stepIdx;
          return Expanded(
            child: Container(
              height: 2,
              color: isPassed
                  ? AppPalette.champagneGold
                  : AppPalette.surface2,
            ),
          );
        }
        final stepIdx = index ~/ 2;
        final isActive = _currentStep == stepIdx;
        final isCompleted = _currentStep > stepIdx;

        return Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: 32,
              height: 32,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: isCompleted
                    ? AppPalette.champagneGold
                    : (isActive ? AppPalette.surface2 : AppPalette.surface0),
                border: Border.all(
                  color: isActive
                      ? AppPalette.champagneGold
                      : (isCompleted ? AppPalette.champagneGold : AppPalette.surface2),
                  width: 2,
                ),
              ),
              child: Center(
                child: isCompleted
                    ? const Icon(
                        Icons.check_rounded,
                        size: 18,
                        color: AppPalette.crust,
                      )
                    : Text(
                        '${stepIdx + 1}',
                        style: TextStyle(
                          color: isActive
                              ? AppPalette.champagneGold
                              : AppPalette.textMuted,
                          fontWeight: FontWeight.w800,
                          fontSize: 13,
                        ),
                      ),
              ),
            ),
            const SizedBox(height: 4),
            Text(
              steps[stepIdx],
              style: TextStyle(
                color: isActive
                    ? AppPalette.champagneGold
                    : (isCompleted ? AppPalette.textHigh : AppPalette.textMuted),
                fontSize: 10,
                fontWeight: isActive ? FontWeight.w700 : FontWeight.w500,
              ),
            ),
          ],
        );
      }),
    );
  }

  Widget _buildEmailStep() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        const Icon(
          Icons.mark_email_read_rounded,
          size: 64,
          color: AppPalette.champagneGold,
        ),
        const SizedBox(height: 16),
        const Text(
          'Forgot Your Password?',
          textAlign: TextAlign.center,
          style: TextStyle(
            color: AppPalette.textHigh,
            fontSize: 20,
            fontWeight: FontWeight.w800,
          ),
        ),
        const SizedBox(height: 8),
        const Text(
          'Enter your registered email address and we will generate a secure 6-digit OTP code to verify your identity.',
          textAlign: TextAlign.center,
          style: TextStyle(
            color: AppPalette.textMuted,
            fontSize: 13,
          ),
        ),
        const SizedBox(height: 28),
        TextField(
          controller: _emailController,
          keyboardType: TextInputType.emailAddress,
          style: const TextStyle(color: AppPalette.textHigh),
          decoration: InputDecoration(
            labelText: 'Registered Email',
            hintText: 'e.g. arman.sarita@bossarman.com',
            prefixIcon: const Icon(Icons.email_outlined),
            filled: true,
            fillColor: AppPalette.surface0,
            border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(12),
              borderSide: BorderSide.none,
            ),
          ),
        ),
        const SizedBox(height: 24),
        ElevatedButton(
          onPressed: _isLoading ? null : _handleSendOtp,
          style: ElevatedButton.styleFrom(
            backgroundColor: AppPalette.champagneGold,
            foregroundColor: AppPalette.crust,
            padding: const EdgeInsets.symmetric(vertical: 16),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(12),
            ),
          ),
          child: _isLoading
              ? const SizedBox(
                  width: 20,
                  height: 20,
                  child: CircularProgressIndicator(
                    strokeWidth: 2,
                    color: AppPalette.crust,
                  ),
                )
              : const Text(
                  'SEND OTP CODE',
                  style: TextStyle(fontWeight: FontWeight.w800),
                ),
        ),
      ],
    );
  }

  Widget _buildOtpStep() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        const Icon(
          Icons.security_rounded,
          size: 64,
          color: AppPalette.champagneGold,
        ),
        const SizedBox(height: 16),
        const Text(
          'Enter 6-Digit OTP Code',
          textAlign: TextAlign.center,
          style: TextStyle(
            color: AppPalette.textHigh,
            fontSize: 20,
            fontWeight: FontWeight.w800,
          ),
        ),
        const SizedBox(height: 8),
        Text(
          'We have sent a verification code to ${_emailController.text}.',
          textAlign: TextAlign.center,
          style: const TextStyle(
            color: AppPalette.textMuted,
            fontSize: 13,
          ),
        ),
        const SizedBox(height: 28),
        TextField(
          controller: _otpController,
          keyboardType: TextInputType.number,
          maxLength: 6,
          textAlign: TextAlign.center,
          style: const TextStyle(
            color: AppPalette.textHigh,
            fontSize: 26,
            fontWeight: FontWeight.w900,
            letterSpacing: 8,
          ),
          decoration: InputDecoration(
            counterText: '',
            hintText: '000000',
            filled: true,
            fillColor: AppPalette.surface0,
            border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(12),
              borderSide: const BorderSide(color: AppPalette.champagneGold),
            ),
          ),
        ),
        const SizedBox(height: 16),

        // 60-second Cooldown Timer & Resend Link
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            if (_remainingCooldown > 0)
              Text(
                'Resend code in ${_remainingCooldown}s',
                style: const TextStyle(
                  color: AppPalette.textMuted,
                  fontSize: 13,
                ),
              )
            else
              TextButton.icon(
                onPressed: _isLoading ? null : _handleResendOtp,
                icon: const Icon(Icons.refresh_rounded, size: 16),
                label: const Text('Resend OTP Code'),
                style: TextButton.styleFrom(
                  foregroundColor: AppPalette.champagneGold,
                ),
              ),
          ],
        ),
        const SizedBox(height: 20),

        ElevatedButton(
          onPressed: _handleVerifyOtp,
          style: ElevatedButton.styleFrom(
            backgroundColor: AppPalette.champagneGold,
            foregroundColor: AppPalette.crust,
            padding: const EdgeInsets.symmetric(vertical: 16),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(12),
            ),
          ),
          child: const Text(
            'VERIFY CODE',
            style: TextStyle(fontWeight: FontWeight.w800),
          ),
        ),
        const SizedBox(height: 10),
        TextButton(
          onPressed: () => setState(() => _currentStep = 0),
          child: const Text(
            'Change Email Address',
            style: TextStyle(color: AppPalette.textMuted),
          ),
        ),
      ],
    );
  }

  Widget _buildNewPasswordStep() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        const Icon(
          Icons.lock_reset_rounded,
          size: 64,
          color: AppPalette.champagneGold,
        ),
        const SizedBox(height: 16),
        const Text(
          'Set New Password',
          textAlign: TextAlign.center,
          style: TextStyle(
            color: AppPalette.textHigh,
            fontSize: 20,
            fontWeight: FontWeight.w800,
          ),
        ),
        const SizedBox(height: 8),
        const Text(
          'Ensure your new password contains at least 6 characters.',
          textAlign: TextAlign.center,
          style: TextStyle(
            color: AppPalette.textMuted,
            fontSize: 13,
          ),
        ),
        const SizedBox(height: 28),
        TextField(
          controller: _passwordController,
          obscureText: _obscurePassword,
          style: const TextStyle(color: AppPalette.textHigh),
          decoration: InputDecoration(
            labelText: 'New Password',
            prefixIcon: const Icon(Icons.lock_outline),
            suffixIcon: IconButton(
              icon: Icon(
                _obscurePassword
                    ? Icons.visibility_outlined
                    : Icons.visibility_off_outlined,
              ),
              onPressed: () =>
                  setState(() => _obscurePassword = !_obscurePassword),
            ),
            filled: true,
            fillColor: AppPalette.surface0,
            border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(12),
              borderSide: BorderSide.none,
            ),
          ),
        ),
        const SizedBox(height: 16),
        TextField(
          controller: _confirmPasswordController,
          obscureText: _obscureConfirmPassword,
          style: const TextStyle(color: AppPalette.textHigh),
          decoration: InputDecoration(
            labelText: 'Confirm New Password',
            prefixIcon: const Icon(Icons.lock_outline),
            suffixIcon: IconButton(
              icon: Icon(
                _obscureConfirmPassword
                    ? Icons.visibility_outlined
                    : Icons.visibility_off_outlined,
              ),
              onPressed: () => setState(
                  () => _obscureConfirmPassword = !_obscureConfirmPassword),
            ),
            filled: true,
            fillColor: AppPalette.surface0,
            border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(12),
              borderSide: BorderSide.none,
            ),
          ),
        ),
        const SizedBox(height: 24),
        ElevatedButton(
          onPressed: _isLoading ? null : _handleResetPassword,
          style: ElevatedButton.styleFrom(
            backgroundColor: AppPalette.champagneGold,
            foregroundColor: AppPalette.crust,
            padding: const EdgeInsets.symmetric(vertical: 16),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(12),
            ),
          ),
          child: _isLoading
              ? const SizedBox(
                  width: 20,
                  height: 20,
                  child: CircularProgressIndicator(
                    strokeWidth: 2,
                    color: AppPalette.crust,
                  ),
                )
              : const Text(
                  'CONFIRM & SAVE PASSWORD',
                  style: TextStyle(fontWeight: FontWeight.w800),
                ),
        ),
      ],
    );
  }

  Widget _buildSuccessStep() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        const Icon(
          Icons.check_circle_rounded,
          size: 72,
          color: AppPalette.success,
        ),
        const SizedBox(height: 16),
        const Text(
          'Password Reset Successful!',
          textAlign: TextAlign.center,
          style: TextStyle(
            color: AppPalette.textHigh,
            fontSize: 22,
            fontWeight: FontWeight.w800,
          ),
        ),
        const SizedBox(height: 10),
        const Text(
          'Your account credentials have been updated securely. You can now log in with your new password.',
          textAlign: TextAlign.center,
          style: TextStyle(
            color: AppPalette.textMuted,
            fontSize: 14,
          ),
        ),
        const SizedBox(height: 32),
        ElevatedButton(
          onPressed: () => Navigator.of(context).pop(),
          style: ElevatedButton.styleFrom(
            backgroundColor: AppPalette.champagneGold,
            foregroundColor: AppPalette.crust,
            padding: const EdgeInsets.symmetric(vertical: 16),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(12),
            ),
          ),
          child: const Text(
            'RETURN TO SIGN IN',
            style: TextStyle(fontWeight: FontWeight.w800),
          ),
        ),
      ],
    );
  }
}
