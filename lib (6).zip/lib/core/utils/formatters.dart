import 'package:intl/intl.dart';

class AppFormatters {
  AppFormatters._();

  static final NumberFormat _pesoFormat = NumberFormat.currency(
    locale: 'en_PH',
    symbol: '₱',
    decimalDigits: 2,
  );

  static final NumberFormat _pesoWholeFormat = NumberFormat.currency(
    locale: 'en_PH',
    symbol: '₱',
    decimalDigits: 0,
  );

  /// Safely formats currency while guarding against NaN and Infinity crashes.
  static String currency(double amount, {bool showDecimals = true}) {
    final safeAmount = (amount.isNaN || amount.isInfinite) ? 0.0 : amount;
    return showDecimals
        ? _pesoFormat.format(safeAmount)
        : _pesoWholeFormat.format(safeAmount);
  }

  static String dateTimeShort(DateTime dt) {
    return DateFormat('MMM d, h:mm a').format(dt);
  }

  static String timeOnly(DateTime dt) {
    return DateFormat('h:mm a').format(dt);
  }

  static String relativeTime(DateTime dt) {
    final diff = DateTime.now().difference(dt);
    if (diff.inSeconds < 60) return 'Just now';
    if (diff.inMinutes < 60) return '${diff.inMinutes}m ago';
    if (diff.inHours < 24) return '${diff.inHours}h ago';
    return DateFormat('MMM d').format(dt);
  }
}

class AppValidators {
  AppValidators._();

  static String? requiredField(
    String? value, [
    String fieldName = 'This field',
  ]) {
    if (value == null || value.trim().isEmpty) {
      return '$fieldName is required';
    }
    return null;
  }

  static String? positiveQuantity(String? value) {
    if (value == null || value.trim().isEmpty) {
      return 'Quantity is required';
    }
    final parsed = int.tryParse(value.trim());
    if (parsed == null) {
      return 'Enter a valid whole number';
    }
    if (parsed <= 0) {
      return 'Quantity must be greater than 0';
    }
    return null;
  }

  static String? nonNegativeInt(String? value) {
    if (value == null || value.trim().isEmpty) {
      return 'Stock count is required';
    }
    final parsed = int.tryParse(value.trim());
    if (parsed == null) {
      return 'Enter a valid whole number';
    }
    if (parsed < 0) {
      return 'Negative quantities are not allowed';
    }
    return null;
  }

  /// Rejects null, empty, NaN, Infinity, or negative currency values.
  static String? positiveAmount(String? value) {
    if (value == null || value.trim().isEmpty) {
      return 'Amount is required';
    }
    final parsed = double.tryParse(value.trim());
    if (parsed == null || parsed.isNaN || parsed.isInfinite) {
      return 'Enter a valid numeric amount';
    }
    if (parsed < 0) {
      return 'Negative amount is not allowed';
    }
    return null;
  }

  /// Validates Philippine LTO Motorcycle Plate / MV File format
  /// Examples: "123-ABC", "ABC-1234", "NBO-4412", "0401-0123456", "FOR-REG"
  static String? plateNumber(String? value) {
    if (value == null || value.trim().isEmpty) {
      return 'Plate or MV File No. is required';
    }
    final clean = value.trim().toUpperCase();
    final regExp = RegExp(r'^[A-Z0-9]{2,4}[-\s]?[A-Z0-9]{3,7}$');
    if (!regExp.hasMatch(clean)) {
      return 'Invalid plate format (e.g., 412-NBO or ABC-1234)';
    }
    return null;
  }

  static String? email(String? value) {
    if (value == null || value.trim().isEmpty) {
      return 'Email address is required';
    }
    final regExp = RegExp(r'^[^@\s]+@[^@\s]+\.[^@\s]+$');
    if (!regExp.hasMatch(value.trim())) {
      return 'Enter a valid email address';
    }
    return null;
  }

  static String? username(String? value) {
    if (value == null || value.trim().isEmpty) {
      return 'Username is required';
    }
    if (value.trim().length < 4) {
      return 'Username must be at least 4 characters';
    }
    return null;
  }

  static String? password(String? value) {
    if (value == null || value.trim().isEmpty) {
      return 'Password is required';
    }
    if (value.length < 6) {
      return 'Password must be at least 6 characters';
    }
    return null;
  }
}
