import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'core/theme/app_theme.dart';
import 'viewmodels/motohub_viewmodel.dart';
import 'views/shared/cloud_sync_banner.dart';
import 'views/splash_screen.dart';

/// App B Entry Point: Customer Facing Companion Application
/// Features: Google One-Tap / Google Sign-In, Email/Password Auth,
/// Live Service Tracking, Appointments, and Atomic Click & Collect Reservations.
/// Run command: `flutter run -t lib/main_customer.dart`
void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const BossArmanCustomerApp());
}

class BossArmanCustomerApp extends StatelessWidget {
  const BossArmanCustomerApp({super.key});

  @override
  Widget build(BuildContext context) {
    return ChangeNotifierProvider<MotoHubViewModel>(
      create: (_) => MotoHubViewModel(isCustomerApp: true),
      child: MaterialApp(
        title: 'Boss Arman MotoHub • Rider Portal',
        debugShowCheckedModeBanner: false,
        theme: AppTheme.darkTheme,
        darkTheme: AppTheme.darkTheme,
        themeMode: ThemeMode.dark,
        builder: (context, child) =>
            CloudSyncBanner(child: child ?? const SizedBox.shrink()),
        home: const SplashScreen(isCustomerApp: true),
      ),
    );
  }
}
