import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'core/theme/app_theme.dart';
import 'viewmodels/motohub_viewmodel.dart';
import 'views/shared/cloud_sync_banner.dart';
import 'views/splash_screen.dart';

/// App A Entry Point: Internal ERP, POS & Bay Management System
/// Roles supported: Admin (`bossarman`), Cashier (`cashier01`), Mechanic (`mechanic01`)
/// Run command: `flutter run -t lib/main_internal.dart`
void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const BossArmanInternalApp());
}

class BossArmanInternalApp extends StatelessWidget {
  const BossArmanInternalApp({super.key});

  @override
  Widget build(BuildContext context) {
    return ChangeNotifierProvider<MotoHubViewModel>(
      create: (_) => MotoHubViewModel(isCustomerApp: false),
      child: MaterialApp(
        title: 'Boss Arman MotoHub • Internal ERP/POS',
        debugShowCheckedModeBanner: false,
        theme: AppTheme.darkTheme,
        darkTheme: AppTheme.darkTheme,
        themeMode: ThemeMode.dark,
        builder: (context, child) =>
            CloudSyncBanner(child: child ?? const SizedBox.shrink()),
        home: const SplashScreen(isCustomerApp: false),
      ),
    );
  }
}
