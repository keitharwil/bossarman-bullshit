package com.bossarman.motohub.boss_arman_motohub

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
