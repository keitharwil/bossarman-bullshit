import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../core/models/models.dart';
import '../core/theme/app_theme.dart';
import '../core/utils/formatters.dart';
import '../viewmodels/motohub_viewmodel.dart';
import 'role_router_screen.dart';
import 'shared/forgot_password_screen.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  // Matches the 2-step flow in the user's Figma design:
  // Step 0 = "LOGIN" ("Staff & Management" -> "Log In to Account")
  // Step 1 = "USERNAME and password" ("Staff Login" -> "What's your username and password?" -> "Next ->")
  bool _showCredentialsForm = false;

  final _formKey = GlobalKey<FormState>();
  final _usernameController = TextEditingController();
  final _passwordController = TextEditingController();
  bool _obscurePassword = true;

  @override
  void dispose() {
    _usernameController.dispose();
    _passwordController.dispose();
    super.dispose();
  }

  Future<void> _submitLogin() async {
    if (!(_formKey.currentState?.validate() ?? false)) return;

    final vm = context.read<MotoHubViewModel>();
    try {
      final ok = await vm.login(
        _usernameController.text.trim(),
        _passwordController.text,
        customerOnly: false,
      );

      if (!mounted) return;
      if (ok) {
        Navigator.of(context).pushReplacement(
          MaterialPageRoute(builder: (_) => const RoleRouterScreen()),
        );
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            backgroundColor: AppPalette.surface1,
            content: Row(
              children: [
                const Icon(Icons.error_outline_rounded, color: AppPalette.danger),
                const SizedBox(width: 10),
                Expanded(
                  child: Text(
                    vm.statusMessage ?? 'Invalid login credentials',
                    style: const TextStyle(color: AppPalette.textHigh),
                  ),
                ),
              ],
            ),
          ),
        );
      }
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          backgroundColor: AppPalette.danger,
          content: Text(
            'Authentication error: $e',
            style: const TextStyle(color: AppPalette.crust),
          ),
        ),
      );
    }
  }

  Future<void> _openGoogleOneTapModal() async {
    final sheetFormKey = GlobalKey<FormState>();
    String emailInput = '';
    String nameInput = '';

    final proceed = await showModalBottomSheet<bool>(
      context: context,
      isScrollControlled: true,
      backgroundColor: AppPalette.mantle,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      builder: (sheetCtx) => Padding(
        padding: EdgeInsets.only(
          left: 20,
          right: 20,
          top: 20,
          bottom: MediaQuery.of(sheetCtx).viewInsets.bottom + 24,
        ),
        child: Form(
          key: sheetFormKey,
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Row(
                    children: [
                      Container(
                        width: 36,
                        height: 36,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          color: AppPalette.surface1,
                          border: Border.all(
                            color: AppPalette.champagneGold,
                            width: 1.2,
                          ),
                        ),
                        child: const Center(
                          child: Text(
                            'G',
                            style: TextStyle(
                              color: AppPalette.champagneGold,
                              fontSize: 18,
                              fontWeight: FontWeight.w900,
                            ),
                          ),
                        ),
                      ),
                      const SizedBox(width: 10),
                      const Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            'Google One-Tap Sign-In',
                            style: TextStyle(
                              color: AppPalette.textHigh,
                              fontSize: 16,
                              fontWeight: FontWeight.w800,
                            ),
                          ),
                          Text(
                            'Staff & Management Identity Provider',
                            style: TextStyle(
                              color: AppPalette.textMuted,
                              fontSize: 11.5,
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                  IconButton(
                    icon: const Icon(Icons.close_rounded),
                    onPressed: () => Navigator.of(sheetCtx).pop(false),
                  ),
                ],
              ),
              const Divider(height: 24),
              const Text(
                'Sign in using your Google account credentials. Only staff email addresses registered and provisioned by the Shop Admin can access the system.',
                style: TextStyle(
                  color: AppPalette.textBody,
                  fontSize: 12.5,
                  height: 1.35,
                ),
              ),
              const SizedBox(height: 14),
              TextFormField(
                onChanged: (v) => nameInput = v,
                decoration: const InputDecoration(
                  labelText: 'Google Account Full Name',
                  hintText: 'e.g. Arman Sarita',
                  prefixIcon: Icon(Icons.badge_outlined),
                ),
              ),
              const SizedBox(height: 12),
              TextFormField(
                onChanged: (v) => emailInput = v,
                keyboardType: TextInputType.emailAddress,
                validator: AppValidators.email,
                decoration: const InputDecoration(
                  labelText: 'Google Email Address',
                  hintText: 'e.g. bossarman@motohub.ph',
                  prefixIcon: Icon(Icons.alternate_email_rounded),
                ),
              ),
              const SizedBox(height: 18),
              GoldGradientButton(
                label: 'Continue with Google Account',
                icon: Icons.verified_user_outlined,
                onPressed: () {
                  if (sheetFormKey.currentState?.validate() ?? false) {
                    Navigator.of(sheetCtx).pop(true);
                  }
                },
              ),
            ],
          ),
        ),
      ),
    );

    if (!mounted || proceed != true) return;

    final vm = context.read<MotoHubViewModel>();
    final ok = await vm.signInStaffWithGoogle(
      email: emailInput.trim(),
      displayName: nameInput.trim(),
    );

    if (!mounted) return;
    if (ok) {
      Navigator.of(context).pushReplacement(
        MaterialPageRoute(builder: (_) => const RoleRouterScreen()),
      );
    } else {
      showDialog<void>(
        context: context,
        builder: (ctx) => AlertDialog(
          backgroundColor: AppPalette.mantle,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(20),
            side: const BorderSide(color: AppPalette.danger, width: 1.5),
          ),
          title: const Row(
            children: [
              Icon(Icons.gpp_bad_rounded, color: AppPalette.danger, size: 26),
              SizedBox(width: 8),
              Expanded(
                child: Text(
                  'Access Denied: Account Not Found',
                  style: TextStyle(
                    color: AppPalette.danger,
                    fontSize: 16,
                    fontWeight: FontWeight.w800,
                  ),
                ),
              ),
            ],
          ),
          content: Text(
            'The Google email "${emailInput.trim()}" is not registered by the Admin as an authorized staff account.\n\nPlease contact Boss Arman Sarita to provision your email in the Admin Panel before using Google One-Tap.',
            style: const TextStyle(
              color: AppPalette.textHigh,
              fontSize: 13.5,
              height: 1.45,
            ),
          ),
          actions: [
            FilledButton(
              style: FilledButton.styleFrom(
                backgroundColor: AppPalette.danger,
                foregroundColor: AppPalette.crust,
              ),
              onPressed: () => Navigator.of(ctx).pop(),
              child: const Text('Dismiss'),
            ),
          ],
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final vm = context.watch<MotoHubViewModel>();

    return Scaffold(
      backgroundColor: AppPalette.crust,
      body: SafeArea(
        child: Center(
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 460),
            child: AnimatedSwitcher(
              duration: const Duration(milliseconds: 320),
              switchInCurve: Curves.easeOutCubic,
              switchOutCurve: Curves.easeInCubic,
              child: _showCredentialsForm
                  ? _buildCredentialsStep(context, vm)
                  : _buildTerminalLandingStep(context, vm),
            ),
          ),
        ),
      ),
    );
  }

  /// Screen 2 from User's Figma Image:
  /// "Staff & Management" / "Choose an action to access the terminal." / "Log In to Account"
  Widget _buildTerminalLandingStep(
    BuildContext context,
    MotoHubViewModel vm,
  ) {
    return LayoutBuilder(
      key: const ValueKey('landing_step'),
      builder: (context, constraints) {
        return SingleChildScrollView(
          padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 24),
          child: ConstrainedBox(
            constraints: BoxConstraints(
              minHeight: (constraints.maxHeight - 48).clamp(0.0, double.infinity),
            ),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                const SizedBox(height: 8),
                Column(
                  children: [
                    // Rounded Square Icon Box with Gold Ring
                    Container(
                      width: 76,
                      height: 76,
                      decoration: BoxDecoration(
                        color: AppPalette.mantle,
                        borderRadius: BorderRadius.circular(22),
                        border: Border.all(
                          color: AppPalette.warmGold.withValues(alpha: 0.35),
                          width: 1.2,
                        ),
                        boxShadow: [
                          BoxShadow(
                            color: AppPalette.champagneGold.withValues(alpha: 0.08),
                            blurRadius: 24,
                            offset: const Offset(0, 8),
                          ),
                        ],
                      ),
                      child: Center(
                        child: Container(
                          width: 30,
                          height: 30,
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            border: Border.all(
                              color: AppPalette.champagneGold,
                              width: 2.4,
                            ),
                          ),
                        ),
                      ),
                    ),
                    const SizedBox(height: 24),
                    const Text(
                      'Staff & Management',
                      textAlign: TextAlign.center,
                      style: TextStyle(
                        color: AppPalette.textHigh,
                        fontSize: 23,
                        fontWeight: FontWeight.w800,
                        letterSpacing: -0.3,
                      ),
                    ),
                    const SizedBox(height: 8),
                    const Text(
                      'Choose an action to access the internal ERP/POS terminal.',
                      textAlign: TextAlign.center,
                      style: TextStyle(
                        color: AppPalette.textMuted,
                        fontSize: 13.5,
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 28),

                Column(
                  children: [
                    // Google One-Tap Card for Staff
                    Card.filled(
                      color: AppPalette.mantle,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(16),
                        side: BorderSide(
                          color: AppPalette.champagneGold.withValues(alpha: 0.4),
                        ),
                      ),
                      child: InkWell(
                        borderRadius: BorderRadius.circular(16),
                        onTap: vm.viewState == ViewState.loading
                            ? null
                            : _openGoogleOneTapModal,
                        child: Padding(
                          padding: const EdgeInsets.symmetric(
                            horizontal: 16,
                            vertical: 14,
                          ),
                          child: Row(
                            children: [
                              Container(
                                width: 36,
                                height: 36,
                                decoration: BoxDecoration(
                                  shape: BoxShape.circle,
                                  color: AppPalette.surface1,
                                  border: Border.all(
                                    color: AppPalette.champagneGold.withValues(alpha: 0.5),
                                  ),
                                ),
                                child: const Center(
                                  child: Text(
                                    'G',
                                    style: TextStyle(
                                      color: AppPalette.champagneGold,
                                      fontSize: 18,
                                      fontWeight: FontWeight.w900,
                                    ),
                                  ),
                                ),
                              ),
                              const SizedBox(width: 14),
                              const Expanded(
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(
                                      'Continue with Google One-Tap',
                                      style: TextStyle(
                                        color: AppPalette.textHigh,
                                        fontSize: 14,
                                        fontWeight: FontWeight.w800,
                                      ),
                                    ),
                                    Text(
                                      'Instant staff sign-in for registered emails',
                                      style: TextStyle(
                                        color: AppPalette.textMuted,
                                        fontSize: 11.5,
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                              const Icon(
                                Icons.arrow_forward_ios_rounded,
                                size: 14,
                                color: AppPalette.champagneGold,
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                    const SizedBox(height: 20),

                    // Divider: OR SIGN IN WITH USERNAME & PASSWORD
                    const Row(
                      children: [
                        Expanded(child: Divider(color: AppPalette.surface0)),
                        Padding(
                          padding: EdgeInsets.symmetric(horizontal: 12),
                          child: Text(
                            'OR SIGN IN WITH PASSWORD',
                            style: TextStyle(
                              color: AppPalette.textMuted,
                              fontSize: 11,
                              fontWeight: FontWeight.w700,
                              letterSpacing: 0.6,
                            ),
                          ),
                        ),
                        Expanded(child: Divider(color: AppPalette.surface0)),
                      ],
                    ),
                    const SizedBox(height: 20),

                    // Primary CTA Button: Log In to Account
                    GoldGradientButton(
                      label: 'Log In to Account',
                      icon: Icons.login_rounded,
                      onPressed: () {
                        setState(() {
                          _showCredentialsForm = true;
                        });
                      },
                    ),
                    const SizedBox(height: 18),

                    Text(
                      'Terminal ID: ${vm.activeBranch.terminalId} • SQLite ACID Engine Ready',
                      textAlign: TextAlign.center,
                      style: const TextStyle(
                        color: AppPalette.inactive,
                        fontSize: 11.5,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  /// Screen 3 from User's Figma Image:
  /// "← Staff Login" / "What's your username and password?" / Outlined Gold Input / "Next →"
  Widget _buildCredentialsStep(
    BuildContext context,
    MotoHubViewModel vm,
  ) {
    return SingleChildScrollView(
      key: const ValueKey('credentials_step'),
      padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 16),
      child: Form(
        key: _formKey,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Top Back Navigation: "← Staff Login"
            InkWell(
              borderRadius: BorderRadius.circular(10),
              onTap: () {
                setState(() {
                  _showCredentialsForm = false;
                });
              },
              child: const Padding(
                padding: EdgeInsets.symmetric(vertical: 8, horizontal: 4),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Icon(
                      Icons.arrow_back_rounded,
                      color: AppPalette.textBody,
                      size: 20,
                    ),
                    SizedBox(width: 10),
                    Text(
                      'Staff Login',
                      style: TextStyle(
                        color: AppPalette.textHigh,
                        fontSize: 15.5,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 20),

            const Text(
              "What's your username and\npassword?",
              style: TextStyle(
                color: AppPalette.textHigh,
                fontSize: 24,
                fontWeight: FontWeight.w800,
                height: 1.25,
                letterSpacing: -0.4,
              ),
            ),
            const SizedBox(height: 8),
            const Text(
              'Enter your registered internal staff username and password to connect.',
              style: TextStyle(
                color: AppPalette.textMuted,
                fontSize: 13.5,
              ),
            ),
            const SizedBox(height: 22),

            // Custom Outlined Gold Input Box for Username (Matching Figma frame)
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
              decoration: BoxDecoration(
                color: AppPalette.mantle,
                borderRadius: BorderRadius.circular(14),
                border: Border.all(
                  color: AppPalette.warmGold.withValues(alpha: 0.75),
                  width: 1.2,
                ),
              ),
              child: Row(
                children: [
                  const Icon(
                    Icons.person_outline_rounded,
                    color: AppPalette.champagneGold,
                    size: 22,
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: TextFormField(
                      controller: _usernameController,
                      validator: AppValidators.username,
                      style: const TextStyle(
                        color: AppPalette.textHigh,
                        fontSize: 14.5,
                        fontWeight: FontWeight.w600,
                      ),
                      decoration: const InputDecoration(
                        labelText: 'Username',
                        labelStyle: TextStyle(
                          color: AppPalette.champagneGold,
                          fontSize: 12,
                          fontWeight: FontWeight.w600,
                        ),
                        hintText: 'Enter store username',
                        filled: false,
                        border: InputBorder.none,
                        enabledBorder: InputBorder.none,
                        focusedBorder: InputBorder.none,
                        errorBorder: InputBorder.none,
                        focusedErrorBorder: InputBorder.none,
                        contentPadding: EdgeInsets.symmetric(vertical: 6),
                      ),
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 14),

            // Custom Outlined Input Box for Password
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
              decoration: BoxDecoration(
                color: AppPalette.mantle,
                borderRadius: BorderRadius.circular(14),
                border: Border.all(
                  color: AppPalette.surface0,
                  width: 1.2,
                ),
              ),
              child: Row(
                children: [
                  const Icon(
                    Icons.lock_outline_rounded,
                    color: AppPalette.champagneGold,
                    size: 21,
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: TextFormField(
                      controller: _passwordController,
                      obscureText: _obscurePassword,
                      validator: AppValidators.password,
                      onFieldSubmitted: (_) => _submitLogin(),
                      style: const TextStyle(
                        color: AppPalette.textHigh,
                        fontSize: 14.5,
                        fontWeight: FontWeight.w600,
                      ),
                      decoration: InputDecoration(
                        labelText: 'Password',
                        labelStyle: const TextStyle(
                          color: AppPalette.champagneGold,
                          fontSize: 12,
                          fontWeight: FontWeight.w600,
                        ),
                        hintText: 'Enter store password',
                        filled: false,
                        border: InputBorder.none,
                        enabledBorder: InputBorder.none,
                        focusedBorder: InputBorder.none,
                        errorBorder: InputBorder.none,
                        focusedErrorBorder: InputBorder.none,
                        contentPadding: const EdgeInsets.symmetric(vertical: 6),
                        suffixIcon: IconButton(
                          onPressed: () {
                            setState(() {
                              _obscurePassword = !_obscurePassword;
                            });
                          },
                          icon: Icon(
                            _obscurePassword
                                ? Icons.visibility_off_outlined
                                : Icons.visibility_outlined,
                            color: AppPalette.textMuted,
                            size: 20,
                          ),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 6),
            Align(
              alignment: Alignment.centerRight,
              child: TextButton(
                onPressed: () => ForgotPasswordScreen.navigate(context),
                child: const Text(
                  'Forgot Password?',
                  style: TextStyle(
                    color: AppPalette.champagneGold,
                    fontSize: 12.5,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ),
            ),
            const SizedBox(height: 16),

            // Bottom "Next ->" Gold Gradient Button matching User's Figma Design
            GoldGradientButton(
              label: 'Next →',
              isLoading: vm.viewState == ViewState.loading,
              onPressed: _submitLogin,
            ),
            const SizedBox(height: 14),

            // Alternative: Sign in with Google One-Tap
            Center(
              child: TextButton.icon(
                onPressed: _openGoogleOneTapModal,
                icon: Container(
                  width: 20,
                  height: 20,
                  decoration: const BoxDecoration(
                    shape: BoxShape.circle,
                    color: AppPalette.surface1,
                  ),
                  child: const Center(
                    child: Text(
                      'G',
                      style: TextStyle(
                        color: AppPalette.champagneGold,
                        fontSize: 12,
                        fontWeight: FontWeight.w900,
                      ),
                    ),
                  ),
                ),
                label: const Text(
                  'Or sign in with Google One-Tap',
                  style: TextStyle(
                    color: AppPalette.champagneGold,
                    fontSize: 13,
                    fontWeight: FontWeight.w700,
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}