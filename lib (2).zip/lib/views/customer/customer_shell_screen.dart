import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../core/theme/app_theme.dart';
import '../../core/utils/formatters.dart';
import '../../models/models.dart';
import '../../viewmodels/motohub_viewmodel.dart';
import '../shared/create_job_order_sheet.dart';
import '../shared/notifications_sheet.dart';
import 'customer_auth_screen.dart';
import '../../core/theme/m3e_motion.dart';

class CustomerShellScreen extends StatefulWidget {
  const CustomerShellScreen({super.key});

  @override
  State<CustomerShellScreen> createState() => _CustomerShellScreenState();
}

class _CustomerShellScreenState extends State<CustomerShellScreen> {
  int _selectedIndex = 0;

  @override
  Widget build(BuildContext context) {
    final vm = context.watch<MotoHubViewModel>();
    final user = vm.currentUser;
    final displayName =
        (user != null && user.fullName.trim().isNotEmpty)
            ? user.fullName
            : 'Rider';

    final tabs = [
      const _CustomerLiveRepairTrackerTab(),
      const _CustomerClickAndCollectTab(),
      const _CustomerProfileTab(),
    ];

    final safeIndex = _selectedIndex.clamp(0, tabs.length - 1);

    return Scaffold(
      backgroundColor: AppPalette.crust,
      appBar: AppBar(
        titleSpacing: 14,
        title: Row(
          children: [
            Container(
              padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(
                color: AppPalette.surface1,
                borderRadius: BorderRadius.circular(10),
                border: Border.all(
                  color: AppPalette.champagneGold.withValues(alpha: 0.4),
                ),
              ),
              child: const Icon(
                Icons.two_wheeler_rounded,
                color: AppPalette.champagneGold,
                size: 20,
              ),
            ),
            const SizedBox(width: 10),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Rider Portal • $displayName',
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(
                      color: AppPalette.textHigh,
                      fontSize: 15,
                      fontWeight: FontWeight.w800,
                    ),
                  ),
                  const Text(
                    'Boss Arman MotoHub • Santa Cruz, Laguna',
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: TextStyle(
                      color: AppPalette.champagneGold,
                      fontSize: 11.5,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
        actions: [
          M3EButton.tonal(
            size: M3EButtonSize.xs,
            onPressed: () => CreateJobOrderSheet.show(
              context,
              defaultCustomerName: user?.fullName ?? '',
              defaultCustomerUsername: user?.username ?? '',
            ),
            icon: const Icon(Icons.calendar_month_outlined, size: 15),
            child: const Text('Book Service'),
          ),
          const NotificationBellAction(
            roleSubtitle: 'Rider Service & Order Alerts',
          ),
          const SizedBox(width: 6),
        ],
      ),
      body: M3ETabSwitcher(index: safeIndex, children: tabs),
      bottomNavigationBar: M3ENavigationBar(
        selectedIndex: safeIndex,
        onDestinationSelected: (i) => setState(() => _selectedIndex = i),
        autoLayout: false,
        layout: M3ENavBarLayout.compact,
        wideDestinationWidth: 168,
        backgroundColor: AppPalette.mantle,
        indicatorColor: AppPalette.surface1,
        destinations: [
          M3ENavigationBarDestination(
            icon: const Icon(Icons.track_changes_outlined),
            selectedIcon: const Icon(Icons.track_changes_rounded),
            label: 'Service Tracker',
            badgeCount:
                vm.customerJobOrders.isNotEmpty ? vm.customerJobOrders.length : null,
          ),
          const M3ENavigationBarDestination(
            icon: Icon(Icons.shopping_bag_outlined),
            selectedIcon: Icon(Icons.shopping_bag_rounded),
            label: 'Click & Collect',
          ),
          M3ENavigationBarDestination(
            icon: const Icon(Icons.person_outline_rounded),
            selectedIcon: const Icon(Icons.person_rounded),
            label: 'My Garage',
            badgeCount: vm.customerClickCollectOrders.isNotEmpty
                ? vm.customerClickCollectOrders.length
                : null,
          ),
        ],
      ),
    );
  }
}

class _CustomerLiveRepairTrackerTab extends StatelessWidget {
  const _CustomerLiveRepairTrackerTab();

  @override
  Widget build(BuildContext context) {
    final vm = context.watch<MotoHubViewModel>();
    final user = vm.currentUser;
    final jobs = vm.customerJobOrders;

    return ListView(
      padding: const EdgeInsets.fromLTRB(16, 14, 16, 96),
      children: [
        // Branch Selector (Material 3 Expressive M3ESegmentedButton)
        M3ESegmentedButton<BranchId>(
          segments: const [
            M3ESegment(
              value: BranchId.patimbao,
              label: 'Branch 1: Patimbao',
              icon: Icon(Icons.storefront_rounded, size: 16),
            ),
            M3ESegment(
              value: BranchId.pedroGuevara,
              label: 'Branch 2: P. Guevara',
              icon: Icon(Icons.location_on_outlined, size: 16),
            ),
          ],
          selected: {vm.activeBranch},
          onSelectionChanged: (set) {
            if (set.isNotEmpty) vm.setActiveBranch(set.first);
          },
        ),
        const SizedBox(height: 14),

        GoldGradientButton(
          label: '+ Schedule New Service Appointment',
          icon: Icons.calendar_today_rounded,
          onPressed: () => CreateJobOrderSheet.show(
            context,
            defaultCustomerName: user?.fullName ?? '',
            defaultCustomerUsername: user?.username ?? '',
          ),
        ),
        const SizedBox(height: 18),
        const Text(
          'LIVE BAY REPAIR STATUS TRACKER',
          style: TextStyle(
            color: AppPalette.textMuted,
            fontSize: 11,
            fontWeight: FontWeight.w800,
            letterSpacing: 0.6,
          ),
        ),
        const SizedBox(height: 8),

        // Material 3 Expressive M3ECardList for Live Repair Status
        M3ECardList(
          itemCount: jobs.length,
          outerRadius: 24,
          innerRadius: 6,
          gap: 4,
          variant: M3ECardVariant.filled,
          color: AppPalette.mantle,
          border: const BorderSide(color: AppPalette.surface0),
          padding: const EdgeInsets.all(16),
          emptyBuilder: MotoHubEmptyState(
            icon: Icons.build_circle_outlined,
            title: 'No Active Service Appointments',
            subtitle:
                'You have no active motorcycle repair tickets yet. Book a bay appointment at Patimbao or Pedro Guevara Ave to track live repair progress.',
            actionLabel: 'Book Service Appointment',
            onAction: () => CreateJobOrderSheet.show(
              context,
              defaultCustomerName: user?.fullName ?? '',
              defaultCustomerUsername: user?.username ?? '',
            ),
          ),
          itemBuilder: (context, index) {
            final job = jobs[index];
            final currentStep = job.status.stepIndex;
            return Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Wrap(
                  spacing: 8,
                  runSpacing: 6,
                  alignment: WrapAlignment.spaceBetween,
                  crossAxisAlignment: WrapCrossAlignment.center,
                  children: [
                    Text(
                      '${job.id} • ${job.plateNumber}',
                      style: const TextStyle(
                        color: AppPalette.champagneGold,
                        fontWeight: FontWeight.w800,
                      ),
                    ),
                    Container(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 10,
                        vertical: 4,
                      ),
                      decoration: BoxDecoration(
                        color: AppPalette.surface1,
                        borderRadius: BorderRadius.circular(8),
                        border: Border.all(color: AppPalette.champagneGold),
                      ),
                      child: Text(
                        job.status.label,
                        style: const TextStyle(
                          color: AppPalette.champagneGold,
                          fontWeight: FontWeight.w800,
                          fontSize: 11.5,
                        ),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 8),
                Text(
                  job.bikeModel,
                  style: const TextStyle(
                    color: AppPalette.textHigh,
                    fontSize: 16,
                    fontWeight: FontWeight.w800,
                  ),
                ),
                Text(
                  '${job.branch.displayName} • Mechanic: ${job.assignedMechanic}',
                  style: const TextStyle(
                    color: AppPalette.textMuted,
                    fontSize: 12,
                  ),
                ),
                const SizedBox(height: 12),

                // 5-Stage Progress Bar
                Row(
                  children: List.generate(JobStatus.values.length, (i) {
                    final reached = i <= currentStep;
                    return Expanded(
                      child: Column(
                        children: [
                          Container(
                            margin: const EdgeInsets.symmetric(horizontal: 2),
                            height: 6,
                            decoration: BoxDecoration(
                              color: reached
                                  ? AppPalette.success
                                  : AppPalette.surface0,
                              borderRadius: BorderRadius.circular(4),
                            ),
                          ),
                          const SizedBox(height: 4),
                          Text(
                            JobStatus.values[i].label.split(' ').first,
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: TextStyle(
                              color: reached
                                  ? AppPalette.textHigh
                                  : AppPalette.inactive,
                              fontSize: 9.5,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                        ],
                      ),
                    );
                  }),
                ),
                const Divider(height: 22),

                // Itemized Parts & Labor Breakdown
                ...job.attachedParts.map(
                  (p) => Padding(
                    padding: const EdgeInsets.only(bottom: 4),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Expanded(
                          child: Text(
                            '${p.quantity}x ${p.name}',
                            style: const TextStyle(
                              color: AppPalette.textBody,
                              fontSize: 12.5,
                            ),
                          ),
                        ),
                        const SizedBox(width: 8),
                        Text(
                          AppFormatters.currency(p.lineTotal),
                          style: const TextStyle(
                            color: AppPalette.textHigh,
                            fontWeight: FontWeight.w700,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    const Text(
                      'Service Labor Fee:',
                      style: TextStyle(
                        color: AppPalette.textMuted,
                        fontSize: 12.5,
                      ),
                    ),
                    Text(
                      AppFormatters.currency(job.effectiveLaborFee),
                      style: const TextStyle(
                        color: AppPalette.champagneGold,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                  ],
                ),

                // Extra Repair Approval Prompt
                if (job.extraRepairNote != null &&
                    !job.extraRepairApproved) ...[
                  const SizedBox(height: 12),
                  Container(
                    padding: const EdgeInsets.all(12),
                    decoration: BoxDecoration(
                      color: AppPalette.surface1,
                      borderRadius: BorderRadius.circular(14),
                      border: Border.all(color: AppPalette.warning),
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'Mechanic Recommendation: ${job.extraRepairNote}',
                          style: const TextStyle(
                            color: AppPalette.warning,
                            fontWeight: FontWeight.w700,
                            fontSize: 12.5,
                          ),
                        ),
                        const SizedBox(height: 8),
                        M3EButton.filled(
                          size: M3EButtonSize.xs,
                          onPressed: () async {
                            await vm.approveCustomerExtraRepair(job.id);
                            if (!context.mounted) return;
                            ScaffoldMessenger.of(context).showSnackBar(
                              SnackBar(
                                content: Text(
                                  vm.statusMessage ??
                                      'Approved extra repair for ${job.id}',
                                ),
                              ),
                            );
                          },
                          icon: const Icon(
                            Icons.thumb_up_alt_outlined,
                            size: 16,
                          ),
                          child: Text(
                            'Approve Extra Repair (+${AppFormatters.currency(job.extraRepairFee, showDecimals: false)})',
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ],
            );
          },
        ),
      ],
    );
  }
}

class _CustomerClickAndCollectTab extends StatelessWidget {
  const _CustomerClickAndCollectTab();

  Future<void> _reservePartModal(
    BuildContext context,
    MotoHubViewModel vm,
    InventoryItem item,
  ) async {
    BranchId selectedBranch = vm.activeBranch;
    if (item.availableStockFor(selectedBranch) <= 0) {
      selectedBranch = selectedBranch == BranchId.patimbao
          ? BranchId.pedroGuevara
          : BranchId.patimbao;
    }

    int qty = 1;
    String phoneInput = '';
    final formKey = GlobalKey<FormState>();

    final confirmed = await showModalBottomSheet<bool>(
      context: context,
      isScrollControlled: true,
      backgroundColor: AppPalette.mantle,
      builder: (sheetCtx) {
        return StatefulBuilder(
          builder: (sheetCtx, setModalState) {
            final maxAvail = item.availableStockFor(selectedBranch);
            return Padding(
              padding: EdgeInsets.only(
                left: 20,
                right: 20,
                top: 16,
                bottom: MediaQuery.of(sheetCtx).viewInsets.bottom + 24,
              ),
              child: SingleChildScrollView(
                child: Form(
                  key: formKey,
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text(
                        'Click & Collect Reservation',
                        style: TextStyle(
                          color: AppPalette.textHigh,
                          fontSize: 17,
                          fontWeight: FontWeight.w800,
                        ),
                      ),
                      const SizedBox(height: 4),
                      Text(
                        '${item.name} • ${AppFormatters.currency(item.price)}',
                        style: const TextStyle(
                          color: AppPalette.champagneGold,
                          fontWeight: FontWeight.w700,
                        ),
                      ),
                      const SizedBox(height: 14),
                      M3ESegmentedButton<BranchId>(
                        segments: [
                          M3ESegment(
                            value: BranchId.patimbao,
                            label:
                                'Patimbao (${item.availableStockFor(BranchId.patimbao)})',
                          ),
                          M3ESegment(
                            value: BranchId.pedroGuevara,
                            label:
                                'P. Guevara (${item.availableStockFor(BranchId.pedroGuevara)})',
                          ),
                        ],
                        selected: {selectedBranch},
                        onSelectionChanged: (set) {
                          if (set.isEmpty) return;
                          setModalState(() {
                            selectedBranch = set.first;
                            if (qty > item.availableStockFor(selectedBranch)) {
                              qty = 1;
                            }
                          });
                        },
                      ),
                      const SizedBox(height: 14),
                      TextFormField(
                        onChanged: (v) => phoneInput = v,
                        keyboardType: TextInputType.phone,
                        validator: (v) =>
                            AppValidators.requiredField(v, 'Contact number'),
                        decoration: const InputDecoration(
                          labelText: 'Pickup Contact Number',
                          hintText: '0917-123-4567',
                          prefixIcon: Icon(Icons.phone_outlined),
                        ),
                      ),
                      const SizedBox(height: 14),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          const Text(
                            'Reserve Quantity:',
                            style: TextStyle(
                              color: AppPalette.textHigh,
                              fontWeight: FontWeight.w700,
                            ),
                          ),
                          Row(
                            children: [
                              IconButton(
                                onPressed: qty > 1
                                    ? () => setModalState(() => qty--)
                                    : null,
                                icon: const Icon(Icons.remove_circle_outline),
                              ),
                              Text(
                                '$qty',
                                style: const TextStyle(
                                  color: AppPalette.champagneGold,
                                  fontSize: 16,
                                  fontWeight: FontWeight.w800,
                                ),
                              ),
                              IconButton(
                                onPressed: qty < maxAvail
                                    ? () => setModalState(() => qty++)
                                    : null,
                                icon: const Icon(Icons.add_circle_outline),
                              ),
                            ],
                          ),
                        ],
                      ),
                      const SizedBox(height: 16),
                      GoldGradientButton(
                        label:
                            'Confirm Reservation (${AppFormatters.currency(item.price * qty)})',
                        icon: Icons.shopping_bag_outlined,
                        onPressed: maxAvail > 0
                            ? () {
                                if (formKey.currentState?.validate() ?? false) {
                                  Navigator.of(sheetCtx).pop(true);
                                }
                              }
                            : null,
                      ),
                    ],
                  ),
                ),
              ),
            );
          },
        );
      },
    );

    final phone = phoneInput.trim();
    if (confirmed != true || !context.mounted) return;

    final order = await vm.createClickAndCollectOrder(
      part: item,
      quantity: qty,
      pickupBranch: selectedBranch,
      customerPhone: phone,
    );

    if (!context.mounted) return;
    if (order != null) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            'Reserved ${qty}x ${item.name} (${order.id}) at ${selectedBranch.shortName}',
          ),
        ),
      );
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          backgroundColor: AppPalette.danger,
          content: Text(
            vm.statusMessage ?? 'Failed to reserve part.',
            style: const TextStyle(color: AppPalette.crust),
          ),
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final vm = context.watch<MotoHubViewModel>();
    final items = vm.filteredInventory;

    return ListView(
      padding: const EdgeInsets.fromLTRB(16, 14, 16, 96),
      children: [
        SearchBar(
          hintText: 'Search parts & reserve for Click & Collect...',
          backgroundColor: const WidgetStatePropertyAll(AppPalette.mantle),
          leading: const Icon(
            Icons.search_rounded,
            color: AppPalette.champagneGold,
          ),
          onChanged: vm.setInventorySearchQuery,
        ),
        const SizedBox(height: 14),

        M3ECardList(
          itemCount: items.length,
          outerRadius: 24,
          innerRadius: 6,
          gap: 4,
          variant: M3ECardVariant.filled,
          color: AppPalette.mantle,
          border: const BorderSide(color: AppPalette.surface0),
          padding: const EdgeInsets.all(14),
          emptyBuilder: MotoHubEmptyState(
            icon: Icons.inventory_2_outlined,
            title: 'No Catalog Items Found',
            subtitle: vm.allInventory.isEmpty
                ? 'The store inventory catalog is currently empty. Once the shop admin stocks parts, they will appear here for live Click & Collect reservation.'
                : 'No parts matched your current search query.',
            actionLabel:
                vm.inventorySearchQuery.isNotEmpty ? 'Clear Search' : null,
            onAction: vm.inventorySearchQuery.isNotEmpty
                ? () => vm.setInventorySearchQuery('')
                : null,
          ),
          itemBuilder: (context, index) {
            final item = items[index];
            final patAvail = item.availableStockFor(BranchId.patimbao);
            final pgvAvail = item.availableStockFor(BranchId.pedroGuevara);
            final totalAvail = patAvail + pgvAvail;
            return Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Expanded(
                      child: Text(
                        item.name,
                        style: const TextStyle(
                          color: AppPalette.textHigh,
                          fontSize: 15,
                          fontWeight: FontWeight.w800,
                        ),
                      ),
                    ),
                    const SizedBox(width: 8),
                    Text(
                      AppFormatters.currency(item.price),
                      style: const TextStyle(
                        color: AppPalette.champagneGold,
                        fontSize: 16,
                        fontWeight: FontWeight.w900,
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 4),
                Text(
                  'Compatible: ${item.compatibleModels}',
                  style: const TextStyle(
                    color: AppPalette.textMuted,
                    fontSize: 12,
                  ),
                ),
                const SizedBox(height: 10),
                Wrap(
                  spacing: 8,
                  runSpacing: 8,
                  children: [
                    Container(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 10,
                        vertical: 6,
                      ),
                      decoration: BoxDecoration(
                        color: AppPalette.crust,
                        borderRadius: BorderRadius.circular(8),
                      ),
                      child: Text(
                        'Branch 1 (Patimbao): ${patAvail > 0 ? "$patAvail In-Stock" : "Out of Stock"}',
                        style: TextStyle(
                          color: patAvail > 0
                              ? AppPalette.success
                              : AppPalette.danger,
                          fontSize: 11.5,
                          fontWeight: FontWeight.w700,
                        ),
                      ),
                    ),
                    Container(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 10,
                        vertical: 6,
                      ),
                      decoration: BoxDecoration(
                        color: AppPalette.crust,
                        borderRadius: BorderRadius.circular(8),
                      ),
                      child: Text(
                        'Branch 2 (P. Guevara): ${pgvAvail > 0 ? "$pgvAvail In-Stock" : "Out of Stock"}',
                        style: TextStyle(
                          color: pgvAvail > 0
                              ? AppPalette.success
                              : AppPalette.danger,
                          fontSize: 11.5,
                          fontWeight: FontWeight.w700,
                        ),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 12),
                Align(
                  alignment: Alignment.centerRight,
                  child: M3EButton.filled(
                    size: M3EButtonSize.xs,
                    onPressed: totalAvail > 0
                        ? () => _reservePartModal(context, vm, item)
                        : null,
                    icon: const Icon(
                      Icons.shopping_bag_outlined,
                      size: 16,
                    ),
                    child: const Text('Reserve Click & Collect'),
                  ),
                ),
              ],
            );
          },
        ),
      ],
    );
  }
}

class _CustomerProfileTab extends StatelessWidget {
  const _CustomerProfileTab();

  @override
  Widget build(BuildContext context) {
    final vm = context.watch<MotoHubViewModel>();
    final user = vm.currentUser;
    final reservations = vm.customerClickCollectOrders;

    return ListView(
      padding: const EdgeInsets.fromLTRB(16, 16, 16, 96),
      children: [
        M3ECard(
          variant: M3ECardVariant.filled,
          color: AppPalette.mantle,
          borderRadius: BorderRadius.circular(24),
          border: const BorderSide(color: AppPalette.surface0),
          padding: const EdgeInsets.all(16),
          child: Wrap(
            spacing: 14,
            runSpacing: 12,
            crossAxisAlignment: WrapCrossAlignment.center,
            alignment: WrapAlignment.spaceBetween,
            children: [
              Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  const CircleAvatar(
                    radius: 26,
                    backgroundColor: AppPalette.surface1,
                    child: Icon(
                      Icons.two_wheeler_rounded,
                      color: AppPalette.champagneGold,
                    ),
                  ),
                  const SizedBox(width: 14),
                  Flexible(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          user?.fullName ?? 'Registered Rider',
                          style: const TextStyle(
                            color: AppPalette.textHigh,
                            fontSize: 17,
                            fontWeight: FontWeight.w800,
                          ),
                        ),
                        Text(
                          '@${user?.username ?? "rider"} • ${user?.email ?? ""}',
                          style: const TextStyle(
                            color: AppPalette.textMuted,
                            fontSize: 12,
                          ),
                        ),
                        const SizedBox(height: 2),
                        Text(
                          'Auth Provider: ${(user?.authProvider ?? "password").toUpperCase()}',
                          style: const TextStyle(
                            color: AppPalette.champagneGold,
                            fontSize: 11.5,
                            fontWeight: FontWeight.w700,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
              M3EButton.outlined(
                size: M3EButtonSize.sm,
                onPressed: () async {
                  await vm.logout();
                  if (!context.mounted) return;
                  Navigator.of(context).pushAndRemoveUntil(
                    MaterialPageRoute(
                      builder: (_) => const CustomerAuthScreen(),
                    ),
                    (r) => false,
                  );
                },
                icon: const Icon(Icons.logout_rounded, size: 16),
                child: const Text('Sign Out'),
              ),
            ],
          ),
        ),
        const SizedBox(height: 20),
        const Text(
          'MY CLICK & COLLECT RESERVATIONS',
          style: TextStyle(
            color: AppPalette.textMuted,
            fontSize: 11,
            fontWeight: FontWeight.w800,
            letterSpacing: 0.6,
          ),
        ),
        const SizedBox(height: 10),
        M3ECardList(
          itemCount: reservations.length,
          outerRadius: 24,
          innerRadius: 6,
          gap: 3,
          variant: M3ECardVariant.filled,
          color: AppPalette.mantle,
          border: const BorderSide(color: AppPalette.surface0),
          emptyBuilder: const MotoHubEmptyState(
            icon: Icons.shopping_bag_outlined,
            title: 'No Click & Collect Orders Yet',
            subtitle:
                'Parts you reserve in the Click & Collect tab will appear here with your pickup reference number and branch status.',
          ),
          itemBuilder: (context, index) {
            final order = reservations[index];
            return M3EListItem(
              overline:
                  '${order.id} • ${order.pickupBranch.shortName.toUpperCase()}',
              headline: '${order.quantity}x ${order.partName}',
              supportingText:
                  'Status: ${order.status} • Contact: ${order.customerPhone}',
              leading: const CircleAvatar(
                backgroundColor: AppPalette.surface1,
                child: Icon(
                  Icons.shopping_bag_outlined,
                  color: AppPalette.champagneGold,
                  size: 18,
                ),
              ),
              trailing: Text(
                AppFormatters.currency(order.totalAmount),
                style: const TextStyle(
                  color: AppPalette.champagneGold,
                  fontWeight: FontWeight.w800,
                ),
              ),
            );
          },
        ),
      ],
    );
  }
}
