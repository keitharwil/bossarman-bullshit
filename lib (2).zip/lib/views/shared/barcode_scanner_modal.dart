import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:mobile_scanner/mobile_scanner.dart';
import 'package:provider/provider.dart';
import 'package:qr_flutter/qr_flutter.dart';
import 'package:url_launcher/url_launcher.dart';
import '../../core/models/models.dart';
import '../../core/theme/app_theme.dart';
import '../../core/utils/formatters.dart';
import '../../viewmodels/motohub_viewmodel.dart';
import 'receipt_preview_modal.dart';

/// Live Camera QR/Barcode Scanner HUD powered by `mobile_scanner` with
/// Instant Shelf Bin Coordinate Locator (`Rack B • Shelf 2 • Bin 04`) and
/// Material 3 Expressive (`M3ECard`, `M3EButton`) action triggers for POS / Mechanic / Admin.
class BarcodeScannerModal extends StatefulWidget {
  final String? targetJobOrderId;
  final bool autoAddToPosCart;

  const BarcodeScannerModal({
    super.key,
    this.targetJobOrderId,
    this.autoAddToPosCart = false,
  });

  static Future<InventoryItem?> show(
    BuildContext context, {
    String? targetJobOrderId,
    bool autoAddToPosCart = false,
  }) {
    return showModalBottomSheet<InventoryItem>(
      context: context,
      isScrollControlled: true,
      backgroundColor: AppPalette.mantle,
      builder: (_) => BarcodeScannerModal(
        targetJobOrderId: targetJobOrderId,
        autoAddToPosCart: autoAddToPosCart,
      ),
    );
  }

  @override
  State<BarcodeScannerModal> createState() => _BarcodeScannerModalState();
}

class _BarcodeScannerModalState extends State<BarcodeScannerModal>
    with SingleTickerProviderStateMixin {
  late final AnimationController _laserController;
  late final MobileScannerController _scannerController;
  final TextEditingController _codeController = TextEditingController();
  InventoryItem? _scannedItem;
  bool _torchEnabled = false;
  String? _lastDetectedRawCode;
  DateTime? _lastDetectedAt;

  @override
  void initState() {
    super.initState();
    _laserController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1600),
    )..repeat(reverse: true);

    _scannerController = MobileScannerController(
      detectionSpeed: DetectionSpeed.normal,
      facing: CameraFacing.back,
      torchEnabled: false,
    );
  }

  @override
  void dispose() {
    _laserController.dispose();
    _scannerController.dispose();
    _codeController.dispose();
    super.dispose();
  }

  void _onBarcodeDetect(BarcodeCapture capture, MotoHubViewModel vm) {
    for (final barcode in capture.barcodes) {
      final raw = barcode.rawValue?.trim();
      if (raw != null && raw.isNotEmpty) {
        final now = DateTime.now();
        if (_lastDetectedRawCode == raw &&
            _lastDetectedAt != null &&
            now.difference(_lastDetectedAt!).inMilliseconds < 1800) {
          return;
        }
        _lastDetectedRawCode = raw;
        _lastDetectedAt = now;
        _handleScanCode(vm, raw, fromCamera: true);
        break;
      }
    }
  }

  void _handleScanCode(
    MotoHubViewModel vm,
    String code, {
    bool fromCamera = false,
  }) {
    final trimmed = code.trim();
    if (trimmed.isEmpty) return;

    String resolvedSku = trimmed;
    if (trimmed.startsWith('{') && trimmed.endsWith('}')) {
      try {
        final decoded = jsonDecode(trimmed);
        if (decoded is Map && decoded['sku'] != null) {
          resolvedSku = decoded['sku'].toString().trim();
        }
      } catch (_) {}
    }

    final found = vm.findPartByCode(resolvedSku) ?? vm.findPartByCode(trimmed);
    if (fromCamera && found != null) {
      HapticFeedback.mediumImpact();
    }

    if (!mounted) return;
    setState(() {
      _scannedItem = found;
      _codeController.text = resolvedSku;
    });
    if (found == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('No part matched QR/barcode/SKU "$trimmed"'),
          backgroundColor: AppPalette.danger,
        ),
      );
      return;
    }

    if (fromCamera && widget.autoAddToPosCart) {
      final avail = found.availableStockFor(vm.activeBranch);
      if (avail > 0) {
        vm.addToCart(found);
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(
              'QR Scanned: Added ${found.name} (${found.shortShelfCoordinates}) to POS Cart',
            ),
          ),
        );
      }
    }
  }

  Future<void> _toggleTorch() async {
    try {
      await _scannerController.toggleTorch();
      if (!mounted) return;
      setState(() {
        _torchEnabled = !_torchEnabled;
      });
    } catch (_) {
      if (!mounted) return;
      setState(() {
        _torchEnabled = !_torchEnabled;
      });
    }
  }

  Future<void> _switchCamera() async {
    try {
      await _scannerController.switchCamera();
    } catch (_) {
      // Ignore on single-camera or desktop devices
    }
  }

  @override
  Widget build(BuildContext context) {
    final vm = context.watch<MotoHubViewModel>();
    final InventoryItem? rawItem = _scannedItem ??
        (vm.allInventory.isNotEmpty ? vm.allInventory.first : null);
    final InventoryItem? item = rawItem == null
        ? null
        : vm.allInventory.firstWhere(
            (i) => i.id == rawItem.id,
            orElse: () => rawItem,
          );
    final availActive = item?.availableStockFor(vm.activeBranch) ?? 0;

    final hasCartItems = vm.cartItemCount > 0;

    return DraggableScrollableSheet(
      initialChildSize: 0.90,
      minChildSize: 0.65,
      maxChildSize: 0.96,
      expand: false,
      builder: (context, scrollController) {
        return Stack(
          children: [
            Padding(
              padding: EdgeInsets.only(
                left: 20,
                right: 20,
                top: 14,
                bottom: MediaQuery.of(context).viewInsets.bottom +
                    (hasCartItems ? 125 : 20),
              ),
              child: ListView(
                controller: scrollController,
                children: [
                  // Drag Handle
                  Center(
                    child: Container(
                      width: 44,
                      height: 4,
                      decoration: BoxDecoration(
                        color: AppPalette.surface0,
                        borderRadius: BorderRadius.circular(4),
                      ),
                    ),
                  ),
              const SizedBox(height: 14),

              // Header
              Row(
                children: [
                  Container(
                    padding: const EdgeInsets.all(10),
                    decoration: BoxDecoration(
                      color: AppPalette.surface1,
                      borderRadius: BorderRadius.circular(14),
                      border: Border.all(
                        color: AppPalette.champagneGold.withValues(alpha: 0.4),
                      ),
                    ),
                    child: const Icon(
                      Icons.qr_code_scanner_rounded,
                      color: AppPalette.champagneGold,
                      size: 22,
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Text(
                          'Live QR / Barcode & Shelf HUD',
                          style: TextStyle(
                            color: AppPalette.textHigh,
                            fontSize: 17,
                            fontWeight: FontWeight.w800,
                          ),
                        ),
                        Text(
                          'Active Terminal: ${vm.activeBranch.displayName}',
                          style: const TextStyle(
                            color: AppPalette.textMuted,
                            fontSize: 12,
                          ),
                        ),
                      ],
                    ),
                  ),
                  IconButton(
                    tooltip: 'Switch Camera',
                    onPressed: _switchCamera,
                    icon: const Icon(
                      Icons.cameraswitch_rounded,
                      color: AppPalette.textBody,
                    ),
                  ),
                  IconButton(
                    tooltip: 'Toggle Torch',
                    onPressed: _toggleTorch,
                    icon: Icon(
                      _torchEnabled
                          ? Icons.flash_on_rounded
                          : Icons.flash_off_rounded,
                      color: _torchEnabled
                          ? AppPalette.champagneGold
                          : AppPalette.textMuted,
                    ),
                  ),
                  IconButton(
                    onPressed: () => Navigator.of(context).pop(),
                    icon: const Icon(Icons.close_rounded),
                  ),
                ],
              ),
              const SizedBox(height: 16),

              // Live MobileScanner Camera Viewfinder with Animated Laser & Bin HUD Overlay
              Container(
                height: 215,
                decoration: BoxDecoration(
                  color: AppPalette.crust,
                  borderRadius: BorderRadius.circular(22),
                  border: Border.all(
                    color: AppPalette.champagneGold.withValues(alpha: 0.6),
                    width: 1.5,
                  ),
                ),
                clipBehavior: Clip.antiAlias,
                child: Stack(
                  fit: StackFit.expand,
                  children: [
                    // Real MobileScanner camera feed with graceful HUD fallback
                    MobileScanner(
                      controller: _scannerController,
                      onDetect: (capture) => _onBarcodeDetect(capture, vm),
                      errorBuilder: (context, error) {
                        return _buildOpticalGridFallback();
                      },
                      placeholderBuilder: (context) {
                        return _buildOpticalGridFallback();
                      },
                    ),

                    // Subtle Corner Reticle Frame
                    IgnorePointer(
                      child: Padding(
                        padding: const EdgeInsets.symmetric(
                          horizontal: 36,
                          vertical: 34,
                        ),
                        child: Container(
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(14),
                            border: Border.all(
                              color: AppPalette.champagneGold
                                  .withValues(alpha: 0.45),
                              width: 1.2,
                            ),
                          ),
                        ),
                      ),
                    ),

                    // Animated Laser Line
                    AnimatedBuilder(
                      animation: _laserController,
                      builder: (context, _) {
                        return Positioned(
                          top: 28 + (_laserController.value * 140),
                          left: 28,
                          right: 28,
                          child: IgnorePointer(
                            child: Container(
                              height: 2.5,
                              decoration: BoxDecoration(
                                gradient: AppPalette.goldActionGradient,
                                boxShadow: [
                                  BoxShadow(
                                    color: AppPalette.champagneGold
                                        .withValues(alpha: 0.75),
                                    blurRadius: 10,
                                    spreadRadius: 1,
                                  ),
                                ],
                              ),
                            ),
                          ),
                        );
                      },
                    ),

                    // Top Left Camera Pill
                    Positioned(
                      top: 12,
                      left: 12,
                      right: 12,
                      child: Align(
                        alignment: Alignment.topLeft,
                        child: Container(
                          padding: const EdgeInsets.symmetric(
                            horizontal: 10,
                            vertical: 5,
                          ),
                          decoration: BoxDecoration(
                            color: AppPalette.mantle.withValues(alpha: 0.9),
                            borderRadius: BorderRadius.circular(10),
                            border: Border.all(color: AppPalette.surface0),
                          ),
                          child: Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Container(
                                width: 8,
                                height: 8,
                                decoration: BoxDecoration(
                                  color: item != null
                                      ? AppPalette.success
                                      : AppPalette.warning,
                                  shape: BoxShape.circle,
                                ),
                              ),
                              const SizedBox(width: 6),
                              Flexible(
                                child: Text(
                                  item != null
                                      ? 'LIVE QR/BARCODE SCANNER • ${item.barcode}'
                                      : 'LIVE QR/BARCODE SCANNER • READY',
                                  maxLines: 1,
                                  overflow: TextOverflow.ellipsis,
                                  style: const TextStyle(
                                    color: AppPalette.textHigh,
                                    fontSize: 11,
                                    fontWeight: FontWeight.w700,
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),

                    // Bottom Shelf Bin Locator Coordinate Readout
                    Positioned(
                      bottom: 12,
                      left: 12,
                      right: 12,
                      child: Container(
                        padding: const EdgeInsets.symmetric(
                          horizontal: 12,
                          vertical: 8,
                        ),
                        decoration: BoxDecoration(
                          color: AppPalette.surface1.withValues(alpha: 0.95),
                          borderRadius: BorderRadius.circular(12),
                          border: Border.all(
                            color: AppPalette.champagneGold,
                            width: 1,
                          ),
                        ),
                        child: Row(
                          children: [
                            const Icon(
                              Icons.place_rounded,
                              color: AppPalette.champagneGold,
                              size: 18,
                            ),
                            const SizedBox(width: 8),
                            Expanded(
                              child: Text(
                                item != null
                                    ? 'SHELF BIN LOCATOR: ${item.shelfCoordinates}'
                                    : 'SHELF BIN LOCATOR: NO INVENTORY REGISTERED YET',
                                maxLines: 1,
                                overflow: TextOverflow.ellipsis,
                                style: const TextStyle(
                                  color: AppPalette.champagneGold,
                                  fontSize: 12,
                                  fontWeight: FontWeight.w800,
                                  letterSpacing: 0.3,
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 14),

              // Manual Barcode / SKU Search Input
              Row(
                children: [
                  Expanded(
                    child: TextField(
                      controller: _codeController,
                      onSubmitted: (val) => _handleScanCode(vm, val),
                      decoration: const InputDecoration(
                        hintText: 'Enter QR / Barcode (e.g. 88501001) or SKU...',
                        prefixIcon: Icon(
                          Icons.qr_code_2_rounded,
                          color: AppPalette.champagneGold,
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(width: 10),
                  M3EButton.filled(
                    size: M3EButtonSize.md,
                    onPressed: () => _handleScanCode(vm, _codeController.text),
                    icon: const Icon(Icons.search_rounded, size: 18),
                    child: const Text('Lookup'),
                  ),
                ],
              ),
              const SizedBox(height: 14),

              if (item == null)
                MotoHubEmptyState(
                  icon: Icons.inventory_2_outlined,
                  title: 'No Inventory SKUs Registered Yet',
                  subtitle:
                      'Add motorcycle parts or accessories in the Inventory Catalog first to scan QR/barcodes and locate shelf bin coordinates.',
                  actionLabel: 'Close Scanner',
                  onAction: () => Navigator.of(context).pop(),
                )
              else ...[
                // Instant Tap-to-Scan Barcode Deck
                const Text(
                  'QUICK SELECT / SIMULATE QR TAG:',
                  style: TextStyle(
                    color: AppPalette.textMuted,
                    fontSize: 11,
                    fontWeight: FontWeight.w700,
                    letterSpacing: 0.6,
                  ),
                ),
                const SizedBox(height: 8),
                SizedBox(
                  height: 38,
                  child: ListView.separated(
                    scrollDirection: Axis.horizontal,
                    itemCount: vm.allInventory.length,
                    separatorBuilder: (_, index) => const SizedBox(width: 8),
                    itemBuilder: (context, index) {
                      final p = vm.allInventory[index];
                      final isSelected = p.id == item.id;
                      return FilterChip(
                        selected: isSelected,
                        label: Text('${p.sku} • ${p.name.split(" (").first}'),
                        onSelected: (_) {
                          setState(() {
                            _scannedItem = p;
                            _codeController.text = p.barcode;
                          });
                        },
                      );
                    },
                  ),
                ),
                const SizedBox(height: 16),

                // Scanned Part Result Card using Material 3 Expressive M3ECard
                M3ECard(
                  variant: M3ECardVariant.filled,
                  color: AppPalette.crust,
                  borderRadius: BorderRadius.circular(22),
                  border: const BorderSide(
                    color: AppPalette.champagneGold,
                    width: 1.2,
                  ),
                  padding: const EdgeInsets.all(16),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  '${item.sku}  •  QR/EAN: ${item.barcode}',
                                  style: const TextStyle(
                                    color: AppPalette.champagneGold,
                                    fontSize: 11.5,
                                    fontWeight: FontWeight.w700,
                                  ),
                                ),
                                const SizedBox(height: 4),
                                Text(
                                  item.name,
                                  style: const TextStyle(
                                    color: AppPalette.textHigh,
                                    fontSize: 16,
                                    fontWeight: FontWeight.w800,
                                  ),
                                ),
                                const SizedBox(height: 4),
                                Text(
                                  'Fits: ${item.compatibleModels}',
                                  style: const TextStyle(
                                    color: AppPalette.textMuted,
                                    fontSize: 12,
                                  ),
                                ),
                              ],
                            ),
                          ),
                          const SizedBox(width: 8),
                          Text(
                            AppFormatters.currency(item.price),
                            style: const TextStyle(
                              color: AppPalette.champagneGold,
                              fontSize: 18,
                              fontWeight: FontWeight.w800,
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 12),

                      // Warehouse Shelf Bin Coordinates Banner
                      Container(
                        padding: const EdgeInsets.all(10),
                        decoration: BoxDecoration(
                          color: AppPalette.surface1,
                          borderRadius: BorderRadius.circular(12),
                          border: Border.all(color: AppPalette.surface0),
                        ),
                        child: Wrap(
                          spacing: 8,
                          runSpacing: 8,
                          crossAxisAlignment: WrapCrossAlignment.center,
                          alignment: WrapAlignment.spaceBetween,
                          children: [
                            Row(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                const Icon(
                                  Icons.shelves,
                                  color: AppPalette.champagneGold,
                                  size: 18,
                                ),
                                const SizedBox(width: 8),
                                Flexible(
                                  child: Text(
                                    'Location: ${item.shelfCoordinates}',
                                    style: const TextStyle(
                                      color: AppPalette.textHigh,
                                      fontSize: 13,
                                      fontWeight: FontWeight.w700,
                                    ),
                                  ),
                                ),
                              ],
                            ),
                            Container(
                              padding: const EdgeInsets.symmetric(
                                horizontal: 8,
                                vertical: 3,
                              ),
                              decoration: BoxDecoration(
                                color: availActive > 0
                                    ? AppPalette.success.withValues(alpha: 0.18)
                                    : AppPalette.danger.withValues(alpha: 0.18),
                                borderRadius: BorderRadius.circular(6),
                              ),
                              child: Text(
                                (vm.currentUser?.role == UserRole.cashier ||
                                        vm.currentUser?.role ==
                                            UserRole.mechanic)
                                    ? '${vm.activeBranch.displayName}: $availActive In-Stock'
                                    : 'Patimbao: ${item.availableStockFor(BranchId.patimbao)} | P.Guevara: ${item.availableStockFor(BranchId.pedroGuevara)}',
                                style: TextStyle(
                                  color: availActive > 0
                                      ? AppPalette.success
                                      : AppPalette.danger,
                                  fontSize: 11,
                                  fontWeight: FontWeight.w700,
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(height: 14),

                      // Material 3 Expressive Action Buttons based on Context
                      Wrap(
                        spacing: 10,
                        runSpacing: 10,
                        children: [
                          M3EButton.filled(
                            size: M3EButtonSize.sm,
                            onPressed: availActive > 0
                                ? () {
                                    final added = vm.addToCart(item);
                                    if (!added) {
                                      ScaffoldMessenger.of(context)
                                          .showSnackBar(
                                        SnackBar(
                                          backgroundColor: AppPalette.danger,
                                          content: Text(
                                            vm.statusMessage ??
                                                'Could not add part to POS Cart.',
                                            style: const TextStyle(
                                              color: AppPalette.crust,
                                            ),
                                          ),
                                        ),
                                      );
                                      return;
                                    }
                                    Navigator.of(context).pop(item);
                                    ScaffoldMessenger.of(context).showSnackBar(
                                      SnackBar(
                                        content: Text(
                                          'Added ${item.name} (${item.shortShelfCoordinates}) to POS Cart',
                                        ),
                                      ),
                                    );
                                  }
                                : null,
                            icon: const Icon(
                              Icons.add_shopping_cart_rounded,
                              size: 18,
                            ),
                            child: const Text('Add to POS Cart'),
                          ),
                          if (widget.targetJobOrderId != null)
                            M3EButton.tonal(
                              size: M3EButtonSize.sm,
                              onPressed: availActive > 0
                                  ? () async {
                                      final ok = await vm.attachPartToJobOrder(
                                        jobId: widget.targetJobOrderId!,
                                        part: item,
                                      );
                                      if (!context.mounted) return;
                                      if (ok) {
                                        Navigator.of(context).pop(item);
                                      } else {
                                        ScaffoldMessenger.of(context)
                                            .showSnackBar(
                                          SnackBar(
                                            backgroundColor: AppPalette.danger,
                                            content: Text(
                                              vm.statusMessage ??
                                                  'Could not lock part to job order.',
                                              style: const TextStyle(
                                                color: AppPalette.crust,
                                              ),
                                            ),
                                          ),
                                        );
                                      }
                                    }
                                  : null,
                              icon: const Icon(
                                Icons.lock_outline_rounded,
                                size: 18,
                              ),
                              child: Text('Lock to ${widget.targetJobOrderId}'),
                            ),
                          M3EButton.outlined(
                            size: M3EButtonSize.sm,
                            onPressed: () {
                              Navigator.of(context).pop(item);
                            },
                            icon: const Icon(
                              Icons.check_circle_outline,
                              size: 18,
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ],
            ],
          ),
        ),
        if (hasCartItems) _buildFloatingPaymentFlyout(context, vm),
      ],
    );
  },
);
}

  Widget _buildFloatingPaymentFlyout(BuildContext context, MotoHubViewModel vm) {
    final total = vm.cartTotal;
    final count = vm.cartItemCount;

    return Positioned(
      left: 16,
      right: 16,
      bottom: MediaQuery.of(context).viewInsets.bottom + 12,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
        decoration: BoxDecoration(
          color: AppPalette.crust.withValues(alpha: 0.96),
          borderRadius: BorderRadius.circular(20),
          border: Border.all(
            color: AppPalette.champagneGold.withValues(alpha: 0.8),
            width: 1.5,
          ),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withValues(alpha: 0.45),
              blurRadius: 16,
              offset: const Offset(0, 6),
            ),
          ],
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            // Cart Summary Row
            Row(
              children: [
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                  decoration: BoxDecoration(
                    color: AppPalette.champagneGold.withValues(alpha: 0.2),
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      const Icon(
                        Icons.shopping_bag_outlined,
                        color: AppPalette.champagneGold,
                        size: 15,
                      ),
                      const SizedBox(width: 4),
                      Text(
                        '$count ${count == 1 ? "Item" : "Items"}',
                        style: const TextStyle(
                          color: AppPalette.champagneGold,
                          fontSize: 12,
                          fontWeight: FontWeight.w700,
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: Text(
                    'Total: ${AppFormatters.currency(total)}',
                    style: const TextStyle(
                      color: AppPalette.textHigh,
                      fontSize: 15,
                      fontWeight: FontWeight.w800,
                    ),
                  ),
                ),
                TextButton.icon(
                  onPressed: () => _openSplitCheckout(context, vm),
                  icon: const Icon(
                    Icons.call_split_rounded,
                    size: 16,
                    color: AppPalette.champagneGold,
                  ),
                  label: const Text(
                    'Split',
                    style: TextStyle(
                      color: AppPalette.champagneGold,
                      fontSize: 12,
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                  style: TextButton.styleFrom(
                    padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                    minimumSize: Size.zero,
                    tapTargetSize: MaterialTapTargetSize.shrinkWrap,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 10),
            // Floating Payment Controls: Bottom-Left GCash, Bottom-Right Cash
            Row(
              children: [
                // Bottom-Left Button: GCash
                Expanded(
                  child: ElevatedButton.icon(
                    onPressed: () => _openGCashCheckout(context, vm),
                    icon: const Icon(Icons.qr_code_2_rounded, size: 18),
                    label: const Text(
                      'GCash Pay',
                      style: TextStyle(fontWeight: FontWeight.w700),
                    ),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: const Color(0xFF007DFE),
                      foregroundColor: Colors.white,
                      padding: const EdgeInsets.symmetric(vertical: 12),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(14),
                      ),
                      elevation: 2,
                    ),
                  ),
                ),
                const SizedBox(width: 10),
                // Bottom-Right Button: Cash Payment
                Expanded(
                  child: ElevatedButton.icon(
                    onPressed: () => _openCashCheckout(context, vm),
                    icon: const Icon(Icons.payments_outlined, size: 18),
                    label: const Text(
                      'Cash Tender',
                      style: TextStyle(fontWeight: FontWeight.w700),
                    ),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: AppPalette.champagneGold,
                      foregroundColor: AppPalette.crust,
                      padding: const EdgeInsets.symmetric(vertical: 12),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(14),
                      ),
                      elevation: 2,
                    ),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  void _openGCashCheckout(BuildContext context, MotoHubViewModel vm) {
    final refCtrl = TextEditingController();
    bool attachProof = false;
    String? errorText;

    showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      backgroundColor: AppPalette.mantle,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      builder: (bottomSheetCtx) {
        return StatefulBuilder(
          builder: (ctx, setModalState) {
            return Padding(
              padding: EdgeInsets.only(
                left: 20,
                right: 20,
                top: 20,
                bottom: MediaQuery.of(ctx).viewInsets.bottom + 20,
              ),
              child: SingleChildScrollView(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        const Row(
                          children: [
                            Icon(
                              Icons.qr_code_2_rounded,
                              color: Color(0xFF007DFE),
                              size: 24,
                            ),
                            SizedBox(width: 8),
                            Text(
                              'GCash Merchant Checkout',
                              style: TextStyle(
                                color: AppPalette.textHigh,
                                fontSize: 17,
                                fontWeight: FontWeight.w800,
                              ),
                            ),
                          ],
                        ),
                        IconButton(
                          icon: const Icon(Icons.close_rounded),
                          onPressed: () => Navigator.of(bottomSheetCtx).pop(),
                        ),
                      ],
                    ),
                    const Divider(height: 16),
                    Text(
                      'Total Due: ${AppFormatters.currency(vm.cartTotal)}',
                      textAlign: TextAlign.center,
                      style: const TextStyle(
                        color: AppPalette.champagneGold,
                        fontSize: 22,
                        fontWeight: FontWeight.w900,
                      ),
                    ),
                    const SizedBox(height: 12),
                    // GCash QR Code Box
                    Center(
                      child: Container(
                        padding: const EdgeInsets.all(12),
                        decoration: BoxDecoration(
                          color: Colors.white,
                          borderRadius: BorderRadius.circular(16),
                          border: Border.all(
                            color: const Color(0xFF007DFE),
                            width: 2,
                          ),
                        ),
                        child: QrImageView(
                          data:
                              '00020101021226480012com.gcash.qr012409178886686520459995303608540${vm.cartTotal.toStringAsFixed(2)}5802PH5918BossArman MotoHub6009Sta Cruz',
                          version: QrVersions.auto,
                          size: 160,
                        ),
                      ),
                    ),
                    const SizedBox(height: 12),
                    // Direct GCash App Launcher Button
                    OutlinedButton.icon(
                      style: OutlinedButton.styleFrom(
                        foregroundColor: const Color(0xFF007DFE),
                        side: const BorderSide(color: Color(0xFF007DFE)),
                        padding: const EdgeInsets.symmetric(vertical: 11),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12),
                        ),
                      ),
                      icon: const Icon(Icons.open_in_new_rounded, size: 18),
                      label: const Text(
                        'Launch GCash App Directly (gcash://)',
                        style: TextStyle(fontWeight: FontWeight.w700),
                      ),
                      onPressed: () async {
                        final gcashUri = Uri.parse('gcash://');
                        try {
                          final launched = await launchUrl(
                            gcashUri,
                            mode: LaunchMode.externalApplication,
                          );
                          if (!launched) {
                            await launchUrl(
                              Uri.parse('https://m.gcash.com/'),
                              mode: LaunchMode.externalApplication,
                            );
                          }
                        } catch (_) {
                          await launchUrl(
                            Uri.parse('https://m.gcash.com/'),
                            mode: LaunchMode.externalApplication,
                          );
                        }
                      },
                    ),
                    const SizedBox(height: 16),
                    // Reference Number Input Field (Last 4 Digits)
                    TextField(
                      controller: refCtrl,
                      keyboardType: TextInputType.number,
                      maxLength: 4,
                      inputFormatters: [
                        FilteringTextInputFormatter.digitsOnly,
                        LengthLimitingTextInputFormatter(4),
                      ],
                      onChanged: (val) {
                        if (errorText != null) {
                          setModalState(() => errorText = null);
                        }
                      },
                      decoration: InputDecoration(
                        labelText: 'Last 4 Digits of GCash Ref # (Required)',
                        hintText: 'e.g. 4819',
                        prefixIcon: const Icon(Icons.pin_rounded),
                        errorText: errorText,
                      ),
                    ),
                    // Optional Proof Attachment Toggle
                    SwitchListTile(
                      contentPadding: EdgeInsets.zero,
                      activeThumbColor: const Color(0xFF007DFE),
                      title: const Text(
                        'Attach GCash Payment Screenshot',
                        style: TextStyle(fontSize: 13, color: AppPalette.textHigh),
                      ),
                      subtitle: const Text(
                        'Flags transaction with digital proof',
                        style: TextStyle(fontSize: 11, color: AppPalette.textMuted),
                      ),
                      value: attachProof,
                      onChanged: (val) {
                        setModalState(() => attachProof = val);
                      },
                    ),
                    const SizedBox(height: 12),
                    ElevatedButton(
                      style: ElevatedButton.styleFrom(
                        backgroundColor: const Color(0xFF007DFE),
                        foregroundColor: Colors.white,
                        padding: const EdgeInsets.symmetric(vertical: 14),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(14),
                        ),
                      ),
                      onPressed: () async {
                        final ref = refCtrl.text.trim();
                        if (ref.length != 4 || !RegExp(r'^\d{4}$').hasMatch(ref)) {
                          setModalState(() {
                            errorText = 'Enter exactly 4 digits from the GCash SMS/receipt';
                          });
                          return;
                        }

                        final tx = await vm.processRetailCheckout(
                          paymentMethod: PaymentMethod.gcash,
                          amountTendered: vm.cartTotal,
                          gcashAmount: vm.cartTotal,
                          gcashRef: ref,
                          gcashProofUrl: attachProof ? 'gcash_proof_$ref.png' : null,
                        );

                        if (!context.mounted) return;
                        if (tx != null) {
                          Navigator.of(bottomSheetCtx).pop(); // Close checkout sheet
                          Navigator.of(context).pop(); // Close scanner sheet
                          ReceiptPreviewModal.show(context, tx);
                        } else {
                          ScaffoldMessenger.of(context).showSnackBar(
                            SnackBar(
                              backgroundColor: AppPalette.danger,
                              content: Text(
                                vm.statusMessage ?? 'GCash checkout failed.',
                              ),
                            ),
                          );
                        }
                      },
                      child: const Text(
                        'Confirm GCash Verification & Print Receipt',
                        style: TextStyle(
                          fontSize: 14,
                          fontWeight: FontWeight.w800,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            );
          },
        );
      },
    );
  }

  void _openCashCheckout(BuildContext context, MotoHubViewModel vm) {
    final total = vm.cartTotal;
    final tenderCtrl = TextEditingController(text: total.toStringAsFixed(0));
    double tendered = total;

    showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      backgroundColor: AppPalette.mantle,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      builder: (bottomSheetCtx) {
        return StatefulBuilder(
          builder: (ctx, setModalState) {
            final change = tendered - total;
            final isSufficient = change >= 0;

            void applyShortcut(double amount) {
              setModalState(() {
                tendered = amount;
                tenderCtrl.text = amount.toStringAsFixed(0);
              });
            }

            return Padding(
              padding: EdgeInsets.only(
                left: 20,
                right: 20,
                top: 20,
                bottom: MediaQuery.of(ctx).viewInsets.bottom + 20,
              ),
              child: SingleChildScrollView(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        const Row(
                          children: [
                            Icon(
                              Icons.payments_outlined,
                              color: AppPalette.champagneGold,
                              size: 24,
                            ),
                            SizedBox(width: 8),
                            Text(
                              'Cash Tender Calculator',
                              style: TextStyle(
                                color: AppPalette.textHigh,
                                fontSize: 17,
                                fontWeight: FontWeight.w800,
                              ),
                            ),
                          ],
                        ),
                        IconButton(
                          icon: const Icon(Icons.close_rounded),
                          onPressed: () => Navigator.of(bottomSheetCtx).pop(),
                        ),
                      ],
                    ),
                    const Divider(height: 16),
                    Text(
                      'Total Due: ${AppFormatters.currency(total)}',
                      textAlign: TextAlign.center,
                      style: const TextStyle(
                        color: AppPalette.champagneGold,
                        fontSize: 22,
                        fontWeight: FontWeight.w900,
                      ),
                    ),
                    const SizedBox(height: 16),
                    TextField(
                      controller: tenderCtrl,
                      keyboardType: const TextInputType.numberWithOptions(decimal: true),
                      autofocus: true,
                      decoration: const InputDecoration(
                        labelText: 'Cash Tendered Amount (₱)',
                        prefixIcon: Icon(Icons.money_rounded),
                      ),
                      onChanged: (val) {
                        setModalState(() {
                          tendered = double.tryParse(val) ?? 0.0;
                        });
                      },
                    ),
                    const SizedBox(height: 10),
                    // Quick Cash Tender Increment Chips
                    Wrap(
                      spacing: 8,
                      runSpacing: 8,
                      children: [
                        ActionChip(
                          label: const Text('Exact'),
                          onPressed: () => applyShortcut(total),
                        ),
                        ActionChip(
                          label: const Text('+₱50'),
                          onPressed: () => applyShortcut(tendered + 50),
                        ),
                        ActionChip(
                          label: const Text('+₱100'),
                          onPressed: () => applyShortcut(tendered + 100),
                        ),
                        ActionChip(
                          label: const Text('+₱500'),
                          onPressed: () => applyShortcut(tendered + 500),
                        ),
                        ActionChip(
                          label: const Text('+₱1,000'),
                          onPressed: () => applyShortcut(tendered + 1000),
                        ),
                      ],
                    ),
                    const SizedBox(height: 16),
                    // Auto-Calculated Change or Warning
                    Container(
                      padding: const EdgeInsets.all(14),
                      decoration: BoxDecoration(
                        color: isSufficient
                            ? AppPalette.success.withValues(alpha: 0.12)
                            : AppPalette.danger.withValues(alpha: 0.12),
                        borderRadius: BorderRadius.circular(14),
                        border: Border.all(
                          color: isSufficient ? AppPalette.success : AppPalette.danger,
                        ),
                      ),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text(
                            isSufficient ? 'Change Due:' : 'Insufficient Cash:',
                            style: TextStyle(
                              color: isSufficient
                                  ? AppPalette.success
                                  : AppPalette.danger,
                              fontWeight: FontWeight.w700,
                              fontSize: 14,
                            ),
                          ),
                          Text(
                            isSufficient
                                ? AppFormatters.currency(change)
                                : '-${AppFormatters.currency(change.abs())}',
                            style: TextStyle(
                              color: isSufficient
                                  ? AppPalette.success
                                  : AppPalette.danger,
                              fontWeight: FontWeight.w900,
                              fontSize: 18,
                            ),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(height: 18),
                    ElevatedButton(
                      style: ElevatedButton.styleFrom(
                        backgroundColor: AppPalette.champagneGold,
                        foregroundColor: AppPalette.crust,
                        padding: const EdgeInsets.symmetric(vertical: 14),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(14),
                        ),
                      ),
                      onPressed: isSufficient
                          ? () async {
                              final tx = await vm.processRetailCheckout(
                                paymentMethod: PaymentMethod.cash,
                                amountTendered: tendered,
                                cashAmount: total,
                              );

                              if (!context.mounted) return;
                              if (tx != null) {
                                Navigator.of(bottomSheetCtx).pop(); // Close checkout sheet
                                Navigator.of(context).pop(); // Close scanner sheet
                                ReceiptPreviewModal.show(context, tx);
                              } else {
                                ScaffoldMessenger.of(context).showSnackBar(
                                  SnackBar(
                                    backgroundColor: AppPalette.danger,
                                    content: Text(
                                      vm.statusMessage ?? 'Cash checkout failed.',
                                    ),
                                  ),
                                );
                              }
                            }
                          : null,
                      child: const Text(
                        'Complete Cash Tender & Print Receipt',
                        style: TextStyle(
                          fontSize: 14,
                          fontWeight: FontWeight.w800,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            );
          },
        );
      },
    );
  }

  void _openSplitCheckout(BuildContext context, MotoHubViewModel vm) {
    final total = vm.cartTotal;
    final half = (total / 2).roundToDouble();
    final cashCtrl = TextEditingController(text: half.toStringAsFixed(0));
    final gcashCtrl = TextEditingController(text: (total - half).toStringAsFixed(0));
    final cashTenderCtrl = TextEditingController(text: half.toStringAsFixed(0));
    final gcashRefCtrl = TextEditingController();

    showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      backgroundColor: AppPalette.mantle,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      builder: (bottomSheetCtx) {
        return StatefulBuilder(
          builder: (ctx, setModalState) {
            final cashPortion = double.tryParse(cashCtrl.text) ?? 0.0;
            final gcashPortion = double.tryParse(gcashCtrl.text) ?? 0.0;
            final cashTendered = double.tryParse(cashTenderCtrl.text) ?? cashPortion;
            final cashChange = cashTendered - cashPortion;

            final totalPortions = cashPortion + gcashPortion;
            final isSplitSumValid = (totalPortions - total).abs() < 0.05;
            final isTenderValid = cashChange >= 0;
            final isGcashRefValid = RegExp(r'^\d{4}$').hasMatch(gcashRefCtrl.text.trim());
            final canSubmit = isSplitSumValid && isTenderValid && isGcashRefValid;

            return Padding(
              padding: EdgeInsets.only(
                left: 20,
                right: 20,
                top: 20,
                bottom: MediaQuery.of(ctx).viewInsets.bottom + 20,
              ),
              child: SingleChildScrollView(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        const Row(
                          children: [
                            Icon(
                              Icons.call_split_rounded,
                              color: AppPalette.champagneGold,
                              size: 24,
                            ),
                            SizedBox(width: 8),
                            Text(
                              'Split Payment (Cash + GCash)',
                              style: TextStyle(
                                color: AppPalette.textHigh,
                                fontSize: 17,
                                fontWeight: FontWeight.w800,
                              ),
                            ),
                          ],
                        ),
                        IconButton(
                          icon: const Icon(Icons.close_rounded),
                          onPressed: () => Navigator.of(bottomSheetCtx).pop(),
                        ),
                      ],
                    ),
                    const Divider(height: 16),
                    Text(
                      'Total Due: ${AppFormatters.currency(total)}',
                      textAlign: TextAlign.center,
                      style: const TextStyle(
                        color: AppPalette.champagneGold,
                        fontSize: 22,
                        fontWeight: FontWeight.w900,
                      ),
                    ),
                    const SizedBox(height: 14),
                    // Quick Split Buttons
                    Row(
                      children: [
                        Expanded(
                          child: OutlinedButton(
                            onPressed: () {
                              setModalState(() {
                                cashCtrl.text = half.toStringAsFixed(0);
                                gcashCtrl.text = (total - half).toStringAsFixed(0);
                                cashTenderCtrl.text = half.toStringAsFixed(0);
                              });
                            },
                            child: const Text('50 / 50 Split'),
                          ),
                        ),
                        const SizedBox(width: 10),
                        Expanded(
                          child: OutlinedButton(
                            onPressed: () {
                              final c = double.tryParse(cashCtrl.text) ?? 0.0;
                              final rem = (total - c).clamp(0.0, total);
                              setModalState(() {
                                gcashCtrl.text = rem.toStringAsFixed(0);
                              });
                            },
                            child: const Text('Auto-Balance GCash'),
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 14),
                    // Cash Portion
                    TextField(
                      controller: cashCtrl,
                      keyboardType: const TextInputType.numberWithOptions(decimal: true),
                      decoration: const InputDecoration(
                        labelText: 'Cash Amount Portion (₱)',
                        prefixIcon: Icon(Icons.money_rounded),
                      ),
                      onChanged: (_) => setModalState(() {}),
                    ),
                    const SizedBox(height: 10),
                    // Cash Tendered Field
                    TextField(
                      controller: cashTenderCtrl,
                      keyboardType: const TextInputType.numberWithOptions(decimal: true),
                      decoration: InputDecoration(
                        labelText: 'Cash Tendered by Customer (₱)',
                        prefixIcon: const Icon(Icons.payments_rounded),
                        helperText: cashChange >= 0
                            ? 'Cash Change: ${AppFormatters.currency(cashChange)}'
                            : 'Short by ${AppFormatters.currency(cashChange.abs())}',
                        helperStyle: TextStyle(
                          color: cashChange >= 0
                              ? AppPalette.success
                              : AppPalette.danger,
                        ),
                      ),
                      onChanged: (_) => setModalState(() {}),
                    ),
                    const SizedBox(height: 12),
                    // GCash Portion
                    TextField(
                      controller: gcashCtrl,
                      keyboardType: const TextInputType.numberWithOptions(decimal: true),
                      decoration: const InputDecoration(
                        labelText: 'GCash Amount Portion (₱)',
                        prefixIcon: Icon(Icons.qr_code_2_rounded, color: Color(0xFF007DFE)),
                      ),
                      onChanged: (_) => setModalState(() {}),
                    ),
                    const SizedBox(height: 10),
                    // GCash Ref Field
                    TextField(
                      controller: gcashRefCtrl,
                      keyboardType: TextInputType.number,
                      maxLength: 4,
                      inputFormatters: [
                        FilteringTextInputFormatter.digitsOnly,
                        LengthLimitingTextInputFormatter(4),
                      ],
                      decoration: const InputDecoration(
                        labelText: 'GCash Ref # (Last 4 Digits Required)',
                        hintText: 'e.g. 5921',
                        prefixIcon: Icon(Icons.pin_rounded),
                      ),
                      onChanged: (_) => setModalState(() {}),
                    ),
                    const SizedBox(height: 10),
                    // Validation Summary Card
                    Container(
                      padding: const EdgeInsets.all(12),
                      decoration: BoxDecoration(
                        color: canSubmit
                            ? AppPalette.success.withValues(alpha: 0.12)
                            : AppPalette.danger.withValues(alpha: 0.12),
                        borderRadius: BorderRadius.circular(12),
                        border: Border.all(
                          color: canSubmit ? AppPalette.success : AppPalette.danger,
                        ),
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              const Text('Split Portions Sum:'),
                              Text(
                                '${AppFormatters.currency(totalPortions)} / ${AppFormatters.currency(total)}',
                                style: TextStyle(
                                  fontWeight: FontWeight.bold,
                                  color: isSplitSumValid
                                      ? AppPalette.success
                                      : AppPalette.danger,
                                ),
                              ),
                            ],
                          ),
                          if (!isSplitSumValid)
                            const Text(
                              'Cash + GCash must equal the total due.',
                              style: TextStyle(
                                fontSize: 11,
                                color: AppPalette.danger,
                              ),
                            ),
                          if (!isGcashRefValid)
                            const Text(
                              'Please enter the 4-digit GCash reference number.',
                              style: TextStyle(
                                fontSize: 11,
                                color: AppPalette.danger,
                              ),
                            ),
                        ],
                      ),
                    ),
                    const SizedBox(height: 16),
                    ElevatedButton(
                      style: ElevatedButton.styleFrom(
                        backgroundColor: AppPalette.champagneGold,
                        foregroundColor: AppPalette.crust,
                        padding: const EdgeInsets.symmetric(vertical: 14),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(14),
                        ),
                      ),
                      onPressed: canSubmit
                          ? () async {
                              final tx = await vm.processRetailCheckout(
                                paymentMethod: PaymentMethod.split,
                                amountTendered: cashTendered,
                                cashAmount: cashPortion,
                                gcashAmount: gcashPortion,
                                gcashRef: gcashRefCtrl.text.trim(),
                              );

                              if (!context.mounted) return;
                              if (tx != null) {
                                Navigator.of(bottomSheetCtx).pop(); // Close checkout sheet
                                Navigator.of(context).pop(); // Close scanner sheet
                                ReceiptPreviewModal.show(context, tx);
                              } else {
                                ScaffoldMessenger.of(context).showSnackBar(
                                  SnackBar(
                                    backgroundColor: AppPalette.danger,
                                    content: Text(
                                      vm.statusMessage ?? 'Split checkout failed.',
                                    ),
                                  ),
                                );
                              }
                            }
                          : null,
                      child: const Text(
                        'Complete Split Checkout & Print Receipt',
                        style: TextStyle(
                          fontSize: 14,
                          fontWeight: FontWeight.w800,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            );
          },
        );
      },
    );
  }

  Widget _buildOpticalGridFallback() {
    return ColoredBox(
      color: AppPalette.crust,
      child: Opacity(
        opacity: 0.14,
        child: GridView.builder(
          physics: const NeverScrollableScrollPhysics(),
          gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
            crossAxisCount: 8,
          ),
          itemCount: 32,
          itemBuilder: (_, index) => Container(
            decoration: BoxDecoration(
              border: Border.all(
                color: AppPalette.champagneGold,
                width: 0.5,
              ),
            ),
          ),
        ),
      ),
    );
  }
}
