import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../core/models/models.dart';
import '../core/theme/app_theme.dart';
import '../core/utils/formatters.dart';
import '../viewmodels/motohub_viewmodel.dart';
import 'role_router_screen.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  // Matches the 2-step flow in the user's Figma design:
  // Step 0 = "LOGIN" ("Staff & Management" -> "Log In to Account")
  // Step 1 = "USERNAME and password" ("Staff Login" -> "What's your username and password?" -> "Next ->")
  bool _showCredentialsForm = false;

  final _formKey = GlobalKey<FormState>();
  final _usernameController = TextEditingController();
  final _passwordController = TextEditingController();
  bool _obscurePassword = true;

  @override
  void dispose() {
    _usernameController.dispose();
    _passwordController.dispose();
    super.dispose();
  }

  Future<void> _submitLogin() async {
    if (!(_formKey.currentState?.validate() ?? false)) return;

    final vm = context.read<MotoHubViewModel>();
    try {
      final ok = await vm.login(
        _usernameController.text.trim(),
        _passwordController.text,
        customerOnly: false,
      );

      if (!mounted) return;
      if (ok) {
        Navigator.of(context).pushReplacement(
          MaterialPageRoute(builder: (_) => const RoleRouterScreen()),
        );
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            backgroundColor: AppPalette.surface1,
            content: Row(
              children: [
                const Icon(Icons.error_outline_rounded, color: AppPalette.danger),
                const SizedBox(width: 10),
                Expanded(
                  child: Text(
                    vm.statusMessage ?? 'Invalid login credentials',
                    style: const TextStyle(color: AppPalette.textHigh),
                  ),
                ),
              ],
            ),
          ),
        );
      }
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          backgroundColor: AppPalette.danger,
          content: Text(
            'Authentication error: $e',
            style: const TextStyle(color: AppPalette.crust),
          ),
        ),
      );
    }
  }

  void _quickFillAndLogin(String username, String password) {
    setState(() {
      _showCredentialsForm = true;
      _usernameController.text = username;
      _passwordController.text = password;
    });
    Future.microtask(_submitLogin);
  }

  @override
  Widget build(BuildContext context) {
    final vm = context.watch<MotoHubViewModel>();

    return Scaffold(
      backgroundColor: AppPalette.crust,
      body: SafeArea(
        child: Center(
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 460),
            child: AnimatedSwitcher(
              duration: const Duration(milliseconds: 320),
              switchInCurve: Curves.easeOutCubic,
              switchOutCurve: Curves.easeInCubic,
              child: _showCredentialsForm
                  ? _buildCredentialsStep(context, vm)
                  : _buildTerminalLandingStep(context, vm),
            ),
          ),
        ),
      ),
    );
  }

  /// Screen 2 from User's Figma Image:
  /// "Staff & Management" / "Choose an action to access the terminal." / "Log In to Account"
  /// AUDIT FIX: Wrapped in LayoutBuilder + SingleChildScrollView so 360dp budget phones
  /// never suffer vertical RenderFlex overflow. Customer role removed (decoupled to App B).
  Widget _buildTerminalLandingStep(
    BuildContext context,
    MotoHubViewModel vm,
  ) {
    return LayoutBuilder(
      key: const ValueKey('landing_step'),
      builder: (context, constraints) {
        return SingleChildScrollView(
          padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 24),
          child: ConstrainedBox(
            constraints: BoxConstraints(
              minHeight: (constraints.maxHeight - 48).clamp(0.0, double.infinity),
            ),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                const SizedBox(height: 8),
                Column(
                  children: [
                    // Rounded Square Icon Box with Gold Ring (Exact match to Figma "LOGIN" screen)
                    Container(
                      width: 76,
                      height: 76,
                      decoration: BoxDecoration(
                        color: AppPalette.mantle,
                        borderRadius: BorderRadius.circular(22),
                        border: Border.all(
                          color: AppPalette.warmGold.withValues(alpha: 0.35),
                          width: 1.2,
                        ),
                        boxShadow: [
                          BoxShadow(
                            color: AppPalette.champagneGold.withValues(alpha: 0.08),
                            blurRadius: 24,
                            offset: const Offset(0, 8),
                          ),
                        ],
                      ),
                      child: Center(
                        child: Container(
                          width: 30,
                          height: 30,
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            border: Border.all(
                              color: AppPalette.champagneGold,
                              width: 2.4,
                            ),
                          ),
                        ),
                      ),
                    ),
                    const SizedBox(height: 24),
                    const Text(
                      'Staff & Management',
                      textAlign: TextAlign.center,
                      style: TextStyle(
                        color: AppPalette.textHigh,
                        fontSize: 23,
                        fontWeight: FontWeight.w800,
                        letterSpacing: -0.3,
                      ),
                    ),
                    const SizedBox(height: 8),
                    const Text(
                      'Choose an action to access the internal ERP/POS terminal.',
                      textAlign: TextAlign.center,
                      style: TextStyle(
                        color: AppPalette.textMuted,
                        fontSize: 13.5,
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 24),

                // Instant One-Tap Staff Role Cards for Thesis Evaluation (Admin, Cashier, Mechanic ONLY)
                Column(
                  children: [
                    Card.filled(
                      color: AppPalette.mantle,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(16),
                        side: const BorderSide(color: AppPalette.surface0, width: 1),
                      ),
                      child: Padding(
                        padding: const EdgeInsets.all(14),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Row(
                              children: [
                                const Icon(
                                  Icons.bolt_rounded,
                                  color: AppPalette.champagneGold,
                                  size: 16,
                                ),
                                const SizedBox(width: 6),
                                const Expanded(
                                  child: Text(
                                    'INITIAL STAFF SEED ACCESS',
                                    maxLines: 1,
                                    overflow: TextOverflow.ellipsis,
                                    style: TextStyle(
                                      color: AppPalette.champagneGold,
                                      fontSize: 11,
                                      fontWeight: FontWeight.w800,
                                      letterSpacing: 0.6,
                                    ),
                                  ),
                                ),
                                const SizedBox(width: 6),
                                Text(
                                  'Internal ERP',
                                  style: TextStyle(
                                    color: AppPalette.textMuted.withValues(alpha: 0.8),
                                    fontSize: 10.5,
                                  ),
                                ),
                              ],
                            ),
                            const SizedBox(height: 10),
                            Wrap(
                              spacing: 8,
                              runSpacing: 8,
                              children: [
                                _DemoRoleChip(
                                  role: 'Admin (Boss Arman)',
                                  sub: 'bossarman',
                                  icon: Icons.admin_panel_settings_rounded,
                                  onTap: () => _quickFillAndLogin(
                                    'bossarman',
                                    'admin123',
                                  ),
                                ),
                                _DemoRoleChip(
                                  role: 'Cashier (Keith)',
                                  sub: 'cashier01',
                                  icon: Icons.point_of_sale_rounded,
                                  onTap: () => _quickFillAndLogin(
                                    'cashier01',
                                    'cashier123',
                                  ),
                                ),
                                _DemoRoleChip(
                                  role: 'Mechanic (Lance)',
                                  sub: 'mechanic01',
                                  icon: Icons.handyman_rounded,
                                  onTap: () => _quickFillAndLogin(
                                    'mechanic01',
                                    'mech123',
                                  ),
                                ),
                              ],
                            ),
                          ],
                        ),
                      ),
                    ),
                    const SizedBox(height: 20),

                    // Primary CTA Button from User's Figma Design
                    GoldGradientButton(
                      label: 'Log In to Account',
                      onPressed: () {
                        setState(() {
                          _showCredentialsForm = true;
                        });
                      },
                    ),
                    const SizedBox(height: 18),

                    Text(
                      'Terminal ID: ${vm.activeBranch.terminalId} • SQLite ACID Engine Ready',
                      textAlign: TextAlign.center,
                      style: const TextStyle(
                        color: AppPalette.inactive,
                        fontSize: 11.5,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  /// Screen 3 from User's Figma Image:
  /// "← Staff Login" / "What's your username and password?" / Outlined Gold Input / "Next →"
  Widget _buildCredentialsStep(
    BuildContext context,
    MotoHubViewModel vm,
  ) {
    return SingleChildScrollView(
      key: const ValueKey('credentials_step'),
      padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 16),
      child: Form(
        key: _formKey,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Top Back Navigation: "← Staff Login"
            InkWell(
              borderRadius: BorderRadius.circular(10),
              onTap: () {
                setState(() {
                  _showCredentialsForm = false;
                });
              },
              child: const Padding(
                padding: EdgeInsets.symmetric(vertical: 8, horizontal: 4),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Icon(
                      Icons.arrow_back_rounded,
                      color: AppPalette.textBody,
                      size: 20,
                    ),
                    SizedBox(width: 10),
                    Text(
                      'Staff Login',
                      style: TextStyle(
                        color: AppPalette.textHigh,
                        fontSize: 15.5,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 20),

            const Text(
              "What's your username and\npassword?",
              style: TextStyle(
                color: AppPalette.textHigh,
                fontSize: 24,
                fontWeight: FontWeight.w800,
                height: 1.25,
                letterSpacing: -0.4,
              ),
            ),
            const SizedBox(height: 8),
            const Text(
              'Enter your registered internal staff username to continue.',
              style: TextStyle(
                color: AppPalette.textMuted,
                fontSize: 13.5,
              ),
            ),
            const SizedBox(height: 22),

            // Custom Outlined Gold Input Box for Username (Matching Figma frame)
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
              decoration: BoxDecoration(
                color: AppPalette.mantle,
                borderRadius: BorderRadius.circular(14),
                border: Border.all(
                  color: AppPalette.warmGold.withValues(alpha: 0.75),
                  width: 1.2,
                ),
              ),
              child: Row(
                children: [
                  const Icon(
                    Icons.person_outline_rounded,
                    color: AppPalette.champagneGold,
                    size: 22,
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: TextFormField(
                      controller: _usernameController,
                      validator: AppValidators.username,
                      style: const TextStyle(
                        color: AppPalette.textHigh,
                        fontSize: 14.5,
                        fontWeight: FontWeight.w600,
                      ),
                      decoration: const InputDecoration(
                        labelText: 'Username',
                        labelStyle: TextStyle(
                          color: AppPalette.champagneGold,
                          fontSize: 12,
                          fontWeight: FontWeight.w600,
                        ),
                        hintText: 'Enter store username',
                        filled: false,
                        border: InputBorder.none,
                        enabledBorder: InputBorder.none,
                        focusedBorder: InputBorder.none,
                        errorBorder: InputBorder.none,
                        focusedErrorBorder: InputBorder.none,
                        contentPadding: EdgeInsets.symmetric(vertical: 6),
                      ),
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 14),

            // Custom Outlined Input Box for Password
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
              decoration: BoxDecoration(
                color: AppPalette.mantle,
                borderRadius: BorderRadius.circular(14),
                border: Border.all(
                  color: AppPalette.surface0,
                  width: 1.2,
                ),
              ),
              child: Row(
                children: [
                  const Icon(
                    Icons.lock_outline_rounded,
                    color: AppPalette.champagneGold,
                    size: 21,
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: TextFormField(
                      controller: _passwordController,
                      obscureText: _obscurePassword,
                      validator: AppValidators.password,
                      onFieldSubmitted: (_) => _submitLogin(),
                      style: const TextStyle(
                        color: AppPalette.textHigh,
                        fontSize: 14.5,
                        fontWeight: FontWeight.w600,
                      ),
                      decoration: InputDecoration(
                        labelText: 'Password',
                        labelStyle: const TextStyle(
                          color: AppPalette.champagneGold,
                          fontSize: 12,
                          fontWeight: FontWeight.w600,
                        ),
                        hintText: 'Enter store password',
                        filled: false,
                        border: InputBorder.none,
                        enabledBorder: InputBorder.none,
                        focusedBorder: InputBorder.none,
                        errorBorder: InputBorder.none,
                        focusedErrorBorder: InputBorder.none,
                        contentPadding:
                            const EdgeInsets.symmetric(vertical: 6),
                        suffixIcon: IconButton(
                          onPressed: () {
                            setState(() {
                              _obscurePassword = !_obscurePassword;
                            });
                          },
                          icon: Icon(
                            _obscurePassword
                                ? Icons.visibility_off_outlined
                                : Icons.visibility_outlined,
                            color: AppPalette.textMuted,
                            size: 20,
                          ),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 20),

            // Master Credentials Reference Card (One-tap fill)
            Card.filled(
              color: AppPalette.mantle,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(16),
                side: const BorderSide(color: AppPalette.surface0),
              ),
              child: Padding(
                padding: const EdgeInsets.all(14),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Row(
                      children: [
                        Icon(
                          Icons.verified_user_outlined,
                          size: 16,
                          color: AppPalette.champagneGold,
                        ),
                        SizedBox(width: 8),
                        Expanded(
                          child: Text(
                            'Initial Administrative & Staff Seeds (Tap to Fill)',
                            style: TextStyle(
                              color: AppPalette.champagneGold,
                              fontSize: 12,
                              fontWeight: FontWeight.w700,
                            ),
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 10),
                    _CredentialTile(
                      roleLabel: 'ADMIN • Boss Arman Sarita',
                      user: 'bossarman',
                      pass: 'admin123',
                      badgeColor: AppPalette.champagneGold,
                      onTap: () {
                        setState(() {
                          _usernameController.text = 'bossarman';
                          _passwordController.text = 'admin123';
                        });
                      },
                    ),
                    _CredentialTile(
                      roleLabel: 'CASHIER • Keith Arwil Umali',
                      user: 'cashier01',
                      pass: 'cashier123',
                      badgeColor: AppPalette.success,
                      onTap: () {
                        setState(() {
                          _usernameController.text = 'cashier01';
                          _passwordController.text = 'cashier123';
                        });
                      },
                    ),
                    _CredentialTile(
                      roleLabel: 'MECHANIC • Lance M. Aclan',
                      user: 'mechanic01',
                      pass: 'mech123',
                      badgeColor: AppPalette.warning,
                      onTap: () {
                        setState(() {
                          _usernameController.text = 'mechanic01';
                          _passwordController.text = 'mech123';
                        });
                      },
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 16),

            // Bottom "Next ->" Gold Gradient Button matching User's Figma Design
            GoldGradientButton(
              label: 'Next →',
              isLoading: vm.viewState == ViewState.loading,
              onPressed: _submitLogin,
            ),
          ],
        ),
      ),
    );
  }
}

class _DemoRoleChip extends StatelessWidget {
  final String role;
  final String sub;
  final IconData icon;
  final VoidCallback onTap;

  const _DemoRoleChip({
    required this.role,
    required this.sub,
    required this.icon,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return InkWell(
      borderRadius: BorderRadius.circular(12),
      onTap: onTap,
      child: Container(
        constraints: const BoxConstraints(minWidth: 140, maxWidth: 195),
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 9),
        decoration: BoxDecoration(
          color: AppPalette.crust,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: AppPalette.surface0),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(icon, color: AppPalette.champagneGold, size: 18),
            const SizedBox(width: 8),
            Flexible(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    role,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(
                      color: AppPalette.textHigh,
                      fontSize: 11.5,
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                  Text(
                    '@$sub',
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(
                      color: AppPalette.textMuted,
                      fontSize: 10,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _CredentialTile extends StatelessWidget {
  final String roleLabel;
  final String user;
  final String pass;
  final Color badgeColor;
  final VoidCallback onTap;

  const _CredentialTile({
    required this.roleLabel,
    required this.user,
    required this.pass,
    required this.badgeColor,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 6),
      child: InkWell(
        borderRadius: BorderRadius.circular(10),
        onTap: onTap,
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
          decoration: BoxDecoration(
            color: AppPalette.crust,
            borderRadius: BorderRadius.circular(10),
            border: Border.all(color: AppPalette.surface0),
          ),
          child: Row(
            children: [
              Container(
                width: 8,
                height: 8,
                decoration: BoxDecoration(
                  color: badgeColor,
                  shape: BoxShape.circle,
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      roleLabel,
                      style: const TextStyle(
                        color: AppPalette.textHigh,
                        fontSize: 12,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                    Text(
                      'User: $user  •  Pass: $pass',
                      style: const TextStyle(
                        color: AppPalette.textMuted,
                        fontSize: 11,
                      ),
                    ),
                  ],
                ),
              ),
              const Icon(
                Icons.touch_app_outlined,
                color: AppPalette.champagneGold,
                size: 16,
              ),
            ],
          ),
        ),
      ),
    );
  }
}