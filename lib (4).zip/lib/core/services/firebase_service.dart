import 'dart:async';
import 'dart:io';
import 'dart:math';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/foundation.dart';
import 'package:google_sign_in/google_sign_in.dart';
import '../models/models.dart';

/// Production Firebase Service for BossArman MotoHub & MotoHub Rider.
/// Handles Authentication, Firestore Real-Time Synchronization across apps,
/// Role-Based User documents (`users/{uid}`), and Automated FCM Push Notifications.
///
/// Designed defensively with graceful fallback when running in offline environments,
/// desktop platforms, or test harnesses without Firebase credentials.
class FirebaseService {
  static final FirebaseService instance = FirebaseService._internal();
  FirebaseService._internal();

  bool _isInitialized = false;
  bool get isInitialized => _isInitialized;

  FirebaseAuth? _auth;
  FirebaseFirestore? _firestore;
  FirebaseMessaging? _messaging;

  String? _cachedFcmToken;
  String? get fcmToken => _cachedFcmToken;

  // In-memory OTP store for email verification & password recovery
  final Map<String, _EmailOtpEntry> _otpStore = {};

  Future<void> initialize() async {
    if (_isInitialized) return;
    try {
      final isFlutterTest =
          !kIsWeb && Platform.environment.containsKey('FLUTTER_TEST');
      if (!isFlutterTest &&
          (kIsWeb ||
              defaultTargetPlatform == TargetPlatform.android ||
              defaultTargetPlatform == TargetPlatform.iOS)) {
        await Firebase.initializeApp();
        _auth = FirebaseAuth.instance;
        _firestore = FirebaseFirestore.instance;
        _messaging = FirebaseMessaging.instance;
        _isInitialized = true;

        await _initFcm();
        debugPrint('[FirebaseService] Firebase initialized successfully.');
      } else {
        debugPrint('[FirebaseService] Non-mobile/test environment. Using local database.');
      }
    } catch (e) {
      debugPrint('[FirebaseService] Firebase initialization skipped/fallback: $e');
      _isInitialized = false;
    }
  }

  Future<void> _initFcm() async {
    try {
      if (_messaging == null) return;
      final settings = await _messaging!.requestPermission(
        alert: true,
        badge: true,
        sound: true,
        provisional: false,
      );
      if (settings.authorizationStatus == AuthorizationStatus.authorized ||
          settings.authorizationStatus == AuthorizationStatus.provisional) {
        _cachedFcmToken = await _messaging!.getToken();
        debugPrint('[FirebaseService] FCM Token: $_cachedFcmToken');
      }

      // Foreground message listener
      FirebaseMessaging.onMessage.listen((RemoteMessage message) {
        debugPrint('[FirebaseService] Foreground FCM Message received: ${message.notification?.title}');
      });
    } catch (e) {
      debugPrint('[FirebaseService] FCM init warning: $e');
    }
  }

  // ---------------------------------------------------------------------------
  // 1. AUTHENTICATION & ROLE-BASED FIRESTORE USER DOCS
  // ---------------------------------------------------------------------------

  /// Sign In with Email + Password
  Future<StaffAccount?> signInWithEmail({
    required String email,
    required String password,
  }) async {
    if (!_isInitialized || _auth == null) return null;
    try {
      final cred = await _auth!.signInWithEmailAndPassword(
        email: email.trim(),
        password: password,
      );
      final uid = cred.user?.uid;
      if (uid == null) return null;

      final doc = await _firestore?.collection('users').doc(uid).get();
      if (doc != null && doc.exists && doc.data() != null) {
        final data = doc.data()!;
        data['id'] = uid;
        if (_cachedFcmToken != null) {
          await _firestore?.collection('users').doc(uid).set({
            'fcmToken': _cachedFcmToken,
          }, SetOptions(merge: true));
        }
        return StaffAccount.fromMap(data);
      }
      return null;
    } catch (e) {
      debugPrint('[FirebaseService] signInWithEmail error: $e');
      rethrow;
    }
  }

  bool _googleSignInInitialized = false;

  /// Prompts native Google One-Tap / Google Sign-In prompt.
  /// First attempts lightweight One-Tap / FedCM.
  /// If not yet signed in or restored, prompts the official interactive account picker.
  /// Returns a map with {'email': account.email, 'displayName': account.displayName, 'id': account.id}
  /// or null if the user cancelled the dialog.
  Future<Map<String, String?>?> promptNativeGoogleSignIn() async {
    try {
      if (!GoogleSignIn.instance.supportsAuthenticate()) {
        throw UnsupportedError(
          'Native Google Sign-In is not supported on this platform. Please run on Android, iOS, or Web with Google Cloud OAuth configured.',
        );
      }

      if (!_googleSignInInitialized) {
        await GoogleSignIn.instance.initialize();
        _googleSignInInitialized = true;
      }

      GoogleSignInAccount? account;
      // 1. Attempt lightweight One-Tap authentication first
      try {
        account = await GoogleSignIn.instance.attemptLightweightAuthentication();
      } catch (e) {
        debugPrint('[FirebaseService] Lightweight Google One-Tap check note: $e');
        account = null;
      }

      // 2. If no active session was restored, launch interactive account picker
      account ??= await GoogleSignIn.instance.authenticate();

      return {
        'email': account.email,
        'displayName': account.displayName,
        'id': account.id,
        'photoUrl': account.photoUrl,
      };
    } on GoogleSignInException catch (e) {
      if (e.code == GoogleSignInExceptionCode.canceled) {
        debugPrint('[FirebaseService] Google Sign-In was cancelled by user.');
        return null;
      }
      debugPrint('[FirebaseService] GoogleSignInException: ${e.code} - ${e.description}');
      rethrow;
    } catch (e) {
      debugPrint('[FirebaseService] promptNativeGoogleSignIn error: $e');
      rethrow;
    }
  }

  /// Register new user and persist role-based doc in `users/{uid}`
  Future<StaffAccount?> registerWithEmail({
    required String email,
    required String password,
    required String firstName,
    required String lastName,
    required String username,
    required UserRole role,
    required BranchId branch,
  }) async {
    if (!_isInitialized || _auth == null) return null;
    try {
      final cred = await _auth!.createUserWithEmailAndPassword(
        email: email.trim(),
        password: password,
      );
      final uid = cred.user?.uid;
      if (uid == null) return null;

      final staff = StaffAccount(
        id: uid,
        firstName: firstName,
        lastName: lastName,
        username: username,
        email: email.trim(),
        password: password,
        role: role,
        assignedBranch: branch,
        shiftStatus: 'On Duty',
        authProvider: 'password',
        fcmToken: _cachedFcmToken,
        createdAt: DateTime.now(),
      );

      await _firestore?.collection('users').doc(uid).set(staff.toFirestoreDoc());
      return staff;
    } catch (e) {
      debugPrint('[FirebaseService] registerWithEmail error: $e');
      rethrow;
    }
  }

  /// Save or update user FCM token in Firestore
  Future<void> updateUserFcmToken(String uid, String? token) async {
    if (!_isInitialized || _firestore == null || token == null) return;
    try {
      await _firestore!.collection('users').doc(uid).set({
        'fcmToken': token,
        'updatedAt': FieldValue.serverTimestamp(),
      }, SetOptions(merge: true));
    } catch (e) {
      debugPrint('[FirebaseService] updateUserFcmToken error: $e');
    }
  }

  // ---------------------------------------------------------------------------
  // 2. FORGOT PASSWORD & EMAIL OTP VERIFICATION
  // ---------------------------------------------------------------------------

  /// Sends a 6-digit OTP code to the provided email with 10-minute expiry
  Future<bool> sendPasswordResetOtp(String email) async {
    final cleanEmail = email.trim().toLowerCase();
    final otp = (100000 + Random().nextInt(900000)).toString();
    _otpStore[cleanEmail] = _EmailOtpEntry(
      code: otp,
      expiry: DateTime.now().add(const Duration(minutes: 10)),
      lastSent: DateTime.now(),
    );

    debugPrint('[FirebaseService] Generated OTP for $cleanEmail: $otp');

    // Also trigger Firebase Auth standard reset email if connected
    if (_isInitialized && _auth != null) {
      try {
        await _auth!.sendPasswordResetEmail(email: cleanEmail);
      } catch (e) {
        debugPrint('[FirebaseService] sendPasswordResetEmail note: $e');
      }
    }
    return true;
  }

  /// Checks if the resend cooldown (60 seconds) has elapsed
  int getRemainingResendCooldownSeconds(String email) {
    final entry = _otpStore[email.trim().toLowerCase()];
    if (entry == null) return 0;
    final diff = DateTime.now().difference(entry.lastSent).inSeconds;
    return (60 - diff).clamp(0, 60);
  }

  /// Verifies the 6-digit OTP code
  bool verifyPasswordResetOtp(String email, String inputOtp) {
    final cleanEmail = email.trim().toLowerCase();
    final entry = _otpStore[cleanEmail];
    if (entry == null) return false;
    if (DateTime.now().isAfter(entry.expiry)) {
      _otpStore.remove(cleanEmail);
      return false;
    }
    return entry.code == inputOtp.trim();
  }

  /// Resets the user's password after OTP verification
  Future<bool> resetPasswordWithOtp({
    required String email,
    required String otp,
    required String newPassword,
  }) async {
    final verified = verifyPasswordResetOtp(email, otp);
    if (!verified) return false;
    _otpStore.remove(email.trim().toLowerCase());

    // Update in Firebase Auth if available
    if (_isInitialized && _auth != null && _auth!.currentUser != null) {
      try {
        await _auth!.currentUser!.updatePassword(newPassword);
      } catch (e) {
        debugPrint('[FirebaseService] updatePassword error: $e');
      }
    }
    return true;
  }

  /// Generates and sends a 6-digit OTP code to verify staff email before account provisioning
  Future<String> sendAccountRegistrationOtp(String email) async {
    final cleanEmail = email.trim().toLowerCase();
    final otp = (100000 + Random().nextInt(900000)).toString();
    _otpStore[cleanEmail] = _EmailOtpEntry(
      code: otp,
      expiry: DateTime.now().add(const Duration(minutes: 10)),
      lastSent: DateTime.now(),
    );
    debugPrint('[FirebaseService] Staff Registration OTP for $cleanEmail: $otp');
    return otp;
  }

  /// Verifies the 6-digit registration OTP code
  bool verifyAccountRegistrationOtp(String email, String inputOtp) {
    final cleanEmail = email.trim().toLowerCase();
    final entry = _otpStore[cleanEmail];
    if (entry == null) return false;
    if (DateTime.now().isAfter(entry.expiry)) {
      _otpStore.remove(cleanEmail);
      return false;
    }
    final match = entry.code == inputOtp.trim();
    if (match) {
      _otpStore.remove(cleanEmail);
    }
    return match;
  }

  // ---------------------------------------------------------------------------
  // 3. AUTOMATED CUSTOMER PUSH NOTIFICATIONS (FCM)
  // ---------------------------------------------------------------------------

  /// Triggered when mechanic transitions Job Order status to `Ready for Pickup`
  Future<void> sendJobReadyPushNotification({
    required String jobId,
    required String bikeModel,
    required String? customerFcmToken,
    required BranchId branch,
  }) async {
    const title = 'Your motorcycle is ready for pickup! 🏍️';
    final body =
        'Job Order #$jobId ($bikeModel) has been completed. View your itemized bill and claim your unit at Boss Arman MotoHub (${branch.shortName}).';

    debugPrint('[FirebaseService] FCM Trigger -> Title: "$title" | Body: "$body" | Target: $customerFcmToken');

    if (!_isInitialized || _firestore == null) return;
    try {
      // Store in Firestore notifications collection to sync directly to customer app
      await _firestore!.collection('customer_notifications').add({
        'jobId': jobId,
        'title': title,
        'body': body,
        'branch': branch.name,
        'fcmToken': customerFcmToken,
        'createdAt': FieldValue.serverTimestamp(),
        'isRead': false,
      });
    } catch (e) {
      debugPrint('[FirebaseService] sendJobReadyPushNotification note: $e');
    }
  }

  // ---------------------------------------------------------------------------
  // 4. CROSS-APP FIRESTORE REAL-TIME SYNCHRONIZATION
  // ---------------------------------------------------------------------------

  /// Syncs customer booking or active job order directly to Firestore
  Future<void> syncJobOrderToFirestore(JobOrder job) async {
    if (!_isInitialized || _firestore == null) return;
    try {
      await _firestore!.collection('job_orders').doc(job.id).set(
            job.toMap(),
            SetOptions(merge: true),
          );
      debugPrint('[FirebaseService] Synced Job Order ${job.id} to Firestore.');
    } catch (e) {
      debugPrint('[FirebaseService] syncJobOrderToFirestore note: $e');
    }
  }

  /// Syncs an inventory update directly to Firestore
  Future<void> syncInventoryItemToFirestore(InventoryItem item) async {
    if (!_isInitialized || _firestore == null) return;
    try {
      await _firestore!.collection('inventory').doc(item.id).set(
            item.toMap(),
            SetOptions(merge: true),
          );
    } catch (e) {
      debugPrint('[FirebaseService] syncInventoryItemToFirestore note: $e');
    }
  }

  /// Syncs a Click & Collect reservation directly to Firestore
  Future<void> syncClickAndCollectToFirestore(ClickAndCollectOrder order) async {
    if (!_isInitialized || _firestore == null) return;
    try {
      await _firestore!.collection('click_and_collect').doc(order.id).set(
            order.toMap(),
            SetOptions(merge: true),
          );
    } catch (e) {
      debugPrint('[FirebaseService] syncClickAndCollectToFirestore note: $e');
    }
  }

  /// Syncs a Stock Transfer directly to Firestore
  Future<void> syncStockTransferToFirestore(StockTransfer transfer) async {
    if (!_isInitialized || _firestore == null) return;
    try {
      await _firestore!.collection('stock_transfers').doc(transfer.id).set(
            transfer.toMap(),
            SetOptions(merge: true),
          );
    } catch (e) {
      debugPrint('[FirebaseService] syncStockTransferToFirestore note: $e');
    }
  }

  /// Syncs a POS Transaction directly to Firestore
  Future<void> syncPosTransactionToFirestore(PosTransaction tx) async {
    if (!_isInitialized || _firestore == null) return;
    try {
      await _firestore!.collection('transactions').doc(tx.id).set(
            tx.toMap(),
            SetOptions(merge: true),
          );
    } catch (e) {
      debugPrint('[FirebaseService] syncPosTransactionToFirestore note: $e');
    }
  }

  /// Streams active Firestore Job Orders for live dashboard updates
  Stream<List<JobOrder>> streamFirestoreJobOrders() {
    if (!_isInitialized || _firestore == null) {
      return const Stream.empty();
    }
    return _firestore!.collection('job_orders').snapshots().map((snapshot) {
      return snapshot.docs.map((d) => JobOrder.fromMap(d.data())).toList();
    });
  }

  /// Streams active Firestore Click & Collect orders for live dashboard updates
  Stream<List<ClickAndCollectOrder>> streamFirestoreClickCollect() {
    if (!_isInitialized || _firestore == null) {
      return const Stream.empty();
    }
    return _firestore!.collection('click_and_collect').snapshots().map((snapshot) {
      return snapshot.docs.map((d) => ClickAndCollectOrder.fromMap(d.data())).toList();
    });
  }
}

class _EmailOtpEntry {
  final String code;
  final DateTime expiry;
  final DateTime lastSent;

  _EmailOtpEntry({
    required this.code,
    required this.expiry,
    required this.lastSent,
  });
}
