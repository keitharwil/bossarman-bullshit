import 'dart:async';
import 'dart:convert';
import 'package:crypto/crypto.dart';
import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:uuid/uuid.dart';
import '../core/models/models.dart';
import '../core/services/firebase_service.dart';
import '../core/services/local_database_service.dart';
import '../core/utils/formatters.dart';

/// Cryptographically secure password hashing & verification using salted SHA-256
class PasswordSecurity {
  static String hashPassword(String password, {String? salt}) {
    salt ??= const Uuid().v4().replaceAll('-', '').substring(0, 16);
    final bytes = utf8.encode('$salt:$password');
    final digest = sha256.convert(bytes);
    return '$salt:$digest';
  }

  static bool verify(String storedHashOrPlaintext, String password) {
    if (storedHashOrPlaintext.isEmpty || password.isEmpty) return false;
    if (storedHashOrPlaintext.contains(':')) {
      final parts = storedHashOrPlaintext.split(':');
      if (parts.length == 2) {
        final salt = parts[0];
        final expectedHash = parts[1];
        final bytes = utf8.encode('$salt:$password');
        final digest = sha256.convert(bytes).toString();
        return digest == expectedHash;
      }
    }
    // Backward compatibility for legacy plaintext passwords
    return storedHashOrPlaintext == password;
  }
}

/// Central State & Business Logic Controller for Boss Arman MotoHub.
class MotoHubViewModel extends ChangeNotifier {
  final LocalDatabaseService _db = LocalDatabaseService.instance;
  final FirebaseService _firebase = FirebaseService.instance;
  final bool isCustomerApp;

  static const _uuid = Uuid();
  String _generateId(String prefix) {
    final ts = DateTime.now().millisecondsSinceEpoch;
    final rand = _uuid.v4().replaceAll('-', '').substring(0, 6).toUpperCase();
    return '$prefix-$ts-$rand';
  }

  StreamSubscription<List<JobOrder>>? _jobOrdersSub;
  StreamSubscription<List<ClickAndCollectOrder>>? _clickCollectSub;
  bool _isProcessingCheckout = false;

  FirebaseService get firebase => _firebase;

  MotoHubViewModel({this.isCustomerApp = false});

  ViewState _viewState = ViewState.idle;
  ViewState get viewState => _viewState;

  String? _statusMessage;
  String? get statusMessage => _statusMessage;

  bool _isInitialized = false;
  bool get isInitialized => _isInitialized;

  // Authentication & Session Context
  StaffAccount? _currentUser;
  StaffAccount? get currentUser => _currentUser;

  // Dynamic Branch Context (Defaults to Branch 1: Patimbao)
  BranchId _activeBranch = BranchId.patimbao;
  BranchId get activeBranch => _activeBranch;

  // Offline-First Connectivity & Background Sync Queue
  bool _isOnline = true;
  bool get isOnline => _isOnline;

  bool _isSyncing = false;
  bool get isSyncing => _isSyncing;

  final List<OfflineSyncTask> _offlineQueue = [];
  List<OfflineSyncTask> get offlineQueue => List.unmodifiable(_offlineQueue);
  int get pendingSyncCount => _offlineQueue.where((t) => !t.synced).length;

  // Core State Collections (Populated exclusively from SQLite — zero mock arrays)
  List<StaffAccount> _staffList = [];
  List<InventoryItem> _inventory = [];
  List<JobOrder> _jobOrders = [];
  List<StockTransfer> _transfers = [];
  List<PosTransaction> _transactions = [];
  List<CashDrawerEntry> _cashLedger = [];
  List<AppNotificationItem> _notifications = [];
  List<ClickAndCollectOrder> _clickCollectOrders = [];
  List<ZReadingRecord> _zReadings = [];

  // Retail POS Cart State
  final List<CartItem> _cart = [];
  List<CartItem> get cart => List.unmodifiable(_cart);

  // Filters
  String _inventorySearchQuery = '';
  String get inventorySearchQuery => _inventorySearchQuery;

  String _selectedPosCategory = 'All';
  String get selectedPosCategory => _selectedPosCategory;

  JobStatus? _selectedJobStatusFilter;
  JobStatus? get selectedJobStatusFilter => _selectedJobStatusFilter;

  // ---------------------------------------------------------------------------
  // Getters & Reactive Branch Queries
  // ---------------------------------------------------------------------------

  List<StaffAccount> get staffList => List.unmodifiable(_staffList);
  List<InventoryItem> get allInventory => List.unmodifiable(_inventory);
  List<ClickAndCollectOrder> get clickCollectOrders =>
      List.unmodifiable(_clickCollectOrders);

  /// Dynamic list of mechanics from registered staff accounts
  List<StaffAccount> get mechanicsList =>
      _staffList.where((s) => s.role == UserRole.mechanic).toList();

  List<InventoryItem> get filteredInventory {
    return _inventory.where((item) {
      final matchesCat = _selectedPosCategory == 'All' ||
          item.category.toLowerCase() == _selectedPosCategory.toLowerCase();
      if (!matchesCat) return false;
      if (_inventorySearchQuery.trim().isEmpty) return true;
      final q = _inventorySearchQuery.toLowerCase();
      return item.name.toLowerCase().contains(q) ||
          item.sku.toLowerCase().contains(q) ||
          item.barcode.toLowerCase().contains(q) ||
          item.category.toLowerCase().contains(q) ||
          item.shelfCoordinates.toLowerCase().contains(q) ||
          item.compatibleModels.toLowerCase().contains(q);
    }).toList();
  }

  static const List<String> categories = [
    'All',
    'CVT Tuning',
    'Engine Oils',
    'Thai Bolts',
    'Tires & Brakes',
    'Electrical',
  ];

  /// Jobs filtered by active branch
  List<JobOrder> get branchJobOrders {
    return _jobOrders.where((j) => j.branch == _activeBranch).toList();
  }

  /// Jobs belonging to the currently logged-in customer (strictly isolated by customerUsername)
  List<JobOrder> get customerJobOrders {
    final user = _currentUser;
    if (user == null) return const [];
    return _jobOrders
        .where((j) =>
            j.customerUsername.toLowerCase() == user.username.toLowerCase())
        .toList();
  }

  /// Click & Collect reservations belonging to the currently logged-in customer
  List<ClickAndCollectOrder> get customerClickCollectOrders {
    final user = _currentUser;
    if (user == null) return const [];
    return _clickCollectOrders
        .where((o) =>
            o.customerUsername.toLowerCase() == user.username.toLowerCase())
        .toList();
  }

  List<JobOrder> get filteredBranchJobOrders {
    final base = branchJobOrders;
    if (_selectedJobStatusFilter == null) return base;
    return base.where((j) => j.status == _selectedJobStatusFilter).toList();
  }

  /// Active bikes currently occupying lifts in the selected branch
  List<JobOrder> get activeBayBikes {
    return branchJobOrders
        .where((j) =>
            j.status == JobStatus.received ||
            j.status == JobStatus.inBay ||
            j.status == JobStatus.waitingForParts ||
            j.status == JobStatus.readyForPickup)
        .toList();
  }

  int get maxBayCapacity => 6;

  /// Service-to-POS Auto-Billing Queue (Ready for Pickup & unbilled)
  List<JobOrder> get serviceToPosQueue {
    return branchJobOrders
        .where((j) => !j.isBilled && j.status == JobStatus.readyForPickup)
        .toList();
  }

  /// Saved Z-Readings for active branch (immutable end-of-shift audit snapshots)
  List<ZReadingRecord> get branchZReadings =>
      _zReadings.where((z) => z.branch == _activeBranch).toList();

  ZReadingRecord? get lastZReading {
    final list = branchZReadings;
    if (list.isEmpty) return null;
    return list.first;
  }

  DateTime get currentShiftStartTime {
    final lastZ = lastZReading;
    if (lastZ != null) {
      return lastZ.generatedAt;
    }
    final now = DateTime.now();
    return DateTime(now.year, now.month, now.day);
  }

  /// All transactions for active branch
  List<PosTransaction> get branchTransactions {
    return _transactions.where((t) => t.branch == _activeBranch).toList();
  }

  /// Transactions scoped strictly to the current active shift
  List<PosTransaction> get currentShiftTransactions {
    final start = currentShiftStartTime;
    return _transactions
        .where((t) => t.branch == _activeBranch && t.createdAt.isAfter(start))
        .toList();
  }

  /// Current shift gross sales for active branch
  double get branchTodayGross {
    return currentShiftTransactions.fold(0.0, (sum, t) => sum + t.totalAmount);
  }

  /// Cash collections for current shift (pure cash + split cash amount)
  double get branchCashSalesTotal {
    return currentShiftTransactions.fold(0.0, (sum, t) {
      if (t.paymentMethod == PaymentMethod.cash) {
        return sum + (t.cashAmount > 0 ? t.cashAmount : t.totalAmount);
      } else if (t.paymentMethod == PaymentMethod.split) {
        return sum + (t.cashAmount > 0 ? t.cashAmount : (t.totalAmount - t.gcashAmount));
      }
      return sum;
    });
  }

  /// GCash collections for current shift (pure gcash + split gcash amount)
  double get branchGcashVaultTotal {
    return currentShiftTransactions.fold(0.0, (sum, t) {
      if (t.paymentMethod == PaymentMethod.gcash) {
        return sum + (t.gcashAmount > 0 ? t.gcashAmount : t.totalAmount);
      } else if (t.paymentMethod == PaymentMethod.split) {
        return sum + (t.gcashAmount > 0 ? t.gcashAmount : (t.totalAmount - t.cashAmount));
      }
      return sum;
    });
  }

  /// All cash drawer ledger records for active branch
  List<CashDrawerEntry> get branchCashLedger {
    return _cashLedger.where((e) => e.branch == _activeBranch).toList();
  }

  /// Cash drawer ledger scoped strictly to the current active shift
  List<CashDrawerEntry> get currentShiftCashLedger {
    final start = currentShiftStartTime;
    return _cashLedger
        .where((e) => e.branch == _activeBranch && e.createdAt.isAfter(start))
        .toList();
  }

  double get branchMorningFloat {
    return currentShiftCashLedger
        .where((e) => e.type == CashLedgerType.morningFloat)
        .fold(0.0, (sum, e) => sum + e.amount);
  }

  double get branchCashoutTotal {
    return currentShiftCashLedger
        .where((e) =>
            e.type == CashLedgerType.cashout ||
            e.type == CashLedgerType.pettyCashOut)
        .fold(0.0, (sum, e) => sum + e.amount.abs());
  }

  /// Backward compatible alias for branchCashoutTotal
  double get branchPettyCashOutTotal => branchCashoutTotal;

  /// Expected Physical Cash in Drawer = Morning Float + Cash Sales + Service Cash - Cashouts
  double get branchPhysicalCashInDrawer {
    return currentShiftCashLedger.fold(0.0, (sum, e) => sum + e.amount);
  }

  /// Low-Stock & Critical Out-of-Stock items in active branch
  List<InventoryItem> get branchLowStockItems {
    return _inventory.where((i) {
      final health = i.healthFor(_activeBranch);
      return health == StockHealth.lowStock ||
          health == StockHealth.criticalOut;
    }).toList();
  }

  /// Overstock items in active branch
  List<InventoryItem> get branchOverstockItems {
    return _inventory
        .where((i) => i.healthFor(_activeBranch) == StockHealth.overStock)
        .toList();
  }

  /// In-Transit transfers count for a specific branch (receiving or sending)
  int inTransitCountForBranch(BranchId branch) {
    return _transfers
        .where((t) =>
            t.status == TransferStatus.inTransit &&
            (t.toBranch == branch || t.fromBranch == branch))
        .length;
  }

  /// Incoming In-Transit transfers waiting for [Confirm Delivery] at active branch
  List<StockTransfer> get incomingInTransitTransfers {
    return _transfers
        .where((t) =>
            t.status == TransferStatus.inTransit &&
            t.toBranch == _activeBranch)
        .toList();
  }

  /// Transfers waiting for source branch or Admin approval (Strict Approval Workflow)
  List<StockTransfer> get pendingApprovalTransfers {
    return _transfers
        .where((t) =>
            t.status == TransferStatus.pendingApproval &&
            (t.fromBranch == _activeBranch ||
                _currentUser?.role == UserRole.admin))
        .toList();
  }

  List<StockTransfer> get allTransfers => List.unmodifiable(_transfers);

  /// Transfers involving the currently active branch only (used by single-branch Cashier monitoring)
  List<StockTransfer> get branchTransfers {
    return _transfers
        .where((t) =>
            t.toBranch == _activeBranch || t.fromBranch == _activeBranch)
        .toList();
  }

  /// True when the logged-in user is a Cashier or Mechanic (strictly locked to 1 branch; only Admin can reassign)
  bool get isBranchLockedForCurrentUser {
    final u = _currentUser;
    if (u == null) return false;
    return u.role == UserRole.cashier || u.role == UserRole.mechanic;
  }

  List<AppNotificationItem> get branchNotifications {
    if (isBranchLockedForCurrentUser) {
      return _notifications
          .where((n) => n.branch == _activeBranch)
          .toList();
    }
    return _notifications
        .where((n) => n.branch == _activeBranch || n.branch == BranchId.both)
        .toList();
  }

  int get unreadNotificationCount {
    return branchNotifications.where((n) => !n.isRead).length;
  }

  Future<void> markNotificationRead(String id) =>
      markAllNotificationsRead(id);

  double get cartTotal => _cart.fold(0.0, (sum, c) => sum + c.subtotal);
  int get cartItemCount => _cart.fold(0, (sum, c) => sum + c.quantity);

  // ---------------------------------------------------------------------------
  // Initialization & Pre-Warm
  // ---------------------------------------------------------------------------

  Future<void> initializeApp({
    void Function(double progress, String status)? onProgress,
  }) async {
    if (_isInitialized) {
      onProgress?.call(1.0, 'Ready');
      return;
    }
    _setViewState(ViewState.loading);
    try {
      await _db.initializeAndPreWarm(onProgress: onProgress);

      _staffList = List<StaffAccount>.from(await _db.loadStaff());

      // Ensure seed admin accounts exist in local SQLite and memory
      for (final seed in LocalDatabaseService.initialAdminAndStaffSeeds()) {
        final exists = _staffList.any((s) =>
            s.username.toLowerCase() == seed.username.toLowerCase() ||
            s.email.toLowerCase() == seed.email.toLowerCase());
        if (!exists) {
          await _db.saveStaff(seed);
          _staffList.add(seed);
        }
      }

      // Enforce single-branch assignment rule for all Cashier & Mechanic accounts
      for (var i = 0; i < _staffList.length; i++) {
        final s = _staffList[i];
        if ((s.role == UserRole.cashier || s.role == UserRole.mechanic) &&
            s.assignedBranch == BranchId.both) {
          final sanitized = s.copyWith(assignedBranch: BranchId.patimbao);
          _staffList[i] = sanitized;
          await _db.saveStaff(sanitized);
        }
      }

      _inventory = List<InventoryItem>.from(await _db.loadInventory());
      _jobOrders = List<JobOrder>.from(await _db.loadJobOrders());
      _transfers = List<StockTransfer>.from(await _db.loadTransfers());
      _transactions = List<PosTransaction>.from(await _db.loadTransactions());
      _cashLedger = List<CashDrawerEntry>.from(await _db.loadCashLedger());
      _notifications =
          List<AppNotificationItem>.from(await _db.loadNotifications());
      _clickCollectOrders =
          List<ClickAndCollectOrder>.from(await _db.loadClickCollectOrders());
      _zReadings = List<ZReadingRecord>.from(await _db.loadZReadings());
      // Restore cached session isolated by app target (Internal vs Customer)
      final prefs = await SharedPreferences.getInstance();
      final userKey =
          isCustomerApp ? 'cached_customer_user' : 'cached_internal_user';
      final savedUsername = prefs.getString(userKey);
      final savedBranch = prefs.getString('cached_branch');

      if (savedBranch != null) {
        _activeBranch = BranchId.values.firstWhere(
          (b) => b.name == savedBranch && b != BranchId.both,
          orElse: () => BranchId.patimbao,
        );
      }
      if (savedUsername != null) {
        final match = _staffList
            .where((s) =>
                s.username.toLowerCase() == savedUsername.toLowerCase() &&
                (isCustomerApp
                    ? s.role == UserRole.customer
                    : s.role != UserRole.customer))
            .toList();
        if (match.isNotEmpty) {
          _currentUser = match.first;
          if (_currentUser!.role == UserRole.cashier ||
              _currentUser!.role == UserRole.mechanic) {
            _activeBranch = _currentUser!.assignedBranch == BranchId.both
                ? BranchId.patimbao
                : _currentUser!.assignedBranch;
          }
        }
      }

      try {
        await _firebase.initialize();
        // Subscribe to live Firestore sync streams for cross-app updates
        _jobOrdersSub = _firebase.streamFirestoreJobOrders().listen((remoteJobs) {
          if (remoteJobs.isNotEmpty) {
            for (final rj in remoteJobs) {
              final idx = _jobOrders.indexWhere((j) => j.id == rj.id);
              if (idx >= 0) {
                _jobOrders[idx] = rj;
              } else {
                _jobOrders.insert(0, rj);
              }
              _db.saveJobOrder(rj);
            }
            notifyListeners();
          }
        });

        _clickCollectSub = _firebase.streamFirestoreClickCollect().listen((remoteOrders) {
          if (remoteOrders.isNotEmpty) {
            for (final ro in remoteOrders) {
              final idx = _clickCollectOrders.indexWhere((o) => o.id == ro.id);
              if (idx >= 0) {
                _clickCollectOrders[idx] = ro;
              } else {
                _clickCollectOrders.insert(0, ro);
              }
              _db.saveClickCollectOrder(ro);
            }
            notifyListeners();
          }
        });
      } catch (e) {
        debugPrint('[MotoHubViewModel] Firebase init notice: $e');
      }

      _isInitialized = true;
      _setViewState(ViewState.idle);
    } catch (e) {
      _setViewState(
        ViewState.error,
        'Failed to initialize local database: $e',
      );
    }
  }

  void _setViewState(ViewState state, [String? message]) {
    _viewState = state;
    _statusMessage = message;
    notifyListeners();
  }

  bool _isValidCurrency(double value) =>
      !value.isNaN && !value.isInfinite && value >= 0.0;

  // ---------------------------------------------------------------------------
  // Authentication (Internal ERP vs. Decoupled Customer App + Google Sign-In)
  // ---------------------------------------------------------------------------

  ///click & collect reservations alias
  List<ClickAndCollectOrder> get customerClickAndCollectOrders =>
      customerClickCollectOrders;

  /// Internal ERP Login (Admin: `bossarman` / `admin123`, Cashier: `cashier01` / `cashier123`, Mechanic: `mechanic01` / `mech123`)
  Future<bool> login(
    String username,
    String password, {
    bool allowCustomerRole = false,
    bool internalOnly = false,
    bool customerOnly = false,
  }) async {
    final effectiveAllowCustomer =
        allowCustomerRole || customerOnly || (isCustomerApp && !internalOnly);
    _setViewState(ViewState.loading);
    try {
      await Future<void>.delayed(const Duration(milliseconds: 200));

      final cleanUser = username.trim().toLowerCase();
      final cleanPass = password.trim();

      final candidates = _staffList.where(
        (s) =>
            s.username.toLowerCase() == cleanUser ||
            s.email.toLowerCase() == cleanUser,
      ).toList();

      if (candidates.isEmpty) {
        _setViewState(
          ViewState.error,
          'Invalid credentials. Check username and password.',
        );
        return false;
      }

      final candidate = candidates.first;
      if (candidate.authProvider == 'google') {
        _setViewState(
          ViewState.error,
          'This account is registered via Google One-Tap. Please sign in using Google.',
        );
        return false;
      }

      final passMatches = PasswordSecurity.verify(candidate.password, cleanPass);
      if (!passMatches) {
        _setViewState(
          ViewState.error,
          'Invalid credentials. Check username and password.',
        );
        return false;
      }

      var user = candidate;
      // If legacy plaintext password matched, automatically hash and update in SQLite
      if (!user.password.contains(':')) {
        final hashed = PasswordSecurity.hashPassword(cleanPass);
        user = user.copyWith(password: hashed);
        final idx = _staffList.indexWhere((s) => s.id == user.id);
        if (idx >= 0) _staffList[idx] = user;
        await _db.saveStaff(user);
      }

      if ((internalOnly || (!effectiveAllowCustomer && !isCustomerApp)) &&
          user.role == UserRole.customer) {
        _setViewState(
          ViewState.error,
          'Customer accounts must sign in using the Customer App target.',
        );
        return false;
      }
      if ((customerOnly || effectiveAllowCustomer) &&
          user.role != UserRole.customer) {
        _setViewState(
          ViewState.error,
          'Staff accounts must sign in using the Internal ERP terminal.',
        );
        return false;
      }

      // Strictly enforce single-branch assignment for Cashier and Mechanic
      if ((user.role == UserRole.cashier || user.role == UserRole.mechanic) &&
          user.assignedBranch == BranchId.both) {
        user = user.copyWith(assignedBranch: BranchId.patimbao);
        final idx = _staffList.indexWhere((s) => s.id == user.id);
        if (idx >= 0) _staffList[idx] = user;
        await _db.saveStaff(user);
      }

      _currentUser = user;

      if (user.role == UserRole.cashier || user.role == UserRole.mechanic) {
        _activeBranch = user.assignedBranch;
      } else if (user.assignedBranch == BranchId.patimbao ||
          user.assignedBranch == BranchId.pedroGuevara) {
        _activeBranch = user.assignedBranch;
      }

      final prefs = await SharedPreferences.getInstance();
      final userKey = (customerOnly || effectiveAllowCustomer)
          ? 'cached_customer_user'
          : 'cached_internal_user';
      await prefs.setString(userKey, user.username);
      await prefs.setString('cached_branch', _activeBranch.name);

      _setViewState(
        ViewState.success,
        'Welcome back, ${user.fullName} (${user.role.label})',
      );
      return true;
    } catch (e) {
      _setViewState(ViewState.error, 'Login error: $e');
      return false;
    }
  }

  /// Customer Email/Password Registration for `main_customer.dart`
  Future<bool> registerCustomerAccount({
    required String firstName,
    required String lastName,
    required String username,
    required String email,
    required String password,
    BranchId preferredBranch = BranchId.patimbao,
  }) async {
    _setViewState(ViewState.loading);
    try {
      final cleanUsername = username.trim().toLowerCase();
      final cleanEmail = email.trim().toLowerCase();

      final duplicate = _staffList.any(
        (s) =>
            s.username.toLowerCase() == cleanUsername ||
            s.email.toLowerCase() == cleanEmail,
      );
      if (duplicate) {
        _setViewState(
          ViewState.error,
          'Username or email is already registered.',
        );
        return false;
      }

      final newCustomer = StaffAccount(
        id: _generateId('CUS'),
        firstName: firstName.trim(),
        lastName: lastName.trim(),
        username: cleanUsername,
        email: cleanEmail,
        password: PasswordSecurity.hashPassword(password.trim()),
        role: UserRole.customer,
        assignedBranch: preferredBranch,
        shiftStatus: 'Verified Customer',
        authProvider: 'password',
        createdAt: DateTime.now(),
      );

      await _db.saveStaff(newCustomer);
      _staffList.add(newCustomer);
      _currentUser = newCustomer;
      _activeBranch = preferredBranch;

      final prefs = await SharedPreferences.getInstance();
      await prefs.setString('cached_customer_user', newCustomer.username);
      await prefs.setString('cached_branch', _activeBranch.name);

      _setViewState(
        ViewState.success,
        'Welcome to Boss Arman MotoHub, ${newCustomer.fullName}!',
      );
      return true;
    } catch (e) {
      _setViewState(ViewState.error, 'Registration failed: $e');
      return false;
    }
  }

  /// Google One-Tap / Google Sign-In Handler for `main_customer.dart`
  Future<bool> signInCustomerWithGoogle({
    required String email,
    required String displayName,
    BranchId preferredBranch = BranchId.patimbao,
  }) async {
    _setViewState(ViewState.loading);
    try {
      final cleanEmail = email.trim().toLowerCase();
      if (cleanEmail.isEmpty || !cleanEmail.contains('@')) {
        _setViewState(ViewState.error, 'Invalid Google account email.');
        return false;
      }

      final existing = _staffList
          .where((s) =>
              s.role == UserRole.customer &&
              s.email.toLowerCase() == cleanEmail)
          .toList();

      StaffAccount customer;
      if (existing.isNotEmpty) {
        customer = existing.first;
      } else {
        final nameParts = displayName.trim().split(RegExp(r'\s+'));
        final firstName = nameParts.isNotEmpty && nameParts.first.isNotEmpty
            ? nameParts.first
            : cleanEmail.split('@').first;
        final lastName =
            nameParts.length > 1 ? nameParts.sublist(1).join(' ') : 'Rider';
        final generatedUsername = cleanEmail.split('@').first.toLowerCase();

        customer = StaffAccount(
          id: _generateId('GGL'),
          firstName: firstName,
          lastName: lastName,
          username: generatedUsername,
          email: cleanEmail,
          password: 'AUTH_PROVIDER_GOOGLE_${_uuid.v4()}',
          role: UserRole.customer,
          assignedBranch: preferredBranch,
          shiftStatus: 'Google Verified',
          authProvider: 'google',
          createdAt: DateTime.now(),
        );
        await _db.saveStaff(customer);
        _staffList.add(customer);
      }

      _currentUser = customer;
      _activeBranch = customer.assignedBranch == BranchId.both
          ? BranchId.patimbao
          : customer.assignedBranch;

      final prefs = await SharedPreferences.getInstance();
      await prefs.setString('cached_customer_user', customer.username);
      await prefs.setString('cached_branch', _activeBranch.name);

      _setViewState(
        ViewState.success,
        'Signed in with Google as ${customer.fullName} (${customer.email})',
      );
      return true;
    } catch (e) {
      _setViewState(ViewState.error, 'Google Sign-In failed: $e');
      return false;
    }
  }

  /// Google One-Tap / Google Sign-In for Staff & Management (Internal App)
  /// Enforces that the Google email MUST already be registered by Admin as an authorized staff account (Admin, Cashier, or Mechanic).
  /// If not found in staff directory, login is strictly REJECTED.
  Future<bool> signInStaffWithGoogle({
    required String email,
    String? displayName,
  }) async {
    _setViewState(ViewState.loading);
    try {
      final cleanEmail = email.trim().toLowerCase();
      if (cleanEmail.isEmpty || !cleanEmail.contains('@')) {
        _setViewState(ViewState.error, 'Invalid Google account email address.');
        return false;
      }

      // Check against registered staff list (must NOT be customer)
      final matchedStaff = _staffList.where((s) =>
          s.email.trim().toLowerCase() == cleanEmail &&
          s.role != UserRole.customer).toList();

      if (matchedStaff.isEmpty) {
        _setViewState(
          ViewState.error,
          'Account not found. Google email "$cleanEmail" is not registered as an authorized staff account. Please contact Boss Arman to register your email in the Admin Panel.',
        );
        return false;
      }

      final staff = matchedStaff.first;
      _currentUser = staff;
      _activeBranch = (staff.role == UserRole.cashier || staff.role == UserRole.mechanic)
          ? (staff.assignedBranch == BranchId.both ? BranchId.patimbao : staff.assignedBranch)
          : staff.assignedBranch;

      final prefs = await SharedPreferences.getInstance();
      await prefs.setString('cached_internal_user', staff.username);
      await prefs.setString('cached_branch', _activeBranch.name);

      _setViewState(
        ViewState.success,
        'Authenticated as ${staff.role.label}: ${staff.fullName}',
      );
      return true;
    } catch (e) {
      _setViewState(ViewState.error, 'Google Sign-In failed: $e');
      return false;
    }
  }

  Future<void> logout() async {
    _currentUser = null;
    _cart.clear();
    try {
      final prefs = await SharedPreferences.getInstance();
      if (isCustomerApp) {
        await prefs.remove('cached_customer_user');
      } else {
        await prefs.remove('cached_internal_user');
      }
    } catch (_) {}
    _setViewState(ViewState.idle);
  }

  // ---------------------------------------------------------------------------
  // Password Recovery & Email OTP Verification
  // ---------------------------------------------------------------------------

  Future<bool> sendPasswordResetOtp(String email) async {
    return _firebase.sendPasswordResetOtp(email);
  }

  Future<String> sendAccountRegistrationOtp(String email) async {
    return _firebase.sendAccountRegistrationOtp(email);
  }

  bool verifyAccountRegistrationOtp(String email, String otp) {
    return _firebase.verifyAccountRegistrationOtp(email, otp);
  }

  int getRemainingResendCooldown(String email) {
    return _firebase.getRemainingResendCooldownSeconds(email);
  }

  bool verifyPasswordResetOtp(String email, String otp) {
    return _firebase.verifyPasswordResetOtp(email, otp);
  }

  Future<bool> resetPasswordWithOtp({
    required String email,
    required String otp,
    required String newPassword,
  }) async {
    _setViewState(ViewState.loading);
    try {
      final verified = _firebase.verifyPasswordResetOtp(email, otp);
      if (!verified) {
        _setViewState(ViewState.error, 'Invalid or expired 6-digit OTP verification code.');
        return false;
      }
      await _firebase.resetPasswordWithOtp(
        email: email,
        otp: otp,
        newPassword: newPassword,
      );

      // Also update local staff account password if present
      final sIdx = _staffList.indexWhere(
        (s) => s.email.toLowerCase() == email.trim().toLowerCase(),
      );
      if (sIdx >= 0) {
        final existing = _staffList[sIdx];
        final updated = StaffAccount(
          id: existing.id,
          firstName: existing.firstName,
          lastName: existing.lastName,
          username: existing.username,
          email: existing.email,
          password: newPassword,
          role: existing.role,
          assignedBranch: existing.assignedBranch,
          shiftStatus: existing.shiftStatus,
          coveredByStaff: existing.coveredByStaff,
          authProvider: existing.authProvider,
          fcmToken: existing.fcmToken,
          createdAt: existing.createdAt,
        );
        _staffList[sIdx] = updated;
        await _db.saveStaff(updated);
      }

      _setViewState(ViewState.success, 'Password successfully reset! Please log in.');
      return true;
    } catch (e) {
      _setViewState(ViewState.error, 'Failed to reset password: $e');
      return false;
    }
  }

  Future<void> switchBranch(BranchId branch) async {
    if (branch == BranchId.both) return;
    if (isBranchLockedForCurrentUser) {
      final lockedBranch = _currentUser!.assignedBranch == BranchId.both
          ? BranchId.patimbao
          : _currentUser!.assignedBranch;
      _activeBranch = lockedBranch;
      _setViewState(
        ViewState.error,
        'Branch locked to ${lockedBranch.displayName}. Only the Admin can change your assigned branch.',
      );
      return;
    }
    if (_activeBranch == branch) return;
    _activeBranch = branch;
    _cart.clear();
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setString('cached_branch', branch.name);
    } catch (_) {}
    _setViewState(
      ViewState.success,
      'Switched context to ${branch.displayName}',
    );
  }

  Future<void> setActiveBranch(BranchId branch) => switchBranch(branch);

  // ---------------------------------------------------------------------------
  // Offline-First Connectivity & Background Sync Worker
  // ---------------------------------------------------------------------------

  Future<void> toggleConnectivity() async {
    _isOnline = !_isOnline;
    if (_isOnline && pendingSyncCount > 0) {
      await syncPendingLogs();
    } else {
      _setViewState(
        ViewState.idle,
        _isOnline
            ? 'Network Online • Real-time Cloud Sync Active'
            : 'Offline Mode Active • Writing all transactions to local SQLite first',
      );
    }
  }

  void _enqueueIfOffline(String operation, String summary) {
    if (_isOnline) return;
    _offlineQueue.insert(
      0,
      OfflineSyncTask(
        id: 'SYNC-${DateTime.now().millisecondsSinceEpoch}',
        operation: operation,
        summary: summary,
        branch: _activeBranch,
        timestamp: DateTime.now(),
        synced: false,
      ),
    );
  }

  Future<void> syncPendingLogs() async {
    if (_isSyncing) return;
    _isSyncing = true;
    notifyListeners();

    try {
      await Future<void>.delayed(const Duration(milliseconds: 500));
      for (var i = 0; i < _offlineQueue.length; i++) {
        _offlineQueue[i] = _offlineQueue[i].copyWith(synced: true);
      }
      for (var i = 0; i < _transactions.length; i++) {
        if (!_transactions[i].isSynced) {
          final updated = _transactions[i].copyWith(isSynced: true);
          _transactions[i] = updated;
          await _db.saveTransaction(updated);
        }
      }
      _isSyncing = false;
      _setViewState(
        ViewState.success,
        'All queued offline SQLite records synchronized.',
      );
    } catch (e) {
      _isSyncing = false;
      _setViewState(ViewState.error, 'Sync failed: $e');
    }
  }

  // ---------------------------------------------------------------------------
  // Search, Filters & Barcode Lookup
  // ---------------------------------------------------------------------------

  void setInventorySearchQuery(String query) {
    _inventorySearchQuery = query;
    notifyListeners();
  }

  void setSelectedPosCategory(String category) {
    _selectedPosCategory = category;
    notifyListeners();
  }

  void setSelectedJobStatusFilter(JobStatus? status) {
    _selectedJobStatusFilter = status;
    notifyListeners();
  }

  InventoryItem? findPartByCode(String code) {
    final clean = code.trim().toLowerCase();
    if (clean.isEmpty) return null;
    for (final item in _inventory) {
      if (item.barcode.toLowerCase() == clean ||
          item.sku.toLowerCase() == clean ||
          item.id.toLowerCase() == clean) {
        return item;
      }
    }
    return null;
  }

  // ---------------------------------------------------------------------------
  // Master Inventory & Atomic Two-Phase Inter-Branch Transfer Protocol
  // ---------------------------------------------------------------------------

  Future<bool> addOrUpdateInventoryItem(InventoryItem item) async {
    if (!_isValidCurrency(item.price) ||
        !_isValidCurrency(item.costPrice) ||
        item.stockPatimbao < 0 ||
        item.stockPedroGuevara < 0) {
      _setViewState(
        ViewState.error,
        'Invalid price or negative stock quantity rejected.',
      );
      return false;
    }
    if (item.stockPatimbao < item.lockedPatimbao ||
        item.stockPedroGuevara < item.lockedPedroGuevara) {
      _setViewState(
        ViewState.error,
        'Stock cannot be set lower than units currently locked in active service bays or reservations.',
      );
      return false;
    }

    try {
      await _db.saveInventoryItem(item);
      final idx = _inventory.indexWhere((e) => e.id == item.id);
      if (idx >= 0) {
        _inventory[idx] = item;
      } else {
        _inventory.insert(0, item);
      }
      final cartIdx = _cart.indexWhere((c) => c.item.id == item.id);
      if (cartIdx >= 0) {
        final avail = item.availableStockFor(_activeBranch);
        if (avail <= 0) {
          _cart.removeAt(cartIdx);
        } else {
          _cart[cartIdx] = CartItem(
            item: item,
            quantity: _cart[cartIdx].quantity.clamp(1, avail),
          );
        }
      }
      _enqueueIfOffline('INVENTORY_UPSERT', '${item.sku} (${item.name})');
      _setViewState(
        ViewState.success,
        'Saved ${item.name} (${item.shelfCoordinates}) to SQLite.',
      );
      return true;
    } catch (e) {
      _setViewState(ViewState.error, 'Failed to save inventory item: $e');
      return false;
    }
  }

  Future<bool> deleteInventoryItem(String id) async {
    final idx = _inventory.indexWhere((e) => e.id == id);
    if (idx >= 0) {
      final target = _inventory[idx];
      if (target.lockedPatimbao > 0 || target.lockedPedroGuevara > 0) {
        _setViewState(
          ViewState.error,
          'Cannot delete ${target.name} while units are locked in active jobs or reservations.',
        );
        return false;
      }
      final hasInTransit = _transfers.any(
        (t) => t.partId == id && t.status == TransferStatus.inTransit,
      );
      if (hasInTransit) {
        _setViewState(
          ViewState.error,
          'Cannot delete ${target.name} while an inter-branch transfer is in-transit.',
        );
        return false;
      }
    }
    try {
      await _db.deleteInventoryItem(id);
      _inventory.removeWhere((e) => e.id == id);
      _cart.removeWhere((c) => c.item.id == id);
      _setViewState(ViewState.success, 'Removed item from inventory.');
      return true;
    } catch (e) {
      _setViewState(ViewState.error, 'Failed to delete inventory item: $e');
      return false;
    }
  }

  /// Strict Approval Transfer Workflow Phase 1: Branch A requests stock from Branch B.
  /// Status is [pendingApproval]; NO stock is decremented yet from Branch B.
  Future<bool> requestStockTransfer({
    required InventoryItem item,
    required BranchId fromBranch,
    required BranchId toBranch,
    required int quantity,
  }) async {
    if (fromBranch == toBranch ||
        fromBranch == BranchId.both ||
        toBranch == BranchId.both) {
      _setViewState(
        ViewState.error,
        'Source and destination branches must be two distinct branches.',
      );
      return false;
    }
    if (quantity <= 0) {
      _setViewState(
        ViewState.error,
        'Transfer quantity must be greater than 0.',
      );
      return false;
    }
    final pIdx = _inventory.indexWhere((e) => e.id == item.id);
    final liveItem = pIdx >= 0 ? _inventory[pIdx] : item;
    final available = liveItem.availableStockFor(fromBranch);
    if (quantity > available) {
      _setViewState(
        ViewState.error,
        'Cannot request $quantity units: only $available available at ${fromBranch.shortName}.',
      );
      return false;
    }

    try {
      final transfer = StockTransfer(
        id: _generateId('TRF'),
        partId: liveItem.id,
        sku: liveItem.sku,
        partName: liveItem.name,
        quantity: quantity,
        fromBranch: fromBranch,
        toBranch: toBranch,
        status: TransferStatus.pendingApproval,
        initiatedBy: _currentUser?.fullName ?? 'Authorized Staff',
        createdAt: DateTime.now(),
      );

      final notif = AppNotificationItem(
        id: _generateId('NTF'),
        title: 'Transfer Request Pending (${transfer.id})',
        message:
            '${toBranch.shortName} requested ${quantity}x ${liveItem.name} from ${fromBranch.shortName}. Requires Approval.',
        category: 'transfer',
        branch: fromBranch,
        isRead: false,
        createdAt: DateTime.now(),
      );

      await _db.executeStockTransferTransaction(
        updatedItem: null, // NO stock deduction yet!
        transfer: transfer,
        notification: notif,
      );

      _transfers.insert(0, transfer);
      _notifications.insert(0, notif);
      _firebase.syncStockTransferToFirestore(transfer);

      _enqueueIfOffline(
        'TRANSFER_REQ',
        '${transfer.id}: ${quantity}x ${liveItem.sku} (${fromBranch.shortName} -> ${toBranch.shortName})',
      );

      _setViewState(
        ViewState.success,
        'Stock transfer request ${transfer.id} submitted for ${fromBranch.shortName} approval.',
      );
      return true;
    } catch (e) {
      _setViewState(ViewState.error, 'Failed to submit transfer request: $e');
      return false;
    }
  }

  /// Strict Approval Transfer Workflow Phase 2: Source branch cashier or Admin APPROVES.
  /// Stock is decremented from source branch and status becomes [inTransit].
  Future<bool> approveStockTransfer(StockTransfer transfer) async {
    if (transfer.status != TransferStatus.pendingApproval) {
      _setViewState(ViewState.error, 'Transfer is not pending approval.');
      return false;
    }

    if (_currentUser != null &&
        _currentUser!.role != UserRole.admin &&
        _currentUser!.assignedBranch != transfer.fromBranch &&
        _currentUser!.assignedBranch != BranchId.both) {
      _setViewState(
        ViewState.error,
        'Access Denied: Only staff assigned to source branch (${transfer.fromBranch.displayName}) or Admin can approve this transfer.',
      );
      return false;
    }

    final tIdx = _transfers.indexWhere((t) => t.id == transfer.id);
    final pIdx = _inventory.indexWhere((p) => p.id == transfer.partId);
    if (tIdx < 0 || pIdx < 0) {
      _setViewState(ViewState.error, 'Transfer or part record not found.');
      return false;
    }

    final liveItem = _inventory[pIdx];
    final available = liveItem.availableStockFor(transfer.fromBranch);
    if (transfer.quantity > available) {
      _setViewState(
        ViewState.error,
        'Insufficient stock at ${transfer.fromBranch.shortName} ($available available).',
      );
      return false;
    }

    try {
      final updatedItem = liveItem.copyWith(
        stockPatimbao: transfer.fromBranch == BranchId.patimbao
            ? liveItem.stockPatimbao - transfer.quantity
            : liveItem.stockPatimbao,
        stockPedroGuevara: transfer.fromBranch == BranchId.pedroGuevara
            ? liveItem.stockPedroGuevara - transfer.quantity
            : liveItem.stockPedroGuevara,
      );

      final approvedTransfer = transfer.copyWith(
        status: TransferStatus.inTransit,
        approvedBy: _currentUser?.fullName ?? 'Branch Manager',
        approvedAt: DateTime.now(),
      );

      final notif = AppNotificationItem(
        id: _generateId('NTF'),
        title: 'Transfer Approved & Dispatched (${transfer.id})',
        message:
            '${transfer.quantity}x ${transfer.partName} approved by ${transfer.fromBranch.shortName}. Shipment now In-Transit.',
        category: 'transfer',
        branch: transfer.toBranch,
        isRead: false,
        createdAt: DateTime.now(),
      );

      await _db.executeStockTransferTransaction(
        updatedItem: updatedItem,
        transfer: approvedTransfer,
        notification: notif,
      );

      _inventory[pIdx] = updatedItem;
      _transfers[tIdx] = approvedTransfer;
      _notifications.insert(0, notif);
      _firebase.syncStockTransferToFirestore(approvedTransfer);

      _enqueueIfOffline(
        'TRANSFER_APPROVE',
        '${transfer.id} approved by ${transfer.fromBranch.shortName}',
      );

      _setViewState(
        ViewState.success,
        'Transfer ${transfer.id} approved and marked In-Transit.',
      );
      return true;
    } catch (e) {
      _setViewState(ViewState.error, 'Failed to approve transfer: $e');
      return false;
    }
  }

  /// Strict Approval Transfer Workflow Phase 2b: Source branch REJECTS.
  /// No stock moved. Status set to [rejected].
  Future<bool> rejectStockTransfer(StockTransfer transfer, String reason) async {
    if (transfer.status != TransferStatus.pendingApproval) return false;

    if (_currentUser != null &&
        _currentUser!.role != UserRole.admin &&
        _currentUser!.assignedBranch != transfer.fromBranch &&
        _currentUser!.assignedBranch != BranchId.both) {
      _setViewState(
        ViewState.error,
        'Access Denied: Only staff assigned to source branch (${transfer.fromBranch.displayName}) or Admin can reject this transfer.',
      );
      return false;
    }

    final tIdx = _transfers.indexWhere((t) => t.id == transfer.id);
    if (tIdx < 0) return false;

    try {
      final rejectedTransfer = transfer.copyWith(
        status: TransferStatus.rejected,
        rejectionReason: reason.trim().isEmpty ? 'Rejected by source branch cashier' : reason.trim(),
        rejectedBy: _currentUser?.fullName ?? 'Branch Manager',
        rejectedAt: DateTime.now(),
      );

      final notif = AppNotificationItem(
        id: _generateId('NTF'),
        title: 'Transfer Request Rejected (${transfer.id})',
        message:
            'Transfer of ${transfer.quantity}x ${transfer.partName} was rejected: ${rejectedTransfer.rejectionReason}',
        category: 'transfer',
        branch: transfer.toBranch,
        isRead: false,
        createdAt: DateTime.now(),
      );

      await _db.executeStockTransferTransaction(
        updatedItem: null,
        transfer: rejectedTransfer,
        notification: notif,
      );

      _transfers[tIdx] = rejectedTransfer;
      _notifications.insert(0, notif);
      _firebase.syncStockTransferToFirestore(rejectedTransfer);

      _setViewState(
        ViewState.success,
        'Transfer request ${transfer.id} rejected.',
      );
      return true;
    } catch (e) {
      _setViewState(ViewState.error, 'Failed to reject transfer: $e');
      return false;
    }
  }

  /// Backward compatible / direct initiation (used by Admin & unit tests)
  Future<bool> initiateStockTransfer({
    required InventoryItem item,
    required BranchId fromBranch,
    required BranchId toBranch,
    required int quantity,
  }) async {
    if (fromBranch == toBranch ||
        fromBranch == BranchId.both ||
        toBranch == BranchId.both) {
      _setViewState(
        ViewState.error,
        'Source and destination branches must be two distinct branches.',
      );
      return false;
    }
    if (quantity <= 0) {
      _setViewState(
        ViewState.error,
        'Transfer quantity must be greater than 0.',
      );
      return false;
    }
    final pIdx = _inventory.indexWhere((e) => e.id == item.id);
    final liveItem = pIdx >= 0 ? _inventory[pIdx] : item;
    final available = liveItem.availableStockFor(fromBranch);
    if (quantity > available) {
      _setViewState(
        ViewState.error,
        'Insufficient available stock at ${fromBranch.shortName} ($available available).',
      );
      return false;
    }

    try {
      final updatedItem = liveItem.copyWith(
        stockPatimbao: fromBranch == BranchId.patimbao
            ? liveItem.stockPatimbao - quantity
            : liveItem.stockPatimbao,
        stockPedroGuevara: fromBranch == BranchId.pedroGuevara
            ? liveItem.stockPedroGuevara - quantity
            : liveItem.stockPedroGuevara,
      );

      final transfer = StockTransfer(
        id: _generateId('TRF'),
        partId: liveItem.id,
        sku: liveItem.sku,
        partName: liveItem.name,
        quantity: quantity,
        fromBranch: fromBranch,
        toBranch: toBranch,
        status: TransferStatus.inTransit,
        initiatedBy: _currentUser?.fullName ?? 'Authorized Staff',
        approvedBy: _currentUser?.fullName ?? 'Direct Dispatch',
        approvedAt: DateTime.now(),
        createdAt: DateTime.now(),
      );

      final notif = AppNotificationItem(
        id: _generateId('NTF'),
        title: 'Shipment In-Transit (${transfer.id})',
        message:
            '${quantity}x ${liveItem.name} dispatched from ${fromBranch.shortName} to ${toBranch.shortName}. Awaiting [Confirm Delivery].',
        category: 'transfer',
        branch: toBranch,
        isRead: false,
        createdAt: DateTime.now(),
      );

      await _db.executeStockTransferTransaction(
        updatedItem: updatedItem,
        transfer: transfer,
        notification: notif,
      );

      if (pIdx >= 0) _inventory[pIdx] = updatedItem;
      _transfers.insert(0, transfer);
      _notifications.insert(0, notif);
      _firebase.syncStockTransferToFirestore(transfer);

      _enqueueIfOffline(
        'TRANSFER_INIT',
        '${transfer.id}: ${quantity}x ${liveItem.sku} (${fromBranch.shortName} -> ${toBranch.shortName})',
      );

      _setViewState(
        ViewState.success,
        'Transfer ${transfer.id} marked In-Transit. Deducted $quantity units from ${fromBranch.shortName}.',
      );
      return true;
    } catch (e) {
      _setViewState(ViewState.error, 'Stock transfer failed (rolled back): $e');
      return false;
    }
  }

  /// Strict Approval Transfer Workflow Phase 3:
  /// Destination branch cashier inspects physical parts upon arrival and taps Confirm Receipt.
  Future<bool> confirmTransferDelivery(StockTransfer transfer) async {
    if (transfer.status != TransferStatus.inTransit) {
      _setViewState(
        ViewState.error,
        'Only in-transit transfers can be confirmed as delivered.',
      );
      return false;
    }

    if (_currentUser != null &&
        _currentUser!.role != UserRole.admin &&
        _currentUser!.assignedBranch != transfer.toBranch &&
        _currentUser!.assignedBranch != BranchId.both) {
      _setViewState(
        ViewState.error,
        'Access Denied: Only staff assigned to ${transfer.toBranch.displayName} or Admin can confirm delivery.',
      );
      return false;
    }

    final tIdx = _transfers.indexWhere((t) => t.id == transfer.id);
    final pIdx = _inventory.indexWhere((p) => p.id == transfer.partId);
    if (tIdx < 0 || pIdx < 0) {
      _setViewState(ViewState.error, 'Transfer or target part no longer exists.');
      return false;
    }

    try {
      final currentPart = _inventory[pIdx];
      final updatedPart = currentPart.copyWith(
        stockPatimbao: transfer.toBranch == BranchId.patimbao
            ? currentPart.stockPatimbao + transfer.quantity
            : currentPart.stockPatimbao,
        stockPedroGuevara: transfer.toBranch == BranchId.pedroGuevara
            ? currentPart.stockPedroGuevara + transfer.quantity
            : currentPart.stockPedroGuevara,
      );

      final updatedTransfer = transfer.copyWith(
        status: TransferStatus.delivered,
        confirmedBy: _currentUser?.fullName ?? 'Branch Receiver',
        confirmedAt: DateTime.now(),
      );

      final notif = AppNotificationItem(
        id: _generateId('NTF'),
        title: 'Delivery Confirmed (${transfer.id})',
        message:
            '${transfer.quantity}x ${transfer.partName} received and credited to ${transfer.toBranch.shortName} stock.',
        category: 'transfer',
        branch: transfer.toBranch,
        isRead: false,
        createdAt: DateTime.now(),
      );

      await _db.executeStockTransferTransaction(
        updatedItem: updatedPart,
        transfer: updatedTransfer,
        notification: notif,
      );

      _inventory[pIdx] = updatedPart;
      _transfers[tIdx] = updatedTransfer;
      _notifications.insert(0, notif);
      _firebase.syncStockTransferToFirestore(updatedTransfer);

      _enqueueIfOffline(
        'TRANSFER_CONFIRM',
        '${transfer.id} credited +${transfer.quantity} to ${transfer.toBranch.shortName}',
      );

      _setViewState(
        ViewState.success,
        'Confirmed receipt for ${transfer.id}. Added ${transfer.quantity} to ${transfer.toBranch.shortName} stock.',
      );
      return true;
    } catch (e) {
      _setViewState(ViewState.error, 'Failed to confirm delivery: $e');
      return false;
    }
  }

  /// Alias for confirmTransferDelivery matching specification
  Future<bool> confirmStockTransferReceipt(StockTransfer transfer) =>
      confirmTransferDelivery(transfer);


  // ---------------------------------------------------------------------------
  // Mechanic Bay Lifecycle, Atomic Parts Locking & Customer Booking
  // ---------------------------------------------------------------------------

  Future<JobOrder?> createJobOrder({
    required String customerName,
    required String customerPhone,
    required String bikeModel,
    required String plateNumber,
    required String serviceType,
    required String issueDescription,
    required String assignedMechanic,
    required double laborFee,
    BranchId? targetBranch,
    String? preferredSchedule,
    String? customerUsername,
  }) async {
    if (_currentUser != null && _currentUser!.role != UserRole.customer) {
      _setViewState(
        ViewState.error,
        'Adding/booking service job orders is a Customer-only function. Admin & Mechanics can only accept incoming customer bookings.',
      );
      return null;
    }
    final plateError = AppValidators.plateNumber(plateNumber);
    if (plateError != null) {
      _setViewState(ViewState.error, plateError);
      return null;
    }
    if (!_isValidCurrency(laborFee)) {
      _setViewState(ViewState.error, 'Invalid labor fee amount.');
      return null;
    }

    try {
      final branch = targetBranch ?? _activeBranch;
      final job = JobOrder(
        id: _generateId('JO'),
        branch: branch,
        customerName: customerName.trim(),
        customerUsername:
            (customerUsername ?? _currentUser?.username ?? '').trim(),
        customerPhone: customerPhone.trim(),
        bikeModel: bikeModel.trim(),
        plateNumber: plateNumber.trim().toUpperCase(),
        serviceType: serviceType.trim(),
        issueDescription: issueDescription.trim(),
        assignedMechanic: assignedMechanic.trim(),
        status: JobStatus.received,
        attachedParts: const [],
        laborFee: laborFee,
        preferredSchedule: preferredSchedule ?? 'Walk-in • Immediate',
        createdAt: DateTime.now(),
        updatedAt: DateTime.now(),
      );

      await _db.saveJobOrder(job);
      _jobOrders.insert(0, job);
      _firebase.syncJobOrderToFirestore(job);

      await _pushNotification(
        title: 'New Repair Job Order (${job.id})',
        message:
            '${job.bikeModel} (${job.plateNumber}) assigned to ${job.assignedMechanic} at ${branch.shortName}.',
        category: 'job_order',
        branch: branch,
      );

      _enqueueIfOffline('JOB_CREATE', '${job.id} (${job.plateNumber})');
      _setViewState(
        ViewState.success,
        'Created Job Order ${job.id} for ${job.bikeModel} (${job.plateNumber}).',
      );
      return job;
    } catch (e) {
      _setViewState(ViewState.error, 'Failed to create job order: $e');
      return null;
    }
  }

  Future<bool> updateJobOrderStatus(String jobId, JobStatus newStatus) async {
    final idx = _jobOrders.indexWhere((j) => j.id == jobId);
    if (idx < 0) return false;

    try {
      final current = _jobOrders[idx];
      final updated = current.copyWith(
        status: newStatus,
        updatedAt: DateTime.now(),
      );
      await _db.saveJobOrder(updated);
      _jobOrders[idx] = updated;

      if (newStatus == JobStatus.readyForPickup) {
        await _pushNotification(
          title: 'Service-to-POS Auto-Billing Ready (${updated.id})',
          message:
              '${updated.bikeModel} (${updated.plateNumber}) is Ready for Pickup. Total bill: ₱${updated.totalEstimate.toStringAsFixed(2)}.',
          category: 'job_order',
          branch: updated.branch,
        );

        // Automated Customer Push Notifications (FCM) via FirebaseService
        final customer = _staffList
            .where((s) =>
                s.username.toLowerCase() ==
                    updated.customerUsername.toLowerCase() ||
                s.fullName.toLowerCase() ==
                    updated.customerName.toLowerCase())
            .toList();
        final fcmToken = customer.isNotEmpty ? customer.first.fcmToken : null;
        await _firebase.sendJobReadyPushNotification(
          jobId: updated.id,
          bikeModel: updated.bikeModel,
          customerFcmToken: fcmToken,
          branch: updated.branch,
        );
      }

      // Real-time Firestore sync across apps
      await _firebase.syncJobOrderToFirestore(updated);

      _enqueueIfOffline(
        'JOB_STATUS',
        '${updated.id} -> ${newStatus.label}',
      );
      _setViewState(
        ViewState.success,
        'Updated ${updated.id} status to "${newStatus.label}".',
      );
      return true;
    } catch (e) {
      _setViewState(ViewState.error, 'Failed to update job status: $e');
      return false;
    }
  }

  /// Accepts an incoming Customer Job Order (`JobStatus.received` -> `JobStatus.inBay`)
  /// by either Admin or Mechanic and assigns the bay lift.
  Future<bool> acceptJobOrder(String jobId, {String? mechanicName}) async {
    final idx = _jobOrders.indexWhere((j) => j.id == jobId);
    if (idx < 0) return false;

    try {
      final current = _jobOrders[idx];
      final resolvedMechanic = (mechanicName != null &&
              mechanicName.trim().isNotEmpty)
          ? mechanicName.trim()
          : (_currentUser?.role == UserRole.mechanic
              ? _currentUser!.fullName
              : current.assignedMechanic);

      final updated = current.copyWith(
        status: JobStatus.inBay,
        assignedMechanic: resolvedMechanic,
        updatedAt: DateTime.now(),
      );
      await _db.saveJobOrder(updated);
      _jobOrders[idx] = updated;
      _firebase.syncJobOrderToFirestore(updated);

      await _pushNotification(
        title: 'Job Order Accepted (${updated.id})',
        message:
            '${updated.bikeModel} (${updated.plateNumber}) accepted into ${updated.branch.shortName} bay by ${_currentUser?.fullName ?? resolvedMechanic}.',
        category: 'job_order',
        branch: updated.branch,
      );

      _enqueueIfOffline(
        'JOB_ACCEPT',
        '${updated.id} accepted into bay ($resolvedMechanic)',
      );
      _setViewState(
        ViewState.success,
        'Accepted Job Order ${updated.id} into ${updated.branch.shortName} Repair Bay!',
      );
      return true;
    } catch (e) {
      _setViewState(ViewState.error, 'Failed to accept job order: $e');
      return false;
    }
  }

  /// Cancels an active or pending Job Order:
  /// Releases all locked parts attached to the job back to available inventory.
  Future<bool> cancelJobOrder(String jobId) async {
    final jIdx = _jobOrders.indexWhere((j) => j.id == jobId);
    if (jIdx < 0) return false;
    final job = _jobOrders[jIdx];

    if (job.status == JobStatus.completed || job.status == JobStatus.cancelled) {
      _setViewState(
        ViewState.error,
        'Cannot cancel job in status: ${job.status.label}.',
      );
      return false;
    }

    try {
      // Release locked stock for all attached parts
      for (final ap in job.attachedParts) {
        final pIdx = _inventory.indexWhere((p) => p.id == ap.partId);
        if (pIdx >= 0) {
          final cur = _inventory[pIdx];
          final updatedPart = cur.copyWith(
            lockedPatimbao: job.branch == BranchId.patimbao
                ? (cur.lockedPatimbao - ap.quantity).clamp(0, 999999)
                : cur.lockedPatimbao,
            lockedPedroGuevara: job.branch == BranchId.pedroGuevara
                ? (cur.lockedPedroGuevara - ap.quantity).clamp(0, 999999)
                : cur.lockedPedroGuevara,
          );
          await _db.saveInventoryItem(updatedPart);
          _inventory[pIdx] = updatedPart;
          await _firebase.syncInventoryItemToFirestore(updatedPart);
        }
      }

      final updatedJob = job.copyWith(
        status: JobStatus.cancelled,
        updatedAt: DateTime.now(),
      );
      await _db.saveJobOrder(updatedJob);
      _jobOrders[jIdx] = updatedJob;
      await _firebase.syncJobOrderToFirestore(updatedJob);

      await _pushNotification(
        title: 'Job Order Cancelled (${updatedJob.id})',
        message:
            '${updatedJob.bikeModel} (${updatedJob.plateNumber}) cancelled. Reserved parts unlocked.',
        category: 'job_order',
        branch: updatedJob.branch,
      );

      _setViewState(
        ViewState.success,
        'Job Order ${updatedJob.id} cancelled. Reserved parts released.',
      );
      return true;
    } catch (e) {
      _setViewState(ViewState.error, 'Failed to cancel job order: $e');
      return false;
    }
  }

  /// Click & Collect orders for the active branch
  List<ClickAndCollectOrder> get branchClickCollectOrders {
    return _clickCollectOrders
        .where((o) => o.pickupBranch == _activeBranch)
        .toList();
  }

  /// Accepts a Customer Click & Collect Part Order in Admin/Mechanic panel
  Future<bool> acceptClickAndCollectOrder(String orderId) async {
    final idx = _clickCollectOrders.indexWhere((o) => o.id == orderId);
    if (idx < 0) return false;

    try {
      final cur = _clickCollectOrders[idx];
      final updated = ClickAndCollectOrder(
        id: cur.id,
        customerUsername: cur.customerUsername,
        customerName: cur.customerName,
        customerPhone: cur.customerPhone,
        pickupBranch: cur.pickupBranch,
        partId: cur.partId,
        sku: cur.sku,
        partName: cur.partName,
        quantity: cur.quantity,
        unitPrice: cur.unitPrice,
        status: 'Accepted • Ready for Counter Pickup',
        createdAt: cur.createdAt,
      );
      await _db.saveClickCollectOrder(updated);
      _clickCollectOrders[idx] = updated;

      await _pushNotification(
        title: 'Click & Collect Order Accepted (${updated.id})',
        message:
            'Order ${updated.id} (${updated.quantity}x ${updated.partName}) accepted for ${updated.customerName}.',
        category: 'booking',
        branch: updated.pickupBranch,
      );

      _setViewState(
        ViewState.success,
        'Accepted Customer Order ${updated.id} (${updated.quantity}x ${updated.partName})!',
      );
      return true;
    } catch (e) {
      _setViewState(ViewState.error, 'Failed to accept order: $e');
      return false;
    }
  }

  /// Atomic Parts Attachment Engine: Locks part in local stock & attaches to JobOrder
  Future<bool> attachPartToJobOrder({
    required String jobId,
    required InventoryItem part,
    int quantity = 1,
  }) async {
    if (quantity <= 0) {
      _setViewState(ViewState.error, 'Quantity must be positive.');
      return false;
    }
    final jIdx = _jobOrders.indexWhere((j) => j.id == jobId);
    final pIdx = _inventory.indexWhere((p) => p.id == part.id);
    if (jIdx < 0 || pIdx < 0) return false;

    final job = _jobOrders[jIdx];
    if (job.isBilled || job.status == JobStatus.completed) {
      _setViewState(
        ViewState.error,
        'Cannot attach parts to a completed or billed Job Order.',
      );
      return false;
    }

    final livePart = _inventory[pIdx];

    final avail = livePart.availableStockFor(job.branch);
    if (avail < quantity) {
      _setViewState(
        ViewState.error,
        'Cannot attach ${livePart.name}: only $avail unlocked unit(s) available in ${job.branch.shortName}.',
      );
      return false;
    }

    try {
      final updatedPart = livePart.copyWith(
        lockedPatimbao: job.branch == BranchId.patimbao
            ? livePart.lockedPatimbao + quantity
            : livePart.lockedPatimbao,
        lockedPedroGuevara: job.branch == BranchId.pedroGuevara
            ? livePart.lockedPedroGuevara + quantity
            : livePart.lockedPedroGuevara,
      );

      final currentParts = List<AttachedJobPart>.from(job.attachedParts);
      final existingIdx =
          currentParts.indexWhere((ap) => ap.partId == livePart.id);
      if (existingIdx >= 0) {
        currentParts[existingIdx] = currentParts[existingIdx].copyWith(
          quantity: currentParts[existingIdx].quantity + quantity,
        );
      } else {
        currentParts.add(
          AttachedJobPart(
            partId: livePart.id,
            sku: livePart.sku,
            name: livePart.name,
            unitPrice: livePart.price,
            quantity: quantity,
            shelfCoordinates: livePart.shelfCoordinates,
          ),
        );
      }

      final updatedJob = job.copyWith(
        attachedParts: currentParts,
        updatedAt: DateTime.now(),
      );

      await _db.executeJobPartLockTransaction(
        updatedItem: updatedPart,
        updatedJob: updatedJob,
      );

      _inventory[pIdx] = updatedPart;
      _jobOrders[jIdx] = updatedJob;
      _firebase.syncJobOrderToFirestore(updatedJob);

      _enqueueIfOffline(
        'JOB_LOCK_PART',
        'Locked ${quantity}x ${livePart.sku} to ${job.id}',
      );
      _setViewState(
        ViewState.success,
        'Locked ${quantity}x ${livePart.name} (${livePart.shortShelfCoordinates}) to ${job.id}.',
      );
      return true;
    } catch (e) {
      _setViewState(ViewState.error, 'Failed to lock part to job: $e');
      return false;
    }
  }

  Future<bool> removeAttachedPartFromJob({
    required String jobId,
    required String partId,
  }) async {
    final jIdx = _jobOrders.indexWhere((j) => j.id == jobId);
    if (jIdx < 0) return false;
    final job = _jobOrders[jIdx];

    final existing =
        job.attachedParts.where((p) => p.partId == partId).toList();
    if (existing.isEmpty) return false;
    final removedPart = existing.first;

    final pIdx = _inventory.indexWhere((p) => p.id == partId);
    if (pIdx < 0) return false;

    try {
      final livePart = _inventory[pIdx];
      final updatedPart = livePart.copyWith(
        lockedPatimbao: job.branch == BranchId.patimbao
            ? (livePart.lockedPatimbao - removedPart.quantity).clamp(0, 999999)
            : livePart.lockedPatimbao,
        lockedPedroGuevara: job.branch == BranchId.pedroGuevara
            ? (livePart.lockedPedroGuevara - removedPart.quantity)
                .clamp(0, 999999)
            : livePart.lockedPedroGuevara,
      );

      final updatedParts =
          job.attachedParts.where((p) => p.partId != partId).toList();
      final updatedJob = job.copyWith(
        attachedParts: updatedParts,
        updatedAt: DateTime.now(),
      );

      await _db.executeJobPartLockTransaction(
        updatedItem: updatedPart,
        updatedJob: updatedJob,
      );

      _inventory[pIdx] = updatedPart;
      _jobOrders[jIdx] = updatedJob;
      _firebase.syncJobOrderToFirestore(updatedJob);

      _setViewState(
        ViewState.success,
        'Released lock on ${removedPart.name} from ${job.id}.',
      );
      return true;
    } catch (e) {
      _setViewState(ViewState.error, 'Failed to unlock part: $e');
      return false;
    }
  }

  Future<bool> updateJobLaborFee({
    required String jobId,
    required double laborFee,
    String? extraRepairNote,
    double? extraRepairFee,
  }) async {
    if (!_isValidCurrency(laborFee) ||
        (extraRepairFee != null && !_isValidCurrency(extraRepairFee))) {
      _setViewState(ViewState.error, 'Invalid labor or extra repair fee.');
      return false;
    }
    final jIdx = _jobOrders.indexWhere((j) => j.id == jobId);
    if (jIdx < 0) return false;

    try {
      final current = _jobOrders[jIdx];
      final cleanExtraNote = extraRepairNote?.trim();
      final shouldClearExtra =
          extraRepairNote != null && (cleanExtraNote == null || cleanExtraNote.isEmpty);
      final nextExtraNote = shouldClearExtra
          ? null
          : (cleanExtraNote ?? current.extraRepairNote);
      final nextExtraFee = shouldClearExtra
          ? 0.0
          : (extraRepairFee ?? current.extraRepairFee);
      final extraChanged = nextExtraNote != current.extraRepairNote ||
          nextExtraFee != current.extraRepairFee;

      final updated = current.copyWith(
        laborFee: laborFee,
        extraRepairNote: nextExtraNote,
        clearExtraRepair: shouldClearExtra,
        extraRepairFee: nextExtraFee,
        extraRepairApproved: extraChanged ? false : current.extraRepairApproved,
        updatedAt: DateTime.now(),
      );
      await _db.saveJobOrder(updated);
      _jobOrders[jIdx] = updated;

      if (extraChanged &&
          nextExtraNote != null &&
          nextExtraNote.isNotEmpty) {
        await _pushNotification(
          title: 'Extra Repair Recommended (${updated.id})',
          message:
              'Mechanic recommended "$nextExtraNote" (+₱${nextExtraFee.toStringAsFixed(0)}) for ${updated.bikeModel}. Awaiting customer approval.',
          category: 'job_order',
          branch: updated.branch,
        );
      }

      _setViewState(
        ViewState.success,
        'Updated labor & repair quote for ${updated.id}. Total bill: ₱${updated.totalEstimate.toStringAsFixed(2)}.',
      );
      return true;
    } catch (e) {
      _setViewState(ViewState.error, 'Failed to update labor fee: $e');
      return false;
    }
  }

  Future<bool> approveCustomerExtraRepair(String jobId) async {
    final jIdx = _jobOrders.indexWhere((j) => j.id == jobId);
    if (jIdx < 0) return false;
    try {
      final current = _jobOrders[jIdx];
      final updated = current.copyWith(
        extraRepairApproved: true,
        updatedAt: DateTime.now(),
      );
      await _db.saveJobOrder(updated);
      _jobOrders[jIdx] = updated;

      await _pushNotification(
        title: 'Customer Approved Extra Repair (${updated.id})',
        message:
            '${updated.customerName} approved "${updated.extraRepairNote}" (+₱${updated.extraRepairFee.toStringAsFixed(0)}).',
        category: 'job_order',
        branch: updated.branch,
      );

      _setViewState(
        ViewState.success,
        'Extra repair approved for ${updated.id}! Assigned mechanic notified.',
      );
      return true;
    } catch (e) {
      _setViewState(ViewState.error, 'Failed to approve extra repair: $e');
      return false;
    }
  }

  // ---------------------------------------------------------------------------
  // Customer App: Click & Collect Part Reservation (Atomic Transaction)
  // ---------------------------------------------------------------------------

  Future<ClickAndCollectOrder?> createClickAndCollectOrder({
    required InventoryItem part,
    BranchId? pickupBranch,
    BranchId? branch,
    required int quantity,
    required String customerPhone,
  }) async {
    final targetBranch = pickupBranch ?? branch ?? _activeBranch;
    if (quantity <= 0) {
      _setViewState(ViewState.error, 'Reservation quantity must be at least 1.');
      return null;
    }
    final pIdx = _inventory.indexWhere((i) => i.id == part.id);
    if (pIdx < 0) {
      _setViewState(ViewState.error, 'Selected part was not found.');
      return null;
    }
    final livePart = _inventory[pIdx];
    final avail = livePart.availableStockFor(targetBranch);
    if (quantity > avail) {
      _setViewState(
        ViewState.error,
        'Only $avail unit(s) available for Click & Collect at ${targetBranch.shortName}.',
      );
      return null;
    }

    try {
      final updatedPart = livePart.copyWith(
        lockedPatimbao: targetBranch == BranchId.patimbao
            ? livePart.lockedPatimbao + quantity
            : livePart.lockedPatimbao,
        lockedPedroGuevara: targetBranch == BranchId.pedroGuevara
            ? livePart.lockedPedroGuevara + quantity
            : livePart.lockedPedroGuevara,
      );

      final order = ClickAndCollectOrder(
        id: _generateId('CNC'),
        customerUsername: _currentUser?.username ?? 'guest',
        customerName: _currentUser?.fullName ?? 'MotoHub Customer',
        customerPhone: customerPhone.trim(),
        pickupBranch: targetBranch,
        partId: livePart.id,
        sku: livePart.sku,
        partName: livePart.name,
        quantity: quantity,
        unitPrice: livePart.price,
        status: 'Reserved • Ready for Counter Pickup',
        createdAt: DateTime.now(),
      );

      final notif = AppNotificationItem(
        id: _generateId('NTF'),
        title: 'Click & Collect Reservation (${order.id})',
        message:
            '${order.customerName} reserved ${quantity}x ${livePart.name} at ${targetBranch.shortName}. Stock locked.',
        category: 'booking',
        branch: targetBranch,
        isRead: false,
        createdAt: DateTime.now(),
      );

      await _db.executeClickAndCollectTransaction(
        updatedItem: updatedPart,
        order: order,
        notification: notif,
      );

      _inventory[pIdx] = updatedPart;
      _clickCollectOrders.insert(0, order);
      _notifications.insert(0, notif);

      await _firebase.syncClickAndCollectToFirestore(order);
      await _firebase.syncInventoryItemToFirestore(updatedPart);

      _setViewState(
        ViewState.success,
        'Reserved ${quantity}x ${livePart.name} at ${targetBranch.shortName} (${order.id})!',
      );
      return order;
    } catch (e) {
      _setViewState(
        ViewState.error,
        'Click & Collect reservation failed (rolled back): $e',
      );
      return null;
    }
  }

  /// Completes / claims a Click & Collect reservation at the branch counter:
  /// Decrements total physical stock AND decrements the locked stock hold.
  Future<bool> claimClickAndCollectOrder(String orderId) async {
    final oIdx = _clickCollectOrders.indexWhere((o) => o.id == orderId);
    if (oIdx < 0) return false;
    final order = _clickCollectOrders[oIdx];
    if (order.status.startsWith('Claimed') ||
        order.status.startsWith('Cancelled')) {
      _setViewState(
        ViewState.error,
        'Order has already been processed (${order.status}).',
      );
      return false;
    }

    final pIdx = _inventory.indexWhere((p) => p.id == order.partId);
    if (pIdx >= 0) {
      final cur = _inventory[pIdx];
      final updatedPart = cur.copyWith(
        stockPatimbao: order.pickupBranch == BranchId.patimbao
            ? (cur.stockPatimbao - order.quantity).clamp(0, 999999)
            : cur.stockPatimbao,
        stockPedroGuevara: order.pickupBranch == BranchId.pedroGuevara
            ? (cur.stockPedroGuevara - order.quantity).clamp(0, 999999)
            : cur.stockPedroGuevara,
        lockedPatimbao: order.pickupBranch == BranchId.patimbao
            ? (cur.lockedPatimbao - order.quantity).clamp(0, 999999)
            : cur.lockedPatimbao,
        lockedPedroGuevara: order.pickupBranch == BranchId.pedroGuevara
            ? (cur.lockedPedroGuevara - order.quantity).clamp(0, 999999)
            : cur.lockedPedroGuevara,
      );
      await _db.saveInventoryItem(updatedPart);
      _inventory[pIdx] = updatedPart;
      await _firebase.syncInventoryItemToFirestore(updatedPart);
    }

    final updatedOrder = ClickAndCollectOrder(
      id: order.id,
      customerUsername: order.customerUsername,
      customerName: order.customerName,
      customerPhone: order.customerPhone,
      pickupBranch: order.pickupBranch,
      partId: order.partId,
      sku: order.sku,
      partName: order.partName,
      quantity: order.quantity,
      unitPrice: order.unitPrice,
      status: 'Claimed & Completed',
      createdAt: order.createdAt,
    );
    await _db.saveClickCollectOrder(updatedOrder);
    _clickCollectOrders[oIdx] = updatedOrder;
    await _firebase.syncClickAndCollectToFirestore(updatedOrder);

    _setViewState(
      ViewState.success,
      'Order ${order.id} claimed and completed at ${order.pickupBranch.shortName}. Stock deducted.',
    );
    return true;
  }

  /// Cancels a Click & Collect reservation:
  /// Releases the locked stock back to available stock (total physical stock unchanged).
  Future<bool> cancelClickAndCollectOrder(String orderId) async {
    final oIdx = _clickCollectOrders.indexWhere((o) => o.id == orderId);
    if (oIdx < 0) return false;
    final order = _clickCollectOrders[oIdx];
    if (order.status.startsWith('Claimed') ||
        order.status.startsWith('Cancelled')) {
      _setViewState(
        ViewState.error,
        'Order has already been processed (${order.status}).',
      );
      return false;
    }

    final pIdx = _inventory.indexWhere((p) => p.id == order.partId);
    if (pIdx >= 0) {
      final cur = _inventory[pIdx];
      final updatedPart = cur.copyWith(
        lockedPatimbao: order.pickupBranch == BranchId.patimbao
            ? (cur.lockedPatimbao - order.quantity).clamp(0, 999999)
            : cur.lockedPatimbao,
        lockedPedroGuevara: order.pickupBranch == BranchId.pedroGuevara
            ? (cur.lockedPedroGuevara - order.quantity).clamp(0, 999999)
            : cur.lockedPedroGuevara,
      );
      await _db.saveInventoryItem(updatedPart);
      _inventory[pIdx] = updatedPart;
      await _firebase.syncInventoryItemToFirestore(updatedPart);
    }

    final updatedOrder = ClickAndCollectOrder(
      id: order.id,
      customerUsername: order.customerUsername,
      customerName: order.customerName,
      customerPhone: order.customerPhone,
      pickupBranch: order.pickupBranch,
      partId: order.partId,
      sku: order.sku,
      partName: order.partName,
      quantity: order.quantity,
      unitPrice: order.unitPrice,
      status: 'Cancelled • Stock Released',
      createdAt: order.createdAt,
    );
    await _db.saveClickCollectOrder(updatedOrder);
    _clickCollectOrders[oIdx] = updatedOrder;
    await _firebase.syncClickAndCollectToFirestore(updatedOrder);

    _setViewState(
      ViewState.success,
      'Order ${order.id} cancelled. Reserved stock released back to inventory.',
    );
    return true;
  }

  // ---------------------------------------------------------------------------
  // Cashier Retail POS & Atomic Service-to-POS Auto-Billing
  // ---------------------------------------------------------------------------

  bool addToCart(InventoryItem item, {int quantity = 1}) {
    if (quantity <= 0) return false;
    final pIdx = _inventory.indexWhere((i) => i.id == item.id);
    final liveItem = pIdx >= 0 ? _inventory[pIdx] : item;
    final avail = liveItem.availableStockFor(_activeBranch);
    final existingIdx = _cart.indexWhere((c) => c.item.id == liveItem.id);
    final currentInCart = existingIdx >= 0 ? _cart[existingIdx].quantity : 0;

    if (currentInCart + quantity > avail) {
      _setViewState(
        ViewState.error,
        'Stock Guard: Only $avail unlocked unit(s) of ${liveItem.name} available in ${_activeBranch.shortName}.',
      );
      return false;
    }

    if (existingIdx >= 0) {
      _cart[existingIdx] = CartItem(
        item: liveItem,
        quantity: currentInCart + quantity,
      );
    } else {
      _cart.add(CartItem(item: liveItem, quantity: quantity));
    }
    notifyListeners();
    return true;
  }

  void updateCartQuantity(String itemId, int newQty) {
    final idx = _cart.indexWhere((c) => c.item.id == itemId);
    if (idx < 0) return;
    if (newQty <= 0) {
      _cart.removeAt(idx);
      notifyListeners();
      return;
    }
    final liveItem = _inventory.firstWhere(
      (i) => i.id == itemId,
      orElse: () => _cart[idx].item,
    );
    final avail = liveItem.availableStockFor(_activeBranch);
    if (newQty > avail) {
      _setViewState(
        ViewState.error,
        'Max available unlocked stock in ${_activeBranch.shortName} is $avail.',
      );
      return;
    }
    _cart[idx] = CartItem(item: liveItem, quantity: newQty);
    notifyListeners();
  }

  void clearCart() {
    _cart.clear();
    notifyListeners();
  }

  /// Atomic Retail POS Checkout:
  /// Deducts inventory + creates POS invoice + logs Cash Drawer in a single SQLite transaction.
  /// Supports Cash, GCash (with last-4-digit verification), and Split payments (Cash + GCash).
  Future<PosTransaction?> processRetailCheckout({
    required PaymentMethod paymentMethod,
    required double amountTendered,
    double cashAmount = 0.0,
    double gcashAmount = 0.0,
    String customerName = 'Walk-in Customer',
    String? gcashRef,
    String? gcashProofUrl,
  }) async {
    if (_isProcessingCheckout) {
      _setViewState(ViewState.error, 'A checkout transaction is already in progress.');
      return null;
    }
    _isProcessingCheckout = true;

    try {
      if (_cart.isEmpty) {
        _setViewState(ViewState.error, 'POS Cart is empty.');
        return null;
      }
      if (!_isValidCurrency(amountTendered)) {
        _setViewState(ViewState.error, 'Invalid tendered cash amount.');
        return null;
      }

      final total = cartTotal;

      // Split Payment calculations & validation
      final effectiveCash = paymentMethod == PaymentMethod.split
          ? (cashAmount > 0 ? cashAmount : (total - gcashAmount))
          : (paymentMethod == PaymentMethod.cash ? total : 0.0);
      final effectiveGcash = paymentMethod == PaymentMethod.split
          ? (gcashAmount > 0 ? gcashAmount : (total - cashAmount))
          : (paymentMethod == PaymentMethod.gcash ? total : 0.0);

      if (paymentMethod == PaymentMethod.split) {
        if ((effectiveCash + effectiveGcash - total).abs() > 0.01) {
          _setViewState(
            ViewState.error,
            'Split amounts (₱${effectiveCash.toStringAsFixed(2)} + ₱${effectiveGcash.toStringAsFixed(2)}) must equal total (₱${total.toStringAsFixed(2)}).',
          );
          return null;
        }
        if (amountTendered < effectiveCash) {
          _setViewState(
            ViewState.error,
            'Tendered cash (₱${amountTendered.toStringAsFixed(2)}) is less than cash portion (₱${effectiveCash.toStringAsFixed(2)}).',
          );
          return null;
        }
        if (gcashRef == null || gcashRef.trim().length < 4) {
          _setViewState(
            ViewState.error,
            'Please enter at least the last 4 digits of the GCash Reference Number.',
          );
          return null;
        }
      } else if (paymentMethod == PaymentMethod.cash) {
        if (amountTendered < total) {
          _setViewState(
            ViewState.error,
            'Tendered cash (₱${amountTendered.toStringAsFixed(2)}) is less than total (₱${total.toStringAsFixed(2)}).',
          );
          return null;
        }
      } else if (paymentMethod == PaymentMethod.gcash) {
        if (gcashRef == null || gcashRef.trim().length < 4) {
          _setViewState(
            ViewState.error,
            'Please enter at least the last 4 digits of the GCash Reference Number.',
          );
          return null;
        }
      }

      final changeDue = (paymentMethod == PaymentMethod.gcash)
          ? 0.0
          : (amountTendered - effectiveCash);

      final summaryParts = <String>[];
      final updatedItems = <InventoryItem>[];

      for (final cartItem in _cart) {
        summaryParts.add('${cartItem.quantity}x ${cartItem.item.name}');
        final pIdx = _inventory.indexWhere((p) => p.id == cartItem.item.id);
        if (pIdx < 0) {
          throw StateError('Part ${cartItem.item.name} no longer exists.');
        }
        final cur = _inventory[pIdx];
        final avail = cur.availableStockFor(_activeBranch);
        if (cartItem.quantity > avail) {
          throw StateError(
            'Insufficient stock for ${cur.name} ($avail available).',
          );
        }
        final updated = cur.copyWith(
          stockPatimbao: _activeBranch == BranchId.patimbao
              ? cur.stockPatimbao - cartItem.quantity
              : cur.stockPatimbao,
          stockPedroGuevara: _activeBranch == BranchId.pedroGuevara
              ? cur.stockPedroGuevara - cartItem.quantity
              : cur.stockPedroGuevara,
        );
        updatedItems.add(updated);
      }

      final tx = PosTransaction(
        id: _generateId('OR'),
        branch: _activeBranch,
        cashierName: _currentUser?.fullName ?? 'Cashier',
        customerName: customerName.trim().isEmpty
            ? 'Walk-in Customer'
            : customerName.trim(),
        itemsSummary: summaryParts.join(', '),
        partsSubtotal: total,
        laborTotal: 0.0,
        totalAmount: total,
        paymentMethod: paymentMethod,
        amountTendered:
            paymentMethod == PaymentMethod.gcash ? total : amountTendered,
        changeAmount: changeDue,
        cashAmount: effectiveCash,
        gcashAmount: effectiveGcash,
        gcashRef: gcashRef,
        gcashProofUrl: gcashProofUrl,
        createdAt: DateTime.now(),
        isSynced: _isOnline,
      );

      final cashToRecord = paymentMethod == PaymentMethod.cash
          ? total
          : (paymentMethod == PaymentMethod.split ? effectiveCash : 0.0);

      final cashEntry = cashToRecord > 0
          ? CashDrawerEntry(
              id: _generateId('CSH'),
              branch: _activeBranch,
              type: CashLedgerType.cashSale,
              description: '${tx.id} • ${tx.itemsSummary}',
              amount: cashToRecord,
              staffName: tx.cashierName,
              createdAt: DateTime.now(),
            )
          : null;

      // Execute atomic database transaction
      await _db.executeRetailCheckoutTransaction(
        updatedInventoryItems: updatedItems,
        transaction: tx,
        cashLedgerEntry: cashEntry,
      );

      // Update in-memory state only after transaction commits
      for (final updated in updatedItems) {
        final pIdx = _inventory.indexWhere((p) => p.id == updated.id);
        if (pIdx >= 0) _inventory[pIdx] = updated;
        _firebase.syncInventoryItemToFirestore(updated);
      }
      _transactions.insert(0, tx);
      if (cashEntry != null) {
        _cashLedger.insert(0, cashEntry);
      }
      await _firebase.syncPosTransactionToFirestore(tx);

      _cart.clear();
      _enqueueIfOffline(
        'POS_SALE',
        '${tx.id} • ₱${tx.totalAmount.toStringAsFixed(2)} (${tx.formattedPaymentDetails})',
      );
      _setViewState(
        ViewState.success,
        'Completed sale ${tx.id} (₱${tx.totalAmount.toStringAsFixed(2)} via ${tx.formattedPaymentDetails}).',
      );
      return tx;
    } catch (e) {
      _setViewState(
        ViewState.error,
        'POS Checkout failed and rolled back: $e',
      );
      return null;
    } finally {
      _isProcessingCheckout = false;
    }
  }

  /// Atomic Service-to-POS Auto-Billing Checkout
  Future<PosTransaction?> processServiceJobCheckout({
    required JobOrder job,
    required PaymentMethod paymentMethod,
    required double amountTendered,
    double cashAmount = 0.0,
    double gcashAmount = 0.0,
    String? gcashRef,
    String? gcashProofUrl,
  }) async {
    if (_isProcessingCheckout) {
      _setViewState(
        ViewState.error,
        'A checkout transaction is currently in progress.',
      );
      return null;
    }
    _isProcessingCheckout = true;

    try {
      final jIdx = _jobOrders.indexWhere((j) => j.id == job.id);
      final liveJob = jIdx >= 0 ? _jobOrders[jIdx] : job;
      if (liveJob.isBilled || liveJob.status == JobStatus.completed) {
        _setViewState(
          ViewState.error,
          'Job Order ${liveJob.id} has already been billed and completed.',
        );
        return null;
      }
      if (!_isValidCurrency(amountTendered)) {
        _setViewState(ViewState.error, 'Invalid tendered amount.');
        return null;
      }
      final total = liveJob.totalEstimate;

      // Split Payment calculations & validation
      final effectiveCash = paymentMethod == PaymentMethod.split
          ? (cashAmount > 0 ? cashAmount : (total - gcashAmount))
          : (paymentMethod == PaymentMethod.cash ? total : 0.0);
      final effectiveGcash = paymentMethod == PaymentMethod.split
          ? (gcashAmount > 0 ? gcashAmount : (total - cashAmount))
          : (paymentMethod == PaymentMethod.gcash ? total : 0.0);

      if (paymentMethod == PaymentMethod.split) {
        if ((effectiveCash + effectiveGcash - total).abs() > 0.01) {
          _setViewState(
            ViewState.error,
            'Split amounts must equal total bill (₱${total.toStringAsFixed(2)}).',
          );
          return null;
        }
        if (amountTendered < effectiveCash) {
          _setViewState(
            ViewState.error,
            'Tendered cash is less than cash portion.',
          );
          return null;
        }
        if (gcashRef == null || gcashRef.trim().length < 4) {
          _setViewState(
            ViewState.error,
            'Please enter at least the last 4 digits of the GCash Reference Number.',
          );
          return null;
        }
      } else if (paymentMethod == PaymentMethod.cash) {
        if (amountTendered < total) {
          _setViewState(
            ViewState.error,
            'Tendered cash is less than total service bill.',
          );
          return null;
        }
      } else if (paymentMethod == PaymentMethod.gcash) {
        if (gcashRef == null || gcashRef.trim().length < 4) {
          _setViewState(
            ViewState.error,
            'Please enter at least the last 4 digits of the GCash Reference Number.',
          );
          return null;
        }
      }

      final changeDue = (paymentMethod == PaymentMethod.gcash)
          ? 0.0
          : (amountTendered - effectiveCash);

      final updatedItems = <InventoryItem>[];
      for (final ap in liveJob.attachedParts) {
        final pIdx = _inventory.indexWhere((p) => p.id == ap.partId);
        if (pIdx >= 0) {
          final cur = _inventory[pIdx];
          final updated = cur.copyWith(
            stockPatimbao: liveJob.branch == BranchId.patimbao
                ? (cur.stockPatimbao - ap.quantity).clamp(0, 999999)
                : cur.stockPatimbao,
            stockPedroGuevara: liveJob.branch == BranchId.pedroGuevara
                ? (cur.stockPedroGuevara - ap.quantity).clamp(0, 999999)
                : cur.stockPedroGuevara,
            lockedPatimbao: liveJob.branch == BranchId.patimbao
                ? (cur.lockedPatimbao - ap.quantity).clamp(0, 999999)
                : cur.lockedPatimbao,
            lockedPedroGuevara: liveJob.branch == BranchId.pedroGuevara
                ? (cur.lockedPedroGuevara - ap.quantity).clamp(0, 999999)
                : cur.lockedPedroGuevara,
          );
          updatedItems.add(updated);
        }
      }

      final completedJob = liveJob.copyWith(
        status: JobStatus.completed,
        isBilled: true,
        updatedAt: DateTime.now(),
      );

      final itemsList = liveJob.attachedParts
          .map((p) => '${p.quantity}x ${p.name}')
          .toList()
        ..add('${liveJob.serviceType} Labor');

      final tx = PosTransaction(
        id: _generateId('OR'),
        branch: liveJob.branch,
        cashierName: _currentUser?.fullName ?? 'Cashier',
        customerName: '${liveJob.customerName} (${liveJob.plateNumber})',
        itemsSummary: itemsList.join(', '),
        partsSubtotal: liveJob.partsSubtotal,
        laborTotal: liveJob.effectiveLaborFee,
        totalAmount: total,
        paymentMethod: paymentMethod,
        amountTendered:
            paymentMethod == PaymentMethod.gcash ? total : amountTendered,
        changeAmount: changeDue,
        cashAmount: effectiveCash,
        gcashAmount: effectiveGcash,
        gcashRef: gcashRef,
        gcashProofUrl: gcashProofUrl,
        linkedJobOrderId: liveJob.id,
        createdAt: DateTime.now(),
        isSynced: _isOnline,
      );

      final cashToRecord = paymentMethod == PaymentMethod.cash
          ? total
          : (paymentMethod == PaymentMethod.split ? effectiveCash : 0.0);

      final cashEntry = cashToRecord > 0
          ? CashDrawerEntry(
              id: _generateId('CSH'),
              branch: liveJob.branch,
              type: CashLedgerType.serviceCash,
              description:
                  '${tx.id} • Service Billing ${liveJob.id} (${liveJob.plateNumber})',
              amount: cashToRecord,
              staffName: tx.cashierName,
              createdAt: DateTime.now(),
            )
          : null;

      await _db.executeServiceJobCheckoutTransaction(
        updatedInventoryItems: updatedItems,
        completedJob: completedJob,
        transaction: tx,
        cashLedgerEntry: cashEntry,
      );

      for (final updated in updatedItems) {
        final pIdx = _inventory.indexWhere((p) => p.id == updated.id);
        if (pIdx >= 0) _inventory[pIdx] = updated;
        _firebase.syncInventoryItemToFirestore(updated);
      }
      if (jIdx >= 0) _jobOrders[jIdx] = completedJob;
      _firebase.syncJobOrderToFirestore(completedJob);
      _transactions.insert(0, tx);
      if (cashEntry != null) {
        _cashLedger.insert(0, cashEntry);
      }
      await _firebase.syncPosTransactionToFirestore(tx);

      _enqueueIfOffline(
        'SERVICE_POS_BILLING',
        '${tx.id} for ${liveJob.id} • ₱${total.toStringAsFixed(2)}',
      );
      _setViewState(
        ViewState.success,
        'Billed Job Order ${liveJob.id} (${tx.id}) • ₱${total.toStringAsFixed(2)} via ${tx.formattedPaymentDetails}!',
      );
      return tx;
    } catch (e) {
      _setViewState(
        ViewState.error,
        'Service checkout failed and rolled back: $e',
      );
      return null;
    } finally {
      _isProcessingCheckout = false;
    }
  }

  // ---------------------------------------------------------------------------
  // Cash Drawer Float, Petty Cash & End-of-Shift Denomination Audit
  // ---------------------------------------------------------------------------

  Future<bool> addMorningFloat(double amount) async {
    if (!_isValidCurrency(amount) || amount <= 0) {
      _setViewState(ViewState.error, 'Float amount must be greater than 0.');
      return false;
    }
    try {
      final entry = CashDrawerEntry(
        id: 'CSH-${DateTime.now().millisecondsSinceEpoch}',
        branch: _activeBranch,
        type: CashLedgerType.morningFloat,
        description: 'Morning Float Added (${_activeBranch.shortName})',
        amount: amount,
        staffName: _currentUser?.fullName ?? 'Cashier',
        createdAt: DateTime.now(),
      );
      await _db.saveCashLedgerEntry(entry);
      _cashLedger.insert(0, entry);
      _setViewState(
        ViewState.success,
        'Recorded Morning Float of ₱${amount.toStringAsFixed(2)}.',
      );
      return true;
    } catch (e) {
      _setViewState(ViewState.error, 'Failed to record morning float: $e');
      return false;
    }
  }

  Future<bool> recordCashout({
    required String description,
    required double amount,
  }) async {
    if (!_isValidCurrency(amount) || amount <= 0) {
      _setViewState(ViewState.error, 'Cashout amount must be positive.');
      return false;
    }
    if (amount > branchPhysicalCashInDrawer) {
      _setViewState(
        ViewState.error,
        'Cashout amount exceeds physical cash in drawer.',
      );
      return false;
    }
    try {
      final entry = CashDrawerEntry(
        id: 'CSH-${DateTime.now().millisecondsSinceEpoch}',
        branch: _activeBranch,
        type: CashLedgerType.cashout,
        description: 'Cashout • ${description.trim()}',
        amount: -amount,
        staffName: _currentUser?.fullName ?? 'Cashier',
        createdAt: DateTime.now(),
      );
      await _db.saveCashLedgerEntry(entry);
      _cashLedger.insert(0, entry);
      _enqueueIfOffline(
        'CASHOUT',
        '-₱${amount.toStringAsFixed(2)} ($description)',
      );
      _setViewState(
        ViewState.success,
        'Logged Cashout: -₱${amount.toStringAsFixed(2)} ($description).',
      );
      return true;
    } catch (e) {
      _setViewState(ViewState.error, 'Failed to log cashout: $e');
      return false;
    }
  }

  /// Backward-compatible forwarder for legacy calls
  Future<bool> recordPettyCashOut({
    required String description,
    required double amount,
  }) =>
      recordCashout(description: description, amount: amount);

  bool verifyAdminOverridePassword(String password) {
    return _staffList.any(
      (s) => s.role == UserRole.admin && PasswordSecurity.verify(s.password, password.trim()),
    );
  }

  Future<bool> logShiftReconciliationAudit({
    required double countedCash,
    required double expectedCash,
    String? adminOverrideBy,
  }) async {
    if (!_isValidCurrency(countedCash)) {
      _setViewState(ViewState.error, 'Invalid counted cash amount.');
      return false;
    }
    try {
      final variance = countedCash - expectedCash;
      final statusLabel = variance == 0
          ? 'EXACT MATCH (₱0.00 Variance)'
          : variance < 0
              ? 'SHORTAGE (₱${variance.toStringAsFixed(2)}) • Override: ${adminOverrideBy ?? "Boss Arman"}'
              : 'OVERAGE (+₱${variance.toStringAsFixed(2)})';

      final entry = CashDrawerEntry(
        id: _generateId('CSH'),
        branch: _activeBranch,
        type: CashLedgerType.reconciliationAudit,
        description:
            'Shift Audit: Counted ₱${countedCash.toStringAsFixed(0)} vs Expected ₱${expectedCash.toStringAsFixed(0)} • $statusLabel',
        amount: 0.0,
        staffName: _currentUser?.fullName ?? 'Cashier',
        createdAt: DateTime.now(),
      );
      await _db.saveCashLedgerEntry(entry);
      _cashLedger.insert(0, entry);

      await _pushNotification(
        title: 'Shift Drawer Audit Logged • ${_activeBranch.shortName}',
        message: entry.description,
        category: 'drawer',
        branch: _activeBranch,
      );

      _setViewState(
        ViewState.success,
        'Shift Cash Reconciliation Audit recorded ($statusLabel).',
      );
      return true;
    } catch (e) {
      _setViewState(ViewState.error, 'Failed to log shift audit: $e');
      return false;
    }
  }

  /// Generates and persists an immutable end-of-shift Z-Reading snapshot with physical cash reconciliation.
  Future<ZReadingRecord?> generateZReadingReport({
    double? actualPhysicalCash,
    String? reconciliationNote,
  }) async {
    try {
      final actual = actualPhysicalCash ?? branchPhysicalCashInDrawer;
      final discrepancy = actual - branchPhysicalCashInDrawer;

      final record = ZReadingRecord(
        id: _generateId('Z'),
        branch: _activeBranch,
        terminalId: _activeBranch.terminalId,
        generatedBy: _currentUser?.fullName ?? 'Cashier',
        morningFloat: branchMorningFloat,
        grossCashSales: branchCashSalesTotal,
        gcashVaultCollections: branchGcashVaultTotal,
        cashoutOutflows: branchCashoutTotal,
        totalGrossRevenue: branchTodayGross,
        expectedPhysicalCash: branchPhysicalCashInDrawer,
        actualPhysicalCash: actual,
        cashDiscrepancy: discrepancy,
        reconciliationNote: reconciliationNote ?? '',
        totalTransactions: currentShiftTransactions.length,
        generatedAt: DateTime.now(),
      );

      await _db.saveZReading(record);
      _zReadings.insert(0, record);

      final discrepancyText = discrepancy == 0
          ? 'Exact match'
          : (discrepancy < 0
              ? 'Shortage -₱${(-discrepancy).toStringAsFixed(2)}'
              : 'Overage +₱${discrepancy.toStringAsFixed(2)}');

      await _pushNotification(
        title: 'Z-Reading Generated (${record.id})',
        message:
            '${_activeBranch.shortName} shift closed • '
            'Gross ₱${record.totalGrossRevenue.toStringAsFixed(2)} • '
            'Drawer: ₱${record.expectedPhysicalCash.toStringAsFixed(2)} (Counted: ₱${actual.toStringAsFixed(2)}, $discrepancyText)',
        category: 'drawer',
        branch: _activeBranch,
      );

      _enqueueIfOffline(
        'Z_READING',
        '${record.id} • ₱${record.totalGrossRevenue.toStringAsFixed(2)}',
      );

      _setViewState(
        ViewState.success,
        'Z-Reading ${record.id} archived to local SQLite.',
      );
      return record;
    } catch (e) {
      _setViewState(ViewState.error, 'Failed to save Z-Reading: $e');
      return null;
    }
  }

  // ---------------------------------------------------------------------------
  // Staff & Admin Management (add_staff_screen.dart)
  // ---------------------------------------------------------------------------

  Future<bool> createStaffAccount({
    required String firstName,
    required String lastName,
    required String username,
    required String email,
    required String password,
    required UserRole role,
    required BranchId assignedBranch,
  }) async {
    if (_currentUser?.role != UserRole.admin) {
      _setViewState(
        ViewState.error,
        'Access Denied: Only the Admin can create staff accounts and assign branches.',
      );
      return false;
    }

    if ((role == UserRole.cashier || role == UserRole.mechanic) &&
        assignedBranch == BranchId.both) {
      _setViewState(
        ViewState.error,
        'Each ${role.label} can only be assigned to ONE branch (Branch 1 or Branch 2).',
      );
      return false;
    }

    final cleanUsername = username.trim().toLowerCase();
    final duplicate = _staffList.any(
      (s) => s.username.toLowerCase() == cleanUsername,
    );
    if (duplicate) {
      _setViewState(
        ViewState.error,
        'Username "$cleanUsername" is already registered.',
      );
      return false;
    }

    try {
      final newStaff = StaffAccount(
        id: _generateId('STF'),
        firstName: firstName.trim(),
        lastName: lastName.trim(),
        username: cleanUsername,
        email: email.trim(),
        password: PasswordSecurity.hashPassword(password.trim()),
        role: role,
        assignedBranch: assignedBranch,
        shiftStatus: role == UserRole.mechanic ? 'In Bay' : 'On Duty',
        createdAt: DateTime.now(),
      );

      await _db.saveStaff(newStaff);
      _staffList.insert(0, newStaff);
      _enqueueIfOffline(
        'STAFF_CREATE',
        '${newStaff.fullName} (${newStaff.role.label} • ${assignedBranch.shortName})',
      );
      _setViewState(
        ViewState.success,
        'Created ${role.label} account for ${newStaff.fullName} (@$cleanUsername) assigned to ${assignedBranch.displayName}.',
      );
      return true;
    } catch (e) {
      _setViewState(ViewState.error, 'Failed to create staff account: $e');
      return false;
    }
  }

  /// Admin-Only: Reassigns a Cashier or Mechanic to a single branch (`BranchId.patimbao` or `BranchId.pedroGuevara`).
  Future<bool> updateStaffAssignedBranch({
    required StaffAccount staff,
    required BranchId newBranch,
  }) async {
    if (_currentUser?.role != UserRole.admin) {
      _setViewState(
        ViewState.error,
        'Access Denied: Only the Admin can change staff branch assignments.',
      );
      return false;
    }

    if ((staff.role == UserRole.cashier || staff.role == UserRole.mechanic) &&
        newBranch == BranchId.both) {
      _setViewState(
        ViewState.error,
        'Each ${staff.role.label} can only be assigned to a single branch.',
      );
      return false;
    }

    final idx = _staffList.indexWhere((s) => s.id == staff.id);
    if (idx < 0) return false;
    if (_staffList[idx].assignedBranch == newBranch) return true;

    try {
      final updated = _staffList[idx].copyWith(assignedBranch: newBranch);
      await _db.saveStaff(updated);
      _staffList[idx] = updated;

      _enqueueIfOffline(
        'STAFF_BRANCH_REASSIGN',
        '${updated.fullName} (${updated.role.label}) -> ${newBranch.shortName}',
      );

      await _pushNotification(
        title: 'Branch Assignment Updated • ${updated.fullName}',
        message:
            'Admin reassigned ${updated.fullName} (${updated.role.label}) to ${newBranch.displayName}.',
        category: 'staff',
        branch: newBranch,
      );

      _setViewState(
        ViewState.success,
        'Reassigned ${updated.fullName} (${updated.role.label}) to ${newBranch.displayName}.',
      );
      return true;
    } catch (e) {
      _setViewState(ViewState.error, 'Failed to reassign staff branch: $e');
      return false;
    }
  }

  Future<void> cycleStaffShiftStatus(StaffAccount staff) async {
    const statuses = ['On Duty', 'In Bay', 'Off Shift', 'Emergency Absence'];
    final curIdx = statuses.indexOf(staff.shiftStatus);
    final nextStatus = statuses[(curIdx + 1) % statuses.length];
    final idx = _staffList.indexWhere((s) => s.id == staff.id);
    if (idx < 0) return;

    try {
      final isEmergency = nextStatus == 'Emergency Absence';
      final updated = staff.copyWith(
        shiftStatus: nextStatus,
        coveredByStaff:
            isEmergency ? 'Cross-Branch Reliever Requested' : null,
        clearCoveredByStaff: !isEmergency,
      );
      await _db.saveStaff(updated);
      _staffList[idx] = updated;
      _setViewState(
        ViewState.success,
        '${staff.fullName} status updated to "$nextStatus".',
      );
    } catch (e) {
      _setViewState(ViewState.error, 'Failed to update shift status: $e');
    }
  }

  // ---------------------------------------------------------------------------
  // Notifications Helper
  // ---------------------------------------------------------------------------

  Future<void> _pushNotification({
    required String title,
    required String message,
    required String category,
    required BranchId branch,
  }) async {
    final notif = AppNotificationItem(
      id: _generateId('NTF'),
      title: title,
      message: message,
      category: category,
      branch: branch,
      isRead: false,
      createdAt: DateTime.now(),
    );
    await _db.saveNotification(notif);
    _notifications.insert(0, notif);
  }

  Future<void> markAllNotificationsRead([String? notificationId]) async {
    try {
      for (var i = 0; i < _notifications.length; i++) {
        final notif = _notifications[i];
        final isInActiveBranchScope = notif.branch == _activeBranch ||
            (!isBranchLockedForCurrentUser && notif.branch == BranchId.both);
        final matchesTarget = notificationId != null
            ? notif.id == notificationId
            : isInActiveBranchScope;
        if (matchesTarget && !notif.isRead) {
          final updated = notif.copyWith(isRead: true);
          _notifications[i] = updated;
          await _db.saveNotification(updated);
        }
      }
      notifyListeners();
    } catch (e) {
      _setViewState(ViewState.error, 'Failed to update notifications: $e');
    }
  }

  @override
  void dispose() {
    _jobOrdersSub?.cancel();
    _clickCollectSub?.cancel();
    super.dispose();
  }
}
