import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../core/models/models.dart';
import '../../core/services/firebase_service.dart';
import '../../core/theme/app_theme.dart';
import '../../core/utils/formatters.dart';
import '../../viewmodels/motohub_viewmodel.dart';
import 'customer_shell_screen.dart';
import '../shared/forgot_password_screen.dart';

/// Dedicated Customer Authentication Screen for `main_customer.dart` (App B).
/// Provides:
/// 1. Real Google One-Tap / Google Sign-In flow (persisted in SQLite with `authProvider: 'google'`)
/// 2. Standard Email/Username + Password Sign-In
/// 3. Rider Account Registration
class CustomerAuthScreen extends StatefulWidget {
  const CustomerAuthScreen({super.key});

  @override
  State<CustomerAuthScreen> createState() => _CustomerAuthScreenState();
}

class _CustomerAuthScreenState extends State<CustomerAuthScreen> {
  final _formKey = GlobalKey<FormState>();
  final _firstNameCtrl = TextEditingController();
  final _lastNameCtrl = TextEditingController();
  final _usernameOrEmailCtrl = TextEditingController();
  final _emailCtrl = TextEditingController();
  final _passwordCtrl = TextEditingController();

  bool _isRegisterMode = false;
  bool _obscurePassword = true;
  BranchId _preferredBranch = BranchId.patimbao;

  @override
  void dispose() {
    _firstNameCtrl.dispose();
    _lastNameCtrl.dispose();
    _usernameOrEmailCtrl.dispose();
    _emailCtrl.dispose();
    _passwordCtrl.dispose();
    super.dispose();
  }

  Future<void> _submitEmailPasswordAuth() async {
    if (!(_formKey.currentState?.validate() ?? false)) return;
    final vm = context.read<MotoHubViewModel>();

    try {
      bool ok;
      if (_isRegisterMode) {
        ok = await vm.registerCustomerAccount(
          firstName: _firstNameCtrl.text.trim(),
          lastName: _lastNameCtrl.text.trim(),
          username: _usernameOrEmailCtrl.text.trim(),
          email: _emailCtrl.text.trim(),
          password: _passwordCtrl.text,
          preferredBranch: _preferredBranch,
        );
      } else {
        ok = await vm.login(
          _usernameOrEmailCtrl.text.trim(),
          _passwordCtrl.text,
          customerOnly: true,
        );
      }

      if (!mounted) return;
      if (ok) {
        Navigator.of(context).pushReplacement(
          MaterialPageRoute(builder: (_) => const CustomerShellScreen()),
        );
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            backgroundColor: AppPalette.danger,
            content: Text(
              vm.statusMessage ?? 'Authentication failed.',
              style: const TextStyle(color: AppPalette.crust),
            ),
          ),
        );
      }
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          backgroundColor: AppPalette.danger,
          content: Text(
            'Customer auth error: $e',
            style: const TextStyle(color: AppPalette.crust),
          ),
        ),
      );
    }
  }

  Future<void> _handleGoogleOneTap() async {
    final vm = context.read<MotoHubViewModel>();

    // 1. Attempt native Google One-Tap prompt
    try {
      final googleAccount =
          await FirebaseService.instance.promptNativeGoogleSignIn();

      if (googleAccount == null) {
        return; // User dismissed prompt
      }

      final email = googleAccount['email'] ?? '';
      final name = googleAccount['displayName'] ?? '';

      final ok = await vm.signInCustomerWithGoogle(
        email: email,
        displayName: name,
        preferredBranch: _preferredBranch,
      );

      if (!mounted) return;
      if (ok) {
        Navigator.of(context).pushReplacement(
          MaterialPageRoute(builder: (_) => const CustomerShellScreen()),
        );
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            backgroundColor: AppPalette.danger,
            content: Text(
              vm.statusMessage ?? 'Google Sign-In could not complete.',
              style: const TextStyle(color: AppPalette.crust),
            ),
          ),
        );
      }
      return;
    } catch (e) {
      debugPrint('[CustomerAuthScreen] Native Google Sign-In notice: $e');
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          backgroundColor: AppPalette.danger,
          content: Text(
            'Google Sign-In failed: $e',
            style: const TextStyle(color: AppPalette.crust),
          ),
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final vm = context.watch<MotoHubViewModel>();

    return Scaffold(
      backgroundColor: AppPalette.crust,
      body: SafeArea(
        child: LayoutBuilder(
          builder: (context, constraints) {
            return SingleChildScrollView(
              padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 20),
              child: Center(
                child: ConstrainedBox(
                  constraints: BoxConstraints(
                    maxWidth: 460,
                    minHeight: constraints.maxHeight - 40,
                  ),
                  child: Form(
                    key: _formKey,
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      children: [
                        // Brand Emblem
                        Center(
                          child: Container(
                            width: 72,
                            height: 72,
                            decoration: BoxDecoration(
                              color: AppPalette.mantle,
                              borderRadius: BorderRadius.circular(22),
                              border: Border.all(
                                color: AppPalette.champagneGold
                                    .withValues(alpha: 0.45),
                                width: 1.4,
                              ),
                            ),
                            child: const Icon(
                              Icons.two_wheeler_rounded,
                              color: AppPalette.champagneGold,
                              size: 36,
                            ),
                          ),
                        ),
                        const SizedBox(height: 16),
                        const Text(
                          'Boss Arman MotoHub',
                          textAlign: TextAlign.center,
                          style: TextStyle(
                            color: AppPalette.textHigh,
                            fontSize: 23,
                            fontWeight: FontWeight.w800,
                            letterSpacing: -0.3,
                          ),
                        ),
                        const SizedBox(height: 4),
                        const Text(
                          'Customer Service Tracking, Appointments & Click-and-Collect',
                          textAlign: TextAlign.center,
                          style: TextStyle(
                            color: AppPalette.champagneGold,
                            fontSize: 12.5,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                        const SizedBox(height: 20),

                        // Mode Toggle: Sign In vs Create Account
                        SegmentedButton<bool>(
                          segments: const [
                            ButtonSegment<bool>(
                              value: false,
                              label: Text('Rider Sign In'),
                              icon: Icon(Icons.login_rounded, size: 16),
                            ),
                            ButtonSegment<bool>(
                              value: true,
                              label: Text('Create Account'),
                              icon:
                                  Icon(Icons.person_add_alt_1_rounded, size: 16),
                            ),
                          ],
                          selected: {_isRegisterMode},
                          onSelectionChanged: (set) {
                            setState(() {
                              _isRegisterMode = set.first;
                            });
                          },
                        ),
                        const SizedBox(height: 16),

                        // Google One-Tap / Google Sign-In CTA Card
                        Card.filled(
                          color: AppPalette.mantle,
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(16),
                            side: BorderSide(
                              color: AppPalette.champagneGold
                                  .withValues(alpha: 0.4),
                            ),
                          ),
                          child: InkWell(
                            borderRadius: BorderRadius.circular(16),
                            onTap: vm.viewState == ViewState.loading
                                ? null
                                : _handleGoogleOneTap,
                            child: Padding(
                              padding: const EdgeInsets.symmetric(
                                horizontal: 16,
                                vertical: 14,
                              ),
                              child: Row(
                                children: [
                                  Container(
                                    width: 36,
                                    height: 36,
                                    decoration: BoxDecoration(
                                      color: AppPalette.surface1,
                                      borderRadius: BorderRadius.circular(10),
                                    ),
                                    child: const Center(
                                      child: Text(
                                        'G',
                                        style: TextStyle(
                                          color: AppPalette.champagneGold,
                                          fontSize: 19,
                                          fontWeight: FontWeight.w900,
                                        ),
                                      ),
                                    ),
                                  ),
                                  const SizedBox(width: 12),
                                  const Expanded(
                                    child: Column(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      children: [
                                        Text(
                                          'Continue with Google One-Tap',
                                          style: TextStyle(
                                            color: AppPalette.textHigh,
                                            fontSize: 14,
                                            fontWeight: FontWeight.w800,
                                          ),
                                        ),
                                        Text(
                                          'Instant rider sign-in for service & parts reservation',
                                          style: TextStyle(
                                            color: AppPalette.textMuted,
                                            fontSize: 11.5,
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                  const Icon(
                                    Icons.arrow_forward_ios_rounded,
                                    size: 15,
                                    color: AppPalette.champagneGold,
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ),
                        const SizedBox(height: 16),

                        Row(
                          children: [
                            const Expanded(child: Divider()),
                            Padding(
                              padding:
                                  const EdgeInsets.symmetric(horizontal: 10),
                              child: Text(
                                _isRegisterMode
                                    ? 'OR REGISTER WITH EMAIL'
                                    : 'OR SIGN IN WITH PASSWORD',
                                style: const TextStyle(
                                  color: AppPalette.textMuted,
                                  fontSize: 10.5,
                                  fontWeight: FontWeight.w700,
                                  letterSpacing: 0.6,
                                ),
                              ),
                            ),
                            const Expanded(child: Divider()),
                          ],
                        ),
                        const SizedBox(height: 16),

                        if (_isRegisterMode) ...[
                          LayoutBuilder(
                            builder: (context, innerConstraints) {
                              final isCompact = innerConstraints.maxWidth < 360;
                              final firstField = TextFormField(
                                controller: _firstNameCtrl,
                                validator: (v) => AppValidators.requiredField(
                                  v,
                                  'First name',
                                ),
                                decoration: const InputDecoration(
                                  labelText: 'First Name',
                                  prefixIcon: Icon(Icons.person_outline_rounded),
                                ),
                              );
                              final lastField = TextFormField(
                                controller: _lastNameCtrl,
                                validator: (v) => AppValidators.requiredField(
                                  v,
                                  'Last name',
                                ),
                                decoration: const InputDecoration(
                                  labelText: 'Last Name',
                                  prefixIcon: Icon(Icons.badge_outlined),
                                ),
                              );
                              if (isCompact) {
                                return Column(
                                  children: [
                                    firstField,
                                    const SizedBox(height: 12),
                                    lastField,
                                  ],
                                );
                              }
                              return Row(
                                children: [
                                  Expanded(child: firstField),
                                  const SizedBox(width: 12),
                                  Expanded(child: lastField),
                                ],
                              );
                            },
                          ),
                          const SizedBox(height: 12),
                        ],

                        TextFormField(
                          controller: _usernameOrEmailCtrl,
                          validator: _isRegisterMode
                              ? AppValidators.username
                              : (v) => AppValidators.requiredField(
                                    v,
                                    'Username or email',
                                  ),
                          decoration: InputDecoration(
                            labelText: _isRegisterMode
                                ? 'Rider Username'
                                : 'Username or Email',
                            hintText: _isRegisterMode
                                ? 'e.g. juan.rider'
                                : 'Enter your username or email',
                            prefixIcon:
                                const Icon(Icons.alternate_email_rounded),
                          ),
                        ),
                        const SizedBox(height: 12),

                        if (_isRegisterMode) ...[
                          TextFormField(
                            controller: _emailCtrl,
                            keyboardType: TextInputType.emailAddress,
                            validator: AppValidators.email,
                            decoration: const InputDecoration(
                              labelText: 'Email Address',
                              hintText: 'rider@email.com',
                              prefixIcon: Icon(Icons.email_outlined),
                            ),
                          ),
                          const SizedBox(height: 12),
                          SegmentedButton<BranchId>(
                            segments: const [
                              ButtonSegment(
                                value: BranchId.patimbao,
                                label: Text('Branch 1: Patimbao'),
                                icon: Icon(Icons.storefront_rounded, size: 16),
                              ),
                              ButtonSegment(
                                value: BranchId.pedroGuevara,
                                label: Text('Branch 2: P. Guevara'),
                                icon: Icon(Icons.location_on_outlined, size: 16),
                              ),
                            ],
                            selected: {_preferredBranch},
                            onSelectionChanged: (set) {
                              setState(() {
                                _preferredBranch = set.first;
                              });
                            },
                          ),
                          const SizedBox(height: 12),
                        ],

                        TextFormField(
                          controller: _passwordCtrl,
                          obscureText: _obscurePassword,
                          validator: AppValidators.password,
                          onFieldSubmitted: (_) => _submitEmailPasswordAuth(),
                          decoration: InputDecoration(
                            labelText: 'Password',
                            prefixIcon: const Icon(Icons.lock_outline_rounded),
                            suffixIcon: IconButton(
                              onPressed: () {
                                setState(() {
                                  _obscurePassword = !_obscurePassword;
                                });
                              },
                              icon: Icon(
                                _obscurePassword
                                    ? Icons.visibility_off_outlined
                                    : Icons.visibility_outlined,
                              ),
                            ),
                          ),
                        ),
                        if (!_isRegisterMode) ...[
                          const SizedBox(height: 6),
                          Align(
                            alignment: Alignment.centerRight,
                            child: TextButton(
                              onPressed: () => ForgotPasswordScreen.navigate(
                                context,
                                initialEmail:
                                    _usernameOrEmailCtrl.text.contains('@')
                                        ? _usernameOrEmailCtrl.text.trim()
                                        : null,
                              ),
                              child: const Text(
                                'Forgot Password?',
                                style: TextStyle(
                                  color: AppPalette.champagneGold,
                                  fontSize: 12.5,
                                  fontWeight: FontWeight.w600,
                                ),
                              ),
                            ),
                          ),
                        ],
                        const SizedBox(height: 16),

                        GoldGradientButton(
                          label: _isRegisterMode
                              ? 'Create Rider Account'
                              : 'Sign In to Rider Portal',
                          icon: _isRegisterMode
                              ? Icons.how_to_reg_rounded
                              : Icons.login_rounded,
                          isLoading: vm.viewState == ViewState.loading,
                          onPressed: _submitEmailPasswordAuth,
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            );
          },
        ),
      ),
    );
  }
}